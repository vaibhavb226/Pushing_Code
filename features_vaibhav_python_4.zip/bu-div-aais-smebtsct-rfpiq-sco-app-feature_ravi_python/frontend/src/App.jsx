import React, { useState, useEffect, useRef } from 'react'
import { Routes, Route, Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { FileText, Archive, Brain, LayoutDashboard, MessageSquare, LogOut, ChevronDown, ChevronLeft, ChevronRight, Sun, Moon } from 'lucide-react'
import { ThemeProvider, useTheme } from './context/ThemeContext'
import BidQueue      from './components/BidQueue/index.jsx'
import BidDetail     from './components/BidDetail/index.jsx'
import DocumentVault from './components/DocumentVault/index.jsx'
import UploadRFP     from './components/BexAI/index.jsx'
import RfpAiqDrawer  from './components/RfpAiq/RfpAiqDrawer.jsx'
import SupplierPortal from './pages/SupplierPortal.jsx'
import Login          from './pages/Login.jsx'

// ── Auth helpers ──────────────────────────────────────────
const LS_KEY = 'rfpaiq_user'

function getStoredUser() {
  try {
    const raw = localStorage.getItem(LS_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

// ── Protected route guard ─────────────────────────────────
function ProtectedRoute({ children }) {
  const auth = getStoredUser()
  if (!auth?.loggedIn) return <Navigate to="/login" replace />
  return children
}

// ── Sidebar nav ───────────────────────────────────────────
const navItems = [
  { path: '/',      label: 'Bid Queue',      icon: LayoutDashboard, exact: true },
  { path: '/vault', label: 'Document Vault', icon: Archive },
  { path: '/bex',   label: 'Upload RFP',     icon: Brain },
]

function Sidebar({ isCollapsed, onToggle }) {
  const location = useLocation()

  const isActive = (path, exact) => {
    if (exact) return location.pathname === path || location.pathname.startsWith('/bids/')
    return location.pathname.startsWith(path) && path !== '/'
  }

  const w = isCollapsed ? 64 : 256

  return (
    <aside
      style={{
        width: w,
        minWidth: w,
        transition: 'width 0.25s ease, min-width 0.25s ease',
        position: 'fixed',
        left: 0,
        top: 0,
        height: '100vh',
        zIndex: 100,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: '#1F3864',
      }}
    >
      {/* Logo row */}
      <div className="border-b border-white/10" style={{ padding: isCollapsed ? '16px 0' : '16px 24px', position: 'relative' }}>
        <div className="flex items-center" style={{ gap: isCollapsed ? 0 : 10, justifyContent: isCollapsed ? 'center' : 'flex-start' }}>
          <div style={{ backgroundColor: 'white', borderRadius: '4px', padding: '2px 6px', display: 'flex', alignItems: 'center', flexShrink: 0 }}>
            <img
              src="/Sysco-Logo.jpg"
              alt="Sysco"
              style={{ height: '32px', objectFit: 'contain' }}
              onError={e => {
                e.currentTarget.style.display = 'none'
                e.currentTarget.nextSibling.style.display = 'block'
              }}
            />
            <span style={{ display: 'none', fontWeight: 'bold', color: '#1F3864', fontSize: '14px' }}>SYSCO</span>
          </div>
          {!isCollapsed && (
            <div style={{ overflow: 'hidden' }}>
              <div className="text-white font-bold text-sm leading-tight">Sysco RFP AIQ</div>
              <div className="text-blue-300 text-xs">Procurement Platform</div>
            </div>
          )}
        </div>

        {/* Toggle button — sits on the right edge */}
        <button
          onClick={onToggle}
          style={{
            position: 'absolute',
            right: -12,
            top: '50%',
            transform: 'translateY(-50%)',
            width: 24,
            height: 24,
            borderRadius: '50%',
            backgroundColor: 'white',
            border: '1.5px solid #1F3864',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            zIndex: 101,
            boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
          }}
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed
            ? <ChevronRight style={{ width: 13, height: 13, color: '#1F3864' }} />
            : <ChevronLeft  style={{ width: 13, height: 13, color: '#1F3864' }} />
          }
        </button>
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-4 space-y-0.5" style={{ padding: isCollapsed ? '16px 8px' : '16px 12px', overflowY: 'auto' }}>
        {!isCollapsed && (
          <p className="text-white/30 text-xs uppercase tracking-widest font-medium px-3 pb-2 pt-1">Navigation</p>
        )}
        {navItems.map(({ path, label, icon: Icon, exact }) => {
          const active = isActive(path, exact)
          return (
            <Link
              key={path}
              to={path}
              title={isCollapsed ? label : undefined}
              className={`
                flex items-center rounded-xl text-sm font-medium transition-all duration-150
                ${isCollapsed ? 'justify-center px-0 py-2.5' : 'gap-3 px-3 py-2.5'}
                ${active
                  ? 'bg-exl-orange text-white shadow-sm'
                  : 'text-blue-200 hover:bg-white/10 hover:text-white'
                }
              `}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {!isCollapsed && label}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-white/10">
        {!isCollapsed && (
          <>
            <p className="text-blue-300/60 text-xs px-6 pt-4">Bid COE · COE.BIDS@sysco.com</p>
            <p className="text-blue-400/40 text-xs px-6 mt-0.5">v1.0 · CONFIDENTIAL</p>
          </>
        )}
        <div style={{ textAlign: 'center', padding: isCollapsed ? '12px 4px' : '12px 16px' }}>
          {isCollapsed ? (
            <img
              src="/exl_logo_sidebar.png"
              alt="EXL Service"
              style={{ height: '28px', width: 'auto', display: 'block', margin: '0 auto' }}
            />
          ) : (
            <>
              <img
                src="/exl_logo_sidebar.png"
                alt="EXL Service"
                style={{ height: '36px', width: 'auto', display: 'block', margin: '0 auto 4px auto' }}
              />
              <p style={{ fontSize: '10px', color: '#94A3B8', margin: '0', letterSpacing: '0.3px' }}>
                EXLService.com™ · © 2026
              </p>
            </>
          )}
        </div>
      </div>
    </aside>
  )
}

// ── User avatar + sign-out dropdown ──────────────────────
function UserMenu() {
  const navigate            = useNavigate()
  const [open, setOpen]     = useState(false)
  const ref                 = useRef(null)
  const stored              = getStoredUser()
  const user                = stored?.user ?? {
    name:     'Tricia Johnson',
    title:    'Bid COE Manager',
    email:    'tricia.johnson@sysco.com',
    initials: 'TJ',
  }

  // Close on outside click
  useEffect(() => {
    if (!open) return
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [open])

  const handleSignOut = () => {
    localStorage.removeItem(LS_KEY)
    localStorage.removeItem('theme')
    document.documentElement.classList.remove('dark')
    navigate('/login', { replace: true })
  }

  return (
    <div ref={ref} className="relative flex items-center gap-2">
      <span className="text-xs text-gray-400 hidden sm:block">
        {user.name} · {user.title}
      </span>

      {/* Avatar button */}
      <button
        onClick={() => setOpen(p => !p)}
        className="flex items-center gap-1 focus:outline-none group"
        title="Account menu"
      >
        <div className="w-8 h-8 rounded-full bg-exl-navy flex items-center justify-center text-white text-xs font-bold select-none group-hover:opacity-80 transition-opacity">
          {user.initials}
        </div>
        <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform duration-150 ${open ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown */}
      {open && (
        <div className="absolute right-0 top-full mt-2 w-56 bg-white dark:bg-[#1E293B] border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg z-50 overflow-hidden">
          {/* User info (non-clickable) */}
          <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700">
            <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{user.name}</p>
            <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5 truncate">{user.email}</p>
          </div>

          {/* Sign out */}
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-2.5 px-4 py-3 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      )}
    </div>
  )
}

// ── Dark mode toggle button ───────────────────────────────
function DarkModeToggle() {
  const { isDark, toggleTheme } = useTheme()
  return (
    <button
      onClick={toggleTheme}
      title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      className="p-2 rounded-lg text-gray-400 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-all duration-150"
    >
      {isDark ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  )
}

// ── Top header bar ─────────────────────────────────────────
function Header() {
  const location   = useLocation()
  const isBidDetail = location.pathname.startsWith('/bids/')
  const isVault    = location.pathname.startsWith('/vault')
  const isBex      = location.pathname.startsWith('/bex')

  const breadcrumb = isBidDetail ? 'Bid Queue / Bid Detail'
    : isVault ? 'Document Vault'
    : isBex   ? 'Upload RFP'
    : null

  return (
    <header className="h-14 bg-white dark:bg-[#1E293B] border-b border-gray-200 dark:border-gray-700 flex items-center px-6 gap-4 flex-shrink-0">
      <div className="flex-1">
        {breadcrumb && (
          <p className="text-xs text-gray-400 dark:text-gray-500">
            {isBidDetail
              ? <><span className="text-exl-orange font-medium">Bid Queue</span>{' '}/ Bid Detail</>
              : <span className="text-exl-orange font-medium">{breadcrumb}</span>
            }
          </p>
        )}
      </div>
      <DarkModeToggle />
      <UserMenu />
    </header>
  )
}

// ── RFP AIQ floating action button ───────────────────────
function AiqFab({ onClick }) {
  return (
    <button
      onClick={onClick}
      className="group fixed z-[9999] flex items-center gap-2 px-4 py-3 rounded-2xl text-white font-semibold text-sm shadow-lg transition-all duration-150 hover:scale-[1.02] active:scale-[0.98]"
      style={{
        bottom: 80,
        right: 28,
        backgroundColor: '#E05A2B',
        boxShadow: '0 4px 20px rgba(224,90,43,0.40)',
        zIndex: 9997,
      }}
      aria-label="Chat with AIQ"
    >
      <MessageSquare className="w-4 h-4 flex-shrink-0" />
      <span className="hidden sm:inline">Chat with AIQ</span>
    </button>
  )
}

// ── Internal app layout (sidebar + header) ────────────────
function AppLayout({ onOpenAiq, aiqOpen }) {
  const [isCollapsed, setIsCollapsed] = useState(
    () => JSON.parse(localStorage.getItem('sidebar_collapsed') || 'false')
  )

  const handleToggle = () => {
    setIsCollapsed(prev => {
      const next = !prev
      localStorage.setItem('sidebar_collapsed', JSON.stringify(next))
      return next
    })
  }

  const marginLeft = isCollapsed ? 64 : 256

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50 dark:bg-[#0F172A]">
      <Sidebar isCollapsed={isCollapsed} onToggle={handleToggle} />
      <div
        className="flex flex-col flex-1 h-screen overflow-hidden min-w-0"
        style={{ marginLeft, transition: 'margin-left 0.25s ease' }}
      >
        <Header />
        <main className="flex-1 p-6 overflow-auto">
          <Routes>
            <Route path="/"         element={<BidQueue />} />
            <Route path="/bids"     element={<BidQueue />} />
            <Route path="/bids/:id" element={<BidDetail />} />
            <Route path="/vault"    element={<DocumentVault />} />
            <Route path="/bex"      element={<UploadRFP />} />
          </Routes>
        </main>
      </div>
      {!aiqOpen && <AiqFab onClick={onOpenAiq} />}
    </div>
  )
}

// ── App root ──────────────────────────────────────────────
export default function App() {
  const [aiqOpen,     setAiqOpen]     = useState(false)
  const [aiqMessages, setAiqMessages] = useState([])

  const handleOpenAiq = () => {
    setAiqMessages([])
    setAiqOpen(true)
  }

  return (
    <ThemeProvider>
    <>
      <Routes>
        {/* ── LOGIN — public ── */}
        <Route path="/login" element={<Login />} />

        {/* ── SUPPLIER PORTAL — public, no auth ── */}
        <Route path="/submit/:bidId/thread/:threadId" element={<SupplierPortal />} />
        <Route path="/submit/:bidId" element={<SupplierPortal />} />

        {/* ── ALL INTERNAL ROUTES — protected ── */}
        <Route path="/*" element={
          <ProtectedRoute>
            <AppLayout onOpenAiq={handleOpenAiq} aiqOpen={aiqOpen} />
          </ProtectedRoute>
        } />
      </Routes>

      {/* Global AIQ drawer — available on all internal pages */}
      <RfpAiqDrawer
        isOpen={aiqOpen}
        onClose={() => setAiqOpen(false)}
        messages={aiqMessages}
        setMessages={setAiqMessages}
      />
    </>
    </ThemeProvider>
  )
}
