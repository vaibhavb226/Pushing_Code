import React, { useState, useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import {
  Mail, ArrowUp, ArrowDown, Paperclip, X, Plus, AlertCircle,
  CheckCircle, AlertTriangle, Send, Loader, Loader2, ChevronDown,
  ChevronRight, FileText, FileSpreadsheet, Users, Clock,
  MailOpen, RefreshCw, Flag, Sparkles, Globe, ExternalLink,
  Download,
} from 'lucide-react'
import { Button } from '../UI/Button'
import { Badge } from '../UI/Badge'
import { EmptyState } from '../UI/EmptyState'
import PricingExtractModal from './PricingExtractModal'
import { buildAwardEmailDraft } from '../../utils/awardEmailTemplate'
import { PORTAL_URL as PORTAL_BASE } from '../../config.js'

// Two-path conditional SVG — guarantees fill/stroke toggle regardless of React reconciliation
const FlagIcon = ({ filled, size = 18, stroke }) => filled ? (
  <svg width={size} height={size} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style={{ flexShrink: 0 }}>
    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"
      fill="#E05A2B" stroke="#E05A2B" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="4" y1="22" x2="4" y2="15" stroke="#E05A2B" strokeWidth="2" strokeLinecap="round" />
  </svg>
) : (
  <svg width={size} height={size} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style={{ flexShrink: 0 }}>
    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"
      fill="none" stroke={stroke ?? '#9CA3AF'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="4" y1="22" x2="4" y2="15" stroke={stroke ?? '#9CA3AF'} strokeWidth="2" strokeLinecap="round" />
  </svg>
)

// ── Portal helpers ─────────────────────────────────────────
const getThreadUrl = (bidId, threadId) => `${PORTAL_BASE}/submit/${bidId}/thread/${threadId}`

// Check if a supplier has any portal emails
const hasPortal = (supplier) =>
  supplier.emails?.some(e => e.portalSubmission === true) ?? false

// Get threadId from supplier emails
const getThreadId = (supplier) =>
  supplier.emails?.find(e => e.threadId)?.threadId ?? null

// ── Attachment helpers ──────────────────────────────────────
// Supports both:
//   • new format: { originalName, savedName, path, mimeType }
//   • legacy format: plain string filename
const getAttachmentName = (att) => {
  if (typeof att === 'string') return att
  if (att?.originalName) return att.originalName
  if (att?.savedName)   return att.savedName
  return 'attachment'
}

const getAttachmentSavedName = (att) => {
  if (typeof att === 'object' && att?.savedName) return att.savedName
  if (typeof att === 'string') return att
  return null
}

// Truncate display name if very long
const truncateAtt = (name, max = 40) =>
  name.length > max ? name.slice(0, max - 1) + '…' : name

// Build a download URL for an attachment.
// Uses /api/files/:bidId/attachments/:filename which handles name→disk mapping.
const getDownloadUrl = (att, bidId) => {
  const saved = getAttachmentSavedName(att)
  if (!saved || !bidId) return null
  return `/api/files/${encodeURIComponent(bidId)}/attachments/${encodeURIComponent(saved)}`
}

// ─────────────────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────────────────
const STATUS_CFG = {
  Awaiting:           { icon: '⏳', bg: 'bg-gray-100',    text: 'text-gray-600',   dot: 'bg-gray-400',    label: 'Awaiting' },
  Responded:          { icon: '✓',  bg: 'bg-emerald-100', text: 'text-emerald-700',dot: 'bg-emerald-500', label: 'Responded' },
  'Issues Found':     { icon: '⚠️', bg: 'bg-amber-100',   text: 'text-amber-700',  dot: 'bg-amber-500',   label: 'Issues Found' },
  'Follow-up Sent':   { icon: '🔄', bg: 'bg-blue-100',    text: 'text-blue-700',   dot: 'bg-blue-500',    label: 'Follow-up Sent' },
  Complete:           { icon: '🏆', bg: 'bg-teal-100',    text: 'text-teal-700',   dot: 'bg-teal-500',    label: 'Awarded' },
  Awarded:            { icon: '🏆', bg: 'bg-teal-100',    text: 'text-teal-700',   dot: 'bg-teal-500',    label: 'Awarded' },
  'In Consideration':    { icon: '🚩', bg: 'bg-orange-100',  text: 'text-orange-700', dot: 'bg-orange-500',  label: 'Under Consideration' },
  'Under Consideration': { icon: '🚩', bg: 'bg-orange-100',  text: 'text-orange-700', dot: 'bg-orange-500',  label: 'Under Consideration' },
}

const ISSUE_CFG = {
  missing_items:   { bg: 'bg-red-100',    text: 'text-red-700',    label: 'Missing Items' },
  format_issues:   { bg: 'bg-amber-100',  text: 'text-amber-700',  label: 'Format Issues' },
  expired_pricing: { bg: 'bg-orange-100', text: 'text-orange-800', label: 'Expired Pricing' },
  non_compliant:   { bg: 'bg-purple-100', text: 'text-purple-700', label: 'Non-Compliant' },
}

const TAG_COLORS = {
  Solicitation: 'bg-blue-100 text-blue-700',
  Response:     'bg-emerald-100 text-emerald-700',
  Pricing:      'bg-green-100 text-green-700',
  'Q&A':        'bg-purple-100 text-purple-700',
  'Follow-up':  'bg-amber-100 text-amber-700',
  'Re-solicit': 'bg-orange-100 text-orange-700',
  Compliance:   'bg-teal-100 text-teal-700',
}

const fmtDate  = (d) => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
const fmtFull  = (d) => new Date(d).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })
const countIssues = (issues) =>
  Object.values(issues || {}).reduce((s, a) => s + (Array.isArray(a) ? a.length : 0), 0)

// ─────────────────────────────────────────────────────────
// 1. Summary Bar
// ─────────────────────────────────────────────────────────
function SummaryBar({ suppliers, activeFilter, onFilter }) {
  const RESPONDED_STATUSES = ['Responded', 'Follow-up Sent', 'Under Consideration', 'Awarded', 'Complete']
  const total          = suppliers.length
  const responded      = suppliers.filter(s => RESPONDED_STATUSES.includes(s.status)).length
  const issues         = suppliers.filter(s => s.status === 'Issues Found').length
  const awaiting       = suppliers.filter(s => !s.status || s.status === 'Awaiting' || s.status === 'Contacted').length
  const awarded        = suppliers.filter(s => s.status === 'Complete' || s.status === 'Awarded').length
  const inConsideration = suppliers.filter(s => s.inConsideration).length

  const pills = [
    { key: null,               label: 'All',              count: total,           cls: 'bg-gray-900 text-white' },
    { key: 'Responded',        label: '✓ Responded',      count: responded,       cls: 'bg-emerald-600 text-white' },
    { key: 'Issues Found',     label: '⚠ Issues',         count: issues,          cls: 'bg-amber-500 text-white' },
    { key: 'Awaiting',         label: '⏳ Awaiting',       count: awaiting,        cls: 'bg-gray-500 text-white' },
    { key: 'Awarded',          label: '🏆 Awarded',        count: awarded,         cls: 'bg-teal-600 text-white' },
  ]

  return (
    <div className="flex flex-wrap items-center gap-2 mb-4">
      {pills.map(p => (
        <button
          key={String(p.key)}
          onClick={() => onFilter(p.key)}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all
            ${activeFilter === p.key
              ? p.cls + ' shadow-sm'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
        >
          {p.label}
          <span className={`min-w-[18px] text-center px-1 py-0.5 rounded-full text-xs font-bold
            ${activeFilter === p.key ? 'bg-white/20' : 'bg-white text-gray-700'}`}>
            {p.count}
          </span>
        </button>
      ))}
      {/* Under Consideration — icon-only pill */}
      <button
        title="Under Consideration"
        onClick={() => onFilter(activeFilter === 'In Consideration' ? null : 'In Consideration')}
        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all
          ${activeFilter === 'In Consideration'
            ? 'bg-orange-500 text-white shadow-sm'
            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
      >
        <FlagIcon filled size={12} stroke={activeFilter === 'In Consideration' ? '#ffffff' : '#E05A2B'} />
        <span className={`min-w-[18px] text-center px-1 py-0.5 rounded-full text-xs font-bold
          ${activeFilter === 'In Consideration' ? 'bg-white/20' : 'bg-white text-gray-700'}`}>
          {inConsideration}
        </span>
      </button>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 2. Solicitation Row (pinned)
// ─────────────────────────────────────────────────────────
function SolicitationRow({ solicitation, active, onClick }) {
  if (!solicitation) return null
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-3 border-b-2 border-gray-200 transition-colors flex items-center gap-3
        ${active
          ? 'bg-exl-orange/5 border-l-2 border-l-exl-orange'
          : 'hover:bg-gray-50 border-l-2 border-l-transparent'
        }`}
    >
      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
        <ArrowUp className="w-4 h-4 text-blue-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-bold text-gray-800">📤 Solicitation Sent</p>
        <p className="text-xs text-gray-500 mt-0.5">
          {fmtDate(solicitation.date)} · {solicitation.bcc?.length ?? 0} suppliers
        </p>
      </div>
    </button>
  )
}

// ─────────────────────────────────────────────────────────
// 3. Supplier Row
// ─────────────────────────────────────────────────────────
function SupplierRow({ supplier, active, onClick, notifDate }) {
  const cfg      = STATUS_CFG[supplier.status] ?? STATUS_CFG.Awaiting
  const isPortal = hasPortal(supplier)

  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-3 border-b border-gray-100 dark:border-gray-700 transition-colors
        ${active
          ? 'bg-[#EBF3FB] dark:bg-[#1a3040] border-l-2 border-l-[#E05A2B]'
          : 'hover:bg-[#F8FAFC] dark:hover:bg-[#253347] border-l-2 border-l-transparent'
        }`}
    >
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <div className="group/row flex items-center gap-1 min-w-0">
          <p className="text-xs font-semibold text-gray-800 truncate leading-tight">
            {supplier.supplierName}
            {supplier.isBroker && (
              <span className="ml-1 text-xs bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded font-medium">Broker</span>
            )}
          </p>
          {/* PORTAL-DEMO: portal badge additive */}
          {isPortal && (
            <span className="inline-flex items-center gap-0.5 text-xs font-semibold px-1.5 py-0.5 bg-emerald-100 text-emerald-700 rounded flex-shrink-0">
              <Globe className="w-2.5 h-2.5" /> Portal
            </span>
          )}
          {/* Flag icon: always visible when flagged, show on row-hover when not */}
          <span
            className={`flex-shrink-0 transition-opacity leading-none ${
              supplier.inConsideration ? 'opacity-100' : 'opacity-0 group-hover/row:opacity-100'
            }`}
            title={supplier.inConsideration ? 'Under Consideration' : 'Mark Under Consideration'}
          >
            <FlagIcon filled={supplier.inConsideration} size={13} />
          </span>
        </div>
        {supplier.issueCount > 0 && (
          <span className="flex-shrink-0 inline-flex items-center gap-0.5 text-xs font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded-full">
            <AlertTriangle className="w-2.5 h-2.5" />{supplier.issueCount}
          </span>
        )}
      </div>

      <div className="flex items-center justify-between">
        <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.text}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
          {cfg.label}
        </span>
        <div className="text-right">
          {supplier.emailCount > 0 && (
            <p className="text-xs text-gray-500">{supplier.emailCount} email{supplier.emailCount > 1 ? 's' : ''}</p>
          )}
          {supplier.lastActivity && (
            <p className="text-xs text-gray-400">{fmtDate(supplier.lastActivity)}</p>
          )}
        </div>
      </div>
      {notifDate && (
        <p className="mt-1 text-emerald-600 dark:text-emerald-400 font-medium" style={{ fontSize: 11 }}>
          📧 Award notified {notifDate}
        </p>
      )}
    </button>
  )
}

// ─────────────────────────────────────────────────────────
// 4. Analysis Card (inline in thread)
// ─────────────────────────────────────────────────────────
function AnalysisCard({ analysis }) {
  const [expanded, setExpanded] = useState({})
  const totalIssues = countIssues(analysis.issues)
  return (
    <div className="mt-3 rounded-xl border border-gray-200 overflow-hidden text-xs">
      <div className="bg-gray-50 px-3 py-2 border-b border-gray-200 flex items-center gap-2">
        <span className="font-semibold text-gray-600 uppercase tracking-wide">AI Analysis</span>
        {analysis.quote_reference && (
          <span className="text-gray-400 font-mono ml-auto">Ref: {analysis.quote_reference}</span>
        )}
      </div>
      <div className="px-3 py-2.5 space-y-2">
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-100 rounded-lg px-2.5 py-1.5">
          <CheckCircle className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
          <span className="text-emerald-800 font-medium">
            {analysis.priced_items?.length ?? 0} items priced
          </span>
          {analysis.valid_through && (
            <span className="ml-auto text-emerald-600">Valid through {analysis.valid_through}</span>
          )}
        </div>
        {totalIssues > 0 && (
          <div className="bg-amber-50 border border-amber-100 rounded-lg px-2.5 py-2">
            <div className="flex items-center gap-1.5 mb-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
              <span className="text-amber-800 font-semibold">{totalIssues} issue{totalIssues > 1 ? 's' : ''} found</span>
            </div>
            {Object.entries(analysis.issues || {}).map(([key, items]) => {
              if (!items?.length) return null
              const cfg = ISSUE_CFG[key]
              return (
                <div key={key} className="mb-1">
                  <button
                    onClick={() => setExpanded(p => ({ ...p, [key]: !p[key] }))}
                    className={`flex items-center gap-1 font-semibold px-2 py-0.5 rounded ${cfg.bg} ${cfg.text}`}
                  >
                    {cfg.label} ({items.length})
                    {expanded[key] ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                  </button>
                  {expanded[key] && (
                    <ul className="mt-1 pl-3 space-y-0.5">
                      {items.map((item, i) => (
                        <li key={i} className="text-gray-600 flex items-start gap-1">
                          <span className="text-gray-400 mt-0.5">•</span>{item}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 5. Email Bubble (in thread)
// ─────────────────────────────────────────────────────────
function EmailBubble({ email, isLatest, onFollowUp, onLogResponse, onExtractPricing, isExtracting, extractError, extractMsg, onUpdateEmail }) {
  const [expanded, setExpanded] = useState(isLatest)
  const [showEmailForm, setShowEmailForm] = useState(false)
  const [newEmail, setNewEmail] = useState('')
  const [updating, setUpdating] = useState(false)
  const isOut = email.direction === 'outbound'
  const isBounce = !!email.isBounce

  const atts     = email.attachments || []
  const attNames = atts.map(getAttachmentName)   // for legacy display / count

  // Show "Extract Pricing" button for inbound emails tagged Response/Pricing
  // or whose subject starts with "Re:" (supplier reply)
  const tags = (email.tags || []).map(t => t.toLowerCase())
  const showExtract = !isOut && (
    tags.some(t => ['response', 'pricing', 'reply'].includes(t)) ||
    (email.subject || '').toLowerCase().startsWith('re:') ||
    (email.subject || '').toLowerCase().includes('pricing') ||
    (email.subject || '').toLowerCase().includes('quote')
  )

  return (
    <div className={`border rounded-xl mb-3 overflow-hidden transition-all
      ${isOut ? 'border-blue-200 bg-blue-50/30' : 'border-gray-200 bg-white'}`}>

      {/* ── Bubble header (always visible) ── */}
      <button
        onClick={() => setExpanded(p => !p)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left"
      >
        <span className={`flex-shrink-0 inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full
          ${isBounce ? 'bg-red-100 text-red-700' : isOut ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'}`}>
          {isOut ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
          {isBounce ? 'Delivery Failed' : isOut ? 'Outbound' : 'Inbound'}
        </span>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-gray-800 truncate">{email.subject}</p>
          <p className="text-xs text-gray-500 truncate">
            {isOut ? `From: ${email.from}` : `From: ${email.from}`}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {attNames.length > 0 && (
            <span className="text-xs text-gray-400 flex items-center gap-0.5">
              <Paperclip className="w-3 h-3" />{attNames.length}
            </span>
          )}
          {email.analysisResult && (
            <span className={`text-xs px-1.5 py-0.5 rounded-full font-semibold
              ${countIssues(email.analysisResult.issues) > 0
                ? 'bg-amber-100 text-amber-700'
                : 'bg-emerald-100 text-emerald-700'}`}>
              AI ✓
            </span>
          )}
          <span className="text-xs text-gray-400">{fmtDate(email.date)}</span>
          {expanded ? <ChevronDown className="w-3.5 h-3.5 text-gray-400" /> : <ChevronRight className="w-3.5 h-3.5 text-gray-400" />}
        </div>
      </button>

      {/* ── Expanded body ── */}
      {expanded && (
        <div className="border-t border-gray-100">
          {/* Meta */}
          <div className="px-4 py-3 bg-gray-50/60 border-b border-gray-100 space-y-1 text-xs text-gray-600">
            <p><span className="font-medium w-12 inline-block">From:</span> {email.from}</p>
            <p><span className="font-medium w-12 inline-block">Date:</span> {fmtFull(email.date)}</p>
            {email.bcc?.length > 0 && (
              <p><span className="font-medium w-12 inline-block">BCC:</span>
                {isOut ? `${email.bcc.length} recipients` : email.bcc.join(', ')}
              </p>
            )}
            {/* Tags */}
            <div className="flex flex-wrap gap-1 pt-1">
              {(email.tags || []).map(t => (
                <span key={t} className={`px-1.5 py-0.5 rounded font-medium ${TAG_COLORS[t] ?? 'bg-gray-100 text-gray-600'}`}>
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* Bounce failure banner */}
          {isBounce && (
            <div className="mx-4 mt-4 rounded-xl border border-red-200 bg-red-50 overflow-hidden">
              <div className="flex items-center gap-2 px-4 py-2.5 bg-red-100 border-b border-red-200">
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                <span className="text-sm font-bold text-red-700">⚠ Delivery Failure</span>
              </div>
              <div className="px-4 py-3 space-y-1 text-xs text-red-800">
                <p><span className="font-semibold w-32 inline-block">Error Code:</span>{email.bounceCode}</p>
                <p><span className="font-semibold w-32 inline-block">Reason:</span>{email.bounceReason}</p>
                <p><span className="font-semibold w-32 inline-block">Failed Address:</span>
                  <span className="font-mono">{email.originalRecipient}</span>
                </p>
              </div>
              <div className="px-4 pb-3">
                {!showEmailForm ? (
                  <button
                    onClick={() => { setShowEmailForm(true); setNewEmail('') }}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                  >
                    <Mail className="w-3 h-3" /> Update Email Address
                  </button>
                ) : (
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-red-700">Enter corrected email address:</p>
                    <input
                      type="email"
                      value={newEmail}
                      onChange={e => setNewEmail(e.target.value)}
                      placeholder="supplier@company.com"
                      className="w-full px-3 py-2 text-sm border border-red-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-400 bg-white"
                      autoFocus
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowEmailForm(false)}
                        className="px-3 py-1.5 text-xs border border-gray-300 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={async () => {
                          if (!newEmail.trim()) return
                          setUpdating(true)
                          await onUpdateEmail?.(newEmail.trim())
                          setUpdating(false)
                          setShowEmailForm(false)
                        }}
                        disabled={updating || !newEmail.trim()}
                        className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors disabled:opacity-50"
                      >
                        {updating
                          ? <><Loader2 className="w-3 h-3 animate-spin" /> Updating…</>
                          : <><Send className="w-3 h-3" /> Update &amp; Re-solicit</>
                        }
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Body */}
          <div className="px-4 py-4">
            <pre className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed font-sans">{email.body}</pre>
          </div>

          {/* Attachments */}
          {atts.length > 0 && (
            <div className="px-4 py-3 bg-gray-50 border-t border-gray-100">
              <p className="text-xs font-semibold text-gray-500 mb-2">
                <Paperclip className="w-3.5 h-3.5 inline mr-1" />Attachments
              </p>
              <div className="flex flex-wrap gap-2">
                {atts.map((att, i) => {
                  const name = getAttachmentName(att)
                  const url  = getDownloadUrl(att, email.bidId)
                  const isPdf  = /\.pdf$/i.test(name)
                  const isXls  = /\.xlsx?$/i.test(name)
                  const Icon   = isPdf ? FileText : isXls ? FileSpreadsheet : Paperclip
                  const iconCls= isPdf ? 'text-red-400' : isXls ? 'text-emerald-500' : 'text-gray-400'
                  const pill   = 'inline-flex items-center gap-1.5 border text-xs px-3 py-1.5 rounded-lg transition-colors'

                  return url ? (
                    <a
                      key={i}
                      href={url}
                      download={name}
                      target="_blank"
                      rel="noopener noreferrer"
                      title={name}
                      className={`${pill} bg-white border-gray-200 text-gray-700 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 cursor-pointer`}
                    >
                      <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${iconCls}`} />
                      <span className="max-w-[200px] truncate">{truncateAtt(name)}</span>
                      <Download className="w-3 h-3 text-gray-400 flex-shrink-0 ml-0.5" />
                    </a>
                  ) : (
                    <span key={i} title={name}
                      className={`${pill} bg-white border-gray-200 text-gray-700`}>
                      <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${iconCls}`} />
                      <span className="max-w-[200px] truncate">{truncateAtt(name)}</span>
                    </span>
                  )
                })}
              </div>
            </div>
          )}

          {/* Analysis card */}
          {email.analysisResult && (
            <div className="px-4 pb-4">
              <AnalysisCard analysis={email.analysisResult} />
            </div>
          )}

          {/* Action buttons on inbound emails */}
          {!isOut && (showExtract || attNames.length > 0) && (
            <div className="px-4 py-3 bg-gray-50 border-t border-gray-100 flex flex-wrap items-center gap-2">
              {/* Extract Pricing to Working File */}
              {showExtract && (
                <div className="flex flex-col gap-1">
                  <button
                    onClick={() => onExtractPricing(email)}
                    disabled={isExtracting}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 border rounded-lg transition-colors disabled:opacity-80 disabled:cursor-wait
                      border-exl-navy text-exl-navy bg-white hover:bg-exl-navy hover:text-white"
                  >
                    {isExtracting
                      ? <><Loader2 className="w-3 h-3 animate-spin" /> Extracting pricing...</>
                      : <><Sparkles className="w-3 h-3" /> Extract Pricing to Working File</>
                    }
                  </button>
                  {isExtracting && extractMsg && (
                    <p className="text-xs text-gray-500 animate-pulse mt-0.5">{extractMsg}</p>
                  )}
                  {extractError && !isExtracting && (
                    <p className="text-xs text-red-600 mt-0.5">
                      {extractError.toLowerCase().includes('attachment') || extractError.toLowerCase().includes('file')
                        ? 'Could not read the attached file. Please ensure the attachment is a valid PDF or Excel file and try again.'
                        : extractError.toLowerCase().includes('document content')
                          ? 'No attachment found on disk. Please re-upload the pricing file via Log Supplier Response.'
                          : 'Could not extract pricing from this email. Try copying the pricing data manually.'}
                    </p>
                  )}
                </div>
              )}
              {/* IMPORT-PRICING-REMOVED: can restore if needed
              {attNames.length > 0 && (
                <button
                  className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-700 transition-colors"
                >
                  <FileSpreadsheet className="w-3 h-3" /> Import Pricing
                </button>
              )}
              */}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 6. Solicitation Detail (right panel)
// ─────────────────────────────────────────────────────────
function SolicitationDetail({ solicitation, suppliers = [] }) {
  const [bccExpanded, setBccExpanded] = useState(false)

  const solAtts  = solicitation.attachments || []
  const attNames = solAtts.map(getAttachmentName)   // legacy compat

  // Build email → supplier name lookup
  const emailToName = {}
  suppliers.forEach(s => {
    if (s.supplierEmail) emailToName[s.supplierEmail.toLowerCase()] = s.supplierName
  })

  const bccEmails     = solicitation.bcc || []
  // Show as "Supplier Name <email>" when we have the name, else just email
  const bccLabels     = bccEmails.map(e => {
    const name = emailToName[e.toLowerCase()]
    return name ? `${name} <${e}>` : e
  })
  const PREVIEW_COUNT = 6
  const previewLabels = bccLabels.slice(0, PREVIEW_COUNT)
  const hiddenCount   = bccLabels.length - PREVIEW_COUNT

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
          <ArrowUp className="w-5 h-5 text-blue-600" />
        </div>
        <div>
          <p className="text-sm font-bold text-gray-900">Solicitation Email</p>
          <p className="text-xs text-gray-500">{fmtFull(solicitation.date)} · {bccEmails.length} supplier contacts</p>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 space-y-2 text-sm text-gray-700">
          <p><span className="font-medium text-gray-500 w-16 inline-block">From:</span>{solicitation.from}</p>

          {/* BCC — show supplier names with expandable list */}
          <div className="flex items-start gap-0">
            <span className="font-medium text-gray-500 w-16 flex-shrink-0">BCC:</span>
            <div className="flex-1">
              <span className="font-semibold text-gray-700">{bccEmails.length} supplier contacts</span>
              <div className="mt-1.5 space-y-0.5">
                {(bccExpanded ? bccLabels : previewLabels).map((label, i) => (
                  <p key={i} className="text-xs text-gray-500 font-mono leading-snug">{label}</p>
                ))}
                {hiddenCount > 0 && !bccExpanded && (
                  <button
                    onClick={() => setBccExpanded(true)}
                    className="text-xs text-exl-orange hover:underline font-medium mt-0.5"
                  >
                    + {hiddenCount} more…
                  </button>
                )}
                {bccExpanded && hiddenCount > 0 && (
                  <button
                    onClick={() => setBccExpanded(false)}
                    className="text-xs text-gray-400 hover:underline mt-0.5"
                  >
                    Show less
                  </button>
                )}
              </div>
            </div>
          </div>

          <p><span className="font-medium text-gray-500 w-16 inline-block">Subject:</span>{solicitation.subject}</p>
        </div>
        <div className="px-5 py-5">
          <pre className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed font-sans">{solicitation.body}</pre>
        </div>
        {solAtts.length > 0 && (
          <div className="px-5 py-3 bg-gray-50 border-t border-gray-100">
            <p className="text-xs font-semibold text-gray-500 mb-2">
              <Paperclip className="w-3.5 h-3.5 inline mr-1" />Attachments
            </p>
            <div className="flex flex-wrap gap-2">
              {solAtts.map((att, i) => {
                const name   = getAttachmentName(att)
                const url    = getDownloadUrl(att, solicitation.bidId)
                const isPdf  = /\.pdf$/i.test(name)
                const isXls  = /\.xlsx?$/i.test(name)
                const Icon   = isPdf ? FileText : isXls ? FileSpreadsheet : Paperclip
                const iconCls= isPdf ? 'text-red-400' : isXls ? 'text-emerald-500' : 'text-gray-400'
                const pill   = 'inline-flex items-center gap-1.5 border text-xs px-3 py-1.5 rounded-lg transition-colors'
                return url ? (
                  <a key={i} href={url} download={name} target="_blank" rel="noopener noreferrer" title={name}
                    className={`${pill} bg-white border-gray-200 text-gray-700 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 cursor-pointer`}>
                    <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${iconCls}`} />
                    <span className="max-w-[200px] truncate">{truncateAtt(name)}</span>
                    <Download className="w-3 h-3 text-gray-400 flex-shrink-0 ml-0.5" />
                  </a>
                ) : (
                  <span key={i} title={name}
                    className={`${pill} bg-white border-gray-200 text-gray-700`}>
                    <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${iconCls}`} />
                    <span className="max-w-[200px] truncate">{truncateAtt(name)}</span>
                  </span>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 7. Supplier Thread (right panel)
// ─────────────────────────────────────────────────────────
function SupplierThread({ supplier, bid, onFollowUp, onLogResponse, onMarkAwarded, onMarkInConsideration, onExtractPricing, onPortalReply, extractingEmailId, extractErrors, extractMsg, onUpdateEmail }) {
  const cfg      = STATUS_CFG[supplier.status] ?? STATUS_CFG.Awaiting
  const isPortal = hasPortal(supplier)
  const threadId = getThreadId(supplier)
  const threadUrl = threadId ? getThreadUrl(bid.id, threadId) : null
  const sortedEmails = [...supplier.emails].sort((a, b) => new Date(b.date) - new Date(a.date))

  // Collect pricing data from any email that has analysisResult with priced_items
  const pricingEmails = supplier.emails.filter(e => e.analysisResult?.priced_items?.length > 0)
  const hasPricingData = pricingEmails.length > 0

  function exportPricingCSV() {
    const rows = [['Supplier', 'Quote Reference', 'Priced Items', 'Valid Through', 'Email Date', 'Subject']]
    pricingEmails.forEach(e => {
      const ar = e.analysisResult
      rows.push([
        ar.supplier_name || supplier.supplierName,
        ar.quote_reference || '',
        (ar.priced_items || []).join('; '),
        ar.valid_through || '',
        (e.date || '').slice(0, 10),
        e.subject || '',
      ])
    })
    const csv = rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url  = URL.createObjectURL(blob)
    const a    = document.createElement('a')
    a.href     = url
    a.download = `${supplier.supplierName.replace(/\s+/g, '_')}_Pricing.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Thread header */}
      <div className="px-6 py-4 border-b border-gray-200 bg-gray-50/60 flex-shrink-0">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-gray-900">{supplier.supplierName}</h3>
              {/* PORTAL-DEMO: portal badge in thread header */}
              {isPortal && (
                <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full">
                  <Globe className="w-3 h-3" /> Supplier Portal
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500 mt-0.5">{supplier.supplierEmail}</p>
            {/* PORTAL-DEMO: supplier thread link additive */}
            {threadUrl && (
              <a
                href={threadUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-emerald-600 hover:underline mt-1"
              >
                <ExternalLink className="w-3 h-3" /> Open Supplier Thread
              </a>
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap justify-end">
            {hasPricingData && (
              <button
                onClick={exportPricingCSV}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-xl border border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition-colors"
                title="Export supplier pricing data as CSV"
              >
                <Download className="w-3.5 h-3.5" /> Export Pricing
              </button>
            )}
            <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.bg} ${cfg.text}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
              {cfg.label}
            </span>
            {/* Under Consideration — icon-only flag button */}
            <button
              onClick={() => onMarkInConsideration(supplier.supplierId)}
              title={supplier.inConsideration ? 'Remove from Consideration' : 'Mark Under Consideration'}
              className="p-1.5 rounded-full hover:bg-orange-50 transition-colors border-none bg-transparent"
            >
              <FlagIcon filled={!!supplier.inConsideration} size={18} />
            </button>
            {/* Awarded toggle — shown when not Awaiting; acts as toggle when already Awarded */}
            {supplier.status !== 'Awaiting' && (
              <button
                onClick={() => onMarkAwarded(supplier.supplierId)}
                title={
                  supplier.status === 'Complete' || supplier.status === 'Awarded'
                    ? 'Click to remove Awarded status'
                    : 'Mark as Awarded — use after pricing team approves this supplier\'s submission'
                }
                className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-colors
                  ${supplier.status === 'Complete' || supplier.status === 'Awarded'
                    ? 'bg-teal-600 text-white hover:bg-teal-700'
                    : 'bg-teal-100 text-teal-700 hover:bg-teal-200'
                  }`}
              >
                <CheckCircle className="w-3.5 h-3.5" />
                {supplier.status === 'Complete' || supplier.status === 'Awarded' ? '✓ Awarded' : 'Mark Awarded'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Email thread */}
      <div className="flex-1 overflow-y-auto px-6 py-5">
        {sortedEmails.length === 0 ? (
          <EmptyState
            icon={MailOpen}
            title="No messages yet"
            description="No emails have been exchanged with this supplier yet."
            size="sm"
          />
        ) : (
          <>
            {/* Extract Pricing strip — shown when any inbound email has extractable attachments */}
            {(() => {
              const extractable = sortedEmails.filter(e =>
                e.direction === 'inbound' && !e.isBounce &&
                (e.attachments?.length > 0 || (e.tags || []).some(t => ['Pricing','Response'].includes(t)))
              )
              if (extractable.length === 0) return null
              const target = extractable[0]
              const isExtr = extractingEmailId === target.id
              return (
                <div className="mb-4 flex items-center gap-3 bg-amber-50 border border-amber-200 rounded-xl px-4 py-2.5">
                  <Sparkles className="w-4 h-4 text-amber-600 flex-shrink-0" />
                  <span className="text-xs font-medium text-amber-800 flex-1">
                    Supplier pricing file detected
                  </span>
                  <button
                    onClick={() => onExtractPricing(target)}
                    disabled={!!extractingEmailId}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-amber-600 text-white hover:bg-amber-700 disabled:opacity-50 transition-colors"
                  >
                    {isExtr
                      ? <><Loader2 className="w-3 h-3 animate-spin" /> Extracting…</>
                      : <><Sparkles className="w-3 h-3" /> Extract Pricing to Working File</>
                    }
                  </button>
                </div>
              )
            })()}
            {sortedEmails.map((email, i) => (
              <EmailBubble
                key={email.id}
                email={email}
                isLatest={i === sortedEmails.length - 1}
                onFollowUp={() => onFollowUp(supplier)}
                onLogResponse={() => onLogResponse(supplier)}
                onExtractPricing={onExtractPricing}
                isExtracting={extractingEmailId === email.id}
                extractError={extractErrors?.[email.id] || null}
                extractMsg={extractingEmailId === email.id ? extractMsg : ''}
                onUpdateEmail={email.isBounce ? (newAddr) => onUpdateEmail?.(supplier, newAddr) : undefined}
              />
            ))}

            {/* PORTAL-DEMO: Reply button always shown for all suppliers */}
            <div className="flex justify-end pt-3 pb-2">
              <button
                onClick={() => onFollowUp(supplier)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-exl-orange hover:bg-exl-orange/90 text-white text-xs font-semibold rounded-xl transition-colors shadow-sm"
              >
                <span>↩</span> Reply
              </button>
            </div>
          </>
        )}
      </div>

      {/* Thread action bar */}
      <div className="px-6 py-3 border-t border-gray-200 bg-gray-50/60 flex-shrink-0 flex gap-2 flex-wrap items-center">
        {/* PORTAL-DEMO: all buttons shown — email flow intact, portal button additive */}
        <Button
          variant="primary"
          size="sm"
          icon={Plus}
          onClick={() => onLogResponse(supplier)}
        >
          Log Response from {supplier.supplierName.split(' ')[0]}
        </Button>
        {isPortal && threadUrl && (
          <a
            href={threadUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl border border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition-colors"
          >
            <Globe className="w-3.5 h-3.5" /> View Portal Thread
          </a>
        )}
        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => onFollowUp(supplier)}
          >
            ↩ Reply
          </Button>
          {isPortal && threadId && (
            <button
              onClick={() => onPortalReply(supplier, threadId)}
              className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl text-white hover:opacity-90 transition-opacity shadow-sm"
              style={{ backgroundColor: '#E05A2B' }}
            >
              <Globe className="w-3.5 h-3.5" /> Reply via Portal
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 8. Log Response Modal (supplier-context aware)
// ─────────────────────────────────────────────────────────
function LogResponseModal({ bid, prefilledSupplier, suppliers = [], onClose, onSaved }) {
  const fileRef   = useRef(null)

  // Allow user to select supplier when not pre-filled
  const [chosenSupplier, setChosenSupplier] = useState(prefilledSupplier || null)
  const activeSupplier = chosenSupplier

  const makeSubject = (sup) =>
    `RE: Solicitation: ${bid.id} ${bid.customer} — ${sup?.supplierName ?? ''}`

  const defaultSubject = makeSubject(prefilledSupplier)
  const [subject,   setSubject]   = useState(defaultSubject)
  const [date,      setDate]      = useState(new Date().toISOString().split('T')[0])
  const [body,      setBody]      = useState('')
  const [file,      setFile]      = useState(null)
  const [dragging,  setDragging]  = useState(false)
  const [saving,    setSaving]    = useState(false)
  const [analysing, setAnalysing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState(null)
  const [error,     setError]     = useState(null)

  const handleSupplierSelect = (e) => {
    const sup = suppliers.find(s => s.supplierId === e.target.value) || null
    setChosenSupplier(sup)
    setSubject(makeSubject(sup))
  }

  const handleFile = (f) => {
    if (!f) return
    const ext = f.name.split('.').pop().toLowerCase()
    if (!['pdf', 'xlsx', 'xls'].includes(ext)) { setError('PDF or Excel only'); return }
    setError(null)
    setFile(f)
    setAnalysisResult(null)
  }

  const handleAnalyse = async () => {
    if (!file) return
    setAnalysing(true)
    setError(null)
    try {
      const form = new FormData()
      form.append('file', file)
      if (prefilledSupplier?.supplierName) form.append('supplierName', prefilledSupplier.supplierName)
      const res  = await fetch('/api/analyse-response', { method: 'POST', body: form })
      const data = await res.json()
      setAnalysisResult(data)
    } catch (err) {
      setError('Analysis failed: ' + err.message)
    } finally {
      setAnalysing(false)
    }
  }

  const handleSave = async () => {
    if (!activeSupplier && suppliers.length > 0) {
      setError('Please select a supplier before saving.')
      return
    }
    setSaving(true)
    setError(null)
    try {
      // ── Upload pricing file first so extract-pricing can find it ──
      // POST /api/bids/:id/files saves with a deterministic name and
      // returns the path, which we store on the email record.
      let pricingFilePath = null
      if (file) {
        const fd = new FormData()
        fd.append('file', file)
        fd.append('docType', 'Pricing')
        const uploadRes  = await fetch(`/api/bids/${bid.id}/files`, { method: 'POST', body: fd })
        const uploadData = await uploadRes.json()
        if (!uploadRes.ok) {
          // Surface the error so the user knows the file didn't save —
          // without this the extract-pricing step would silently have no file.
          throw new Error(`File upload failed: ${uploadData.error || uploadRes.statusText}`)
        }
        if (uploadData.file?.path) {
          pricingFilePath = uploadData.file.path   // e.g. "uploads/B2600042_Pricing_<ts>.xlsx"
        }
      }

      const payload = {
        direction:     'inbound',
        supplierId:    activeSupplier?.supplierId    || null,
        supplierName:  activeSupplier?.supplierName  || null,
        supplierEmail: activeSupplier?.supplierEmail || null,
        from:          activeSupplier?.supplierEmail || 'supplier@unknown.com',
        to:            'COE.BIDS@sysco.com',
        bcc:           [],
        subject:       subject || defaultSubject,
        body,
        attachments:    file ? [file.name] : [],
        pricingFilePath,                              // disk path for extract-pricing
        tags:          ['Response', ...(file ? ['Pricing'] : [])],
        date:          new Date(date).toISOString(),
      }
      const emailRes  = await fetch(`/api/bids/${bid.id}/emails`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(payload),
      })
      const emailData = await emailRes.json()
      if (!emailRes.ok) throw new Error(emailData.error || 'Save failed')

      // Persist analysis result to the email record
      if (analysisResult) {
        await fetch(`/api/bids/${bid.id}/emails/${emailData.email.id}/analysis`, {
          method:  'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ analysisResult }),
        }).catch(() => {}) // best-effort
      }

      onSaved({ ...emailData.email, analysisResult })
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange bg-white'

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-exl-navy flex-shrink-0">
          <div>
            <h3 className="text-white font-bold text-sm">
              {prefilledSupplier ? `Log Response from ${prefilledSupplier.supplierName}` : 'Log Supplier Response'}
            </h3>
            {prefilledSupplier && (
              <p className="text-white/60 text-xs mt-0.5">{prefilledSupplier.supplierEmail}</p>
            )}
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <div className="px-6 py-5 space-y-4 overflow-y-auto flex-1">

          {/* Supplier selector or read-only chip */}
          {prefilledSupplier ? (
            <div className="flex items-center gap-3 bg-exl-navy/5 border border-exl-navy/20 rounded-lg px-3 py-2.5">
              <Mail className="w-4 h-4 text-exl-navy flex-shrink-0" />
              <div>
                <p className="text-xs font-semibold text-exl-navy">{prefilledSupplier.supplierName}</p>
                <p className="text-xs text-gray-500">{prefilledSupplier.supplierEmail}</p>
              </div>
              <span className="ml-auto text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">Pre-selected</span>
            </div>
          ) : suppliers.length > 0 ? (
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Supplier</label>
              <select
                value={chosenSupplier?.supplierId ?? ''}
                onChange={handleSupplierSelect}
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange bg-white"
              >
                <option value="">— Select supplier —</option>
                {suppliers.map(s => (
                  <option key={s.supplierId} value={s.supplierId}>
                    {s.supplierName}{s.isBroker ? ' (Broker)' : ''}
                  </option>
                ))}
              </select>
              {chosenSupplier && (
                <p className="text-xs text-gray-400 mt-1">{chosenSupplier.supplierEmail}</p>
              )}
            </div>
          ) : null}

          {/* Subject */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Email Subject</label>
            <input type="text" value={subject} onChange={e => setSubject(e.target.value)} className={inputCls} />
          </div>

          {/* Date */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Date Received</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className={inputCls} />
          </div>

          {/* Body */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Email Body</label>
            <textarea rows={4} value={body} onChange={e => setBody(e.target.value)}
              placeholder="Paste the supplier's email body here…"
              className={`${inputCls} resize-none`} />
          </div>

          {/* File */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">
              Pricing File <span className="text-gray-400 font-normal normal-case">(optional — triggers AI analysis)</span>
            </label>
            <div
              onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => { e.preventDefault(); setDragging(false); handleFile(e.dataTransfer.files[0]) }}
              onClick={() => fileRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
                file      ? 'border-emerald-400 bg-emerald-50'
                : dragging ? 'border-exl-orange bg-exl-orange/5'
                : 'border-gray-200 hover:border-exl-orange/50'
              }`}
            >
              <input ref={fileRef} type="file" accept=".pdf,.xlsx,.xls" className="hidden"
                onChange={(e) => handleFile(e.target.files[0])} />
              {file ? (
                <div className="flex items-center justify-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  <span className="text-sm font-medium text-emerald-800">{file.name}</span>
                  <button onClick={(e) => { e.stopPropagation(); setFile(null); setAnalysisResult(null) }}
                    className="text-gray-400 hover:text-red-500">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <p className="text-sm text-gray-500">Drop PDF or Excel here, or click to browse</p>
              )}
            </div>
            {file && !analysisResult && (
              <button
                onClick={handleAnalyse}
                disabled={analysing}
                className="mt-2 w-full flex items-center justify-center gap-1.5 py-2 bg-exl-orange hover:bg-exl-orange/90 text-white text-xs font-semibold rounded-lg transition-colors disabled:opacity-50"
              >
                {analysing
                  ? <><Loader className="w-3.5 h-3.5 animate-spin" /> Analysing with AI…</>
                  : <><Flag className="w-3.5 h-3.5" /> Analyse Pricing File</>}
              </button>
            )}
          </div>

          {/* Analysis preview */}
          {analysisResult && (
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Analysis Preview</p>
              <AnalysisCard analysis={analysisResult} />
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />{error}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 px-6 py-4 flex gap-3 flex-shrink-0">
          <button onClick={onClose} className="btn-secondary flex-1 text-sm">Cancel</button>
          <button onClick={handleSave} disabled={saving || analysing}
            className="btn-primary flex-1 flex items-center justify-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed">
            {saving
              ? <><Loader className="w-4 h-4 animate-spin" /> Saving…</>
              : <><CheckCircle className="w-4 h-4" /> Save Response</>}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 9. Follow-up Composer Modal
// ─────────────────────────────────────────────────────────
function FollowUpComposer({ bid, supplier, onClose, onSent }) {
  // Derive subject from first outbound email in this supplier's thread
  const firstOutbound = (supplier?.emails ?? [])
    .filter(e => e.direction === 'outbound')
    .sort((a, b) => new Date(a.date) - new Date(b.date))[0]

  const defaultSubject = firstOutbound
    ? `Re: ${firstOutbound.subject}`
    : `Re: Solicitation ${bid.id} ${bid.customer}`

  const greeting = new Date().getHours() < 12 ? 'morning' : 'afternoon'

  const defaultBody =
`Good ${greeting},

Thank you for reaching out regarding ${bid.customer}.

[Type your message here...]

Please don't hesitate to contact us if you need anything further.

Sysco Bid COE
COE.BIDS@sysco.com`

  const [subject, setSubject] = useState(defaultSubject)
  const [body,    setBody]    = useState(defaultBody)
  const [sending, setSending] = useState(false)
  const [error,   setError]   = useState(null)

  const handleSend = async () => {
    setSending(true)
    setError(null)
    try {
      // 1. Send the follow-up email
      const emailRes = await fetch(`/api/bids/${bid.id}/emails`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          direction:     'outbound',
          supplierId:    supplier.supplierId,
          supplierName:  supplier.supplierName,
          supplierEmail: supplier.supplierEmail,
          from:          'COE.BIDS@sysco.com',
          to:            supplier.supplierEmail,
          bcc:           [supplier.supplierEmail],
          subject, body,
          attachments:   [],
          tags:          ['Reply'],
        }),
      })
      const emailData = await emailRes.json()
      if (!emailRes.ok) throw new Error([emailData.error, emailData.hint].filter(Boolean).join(' — '))

      // 2. Update this supplier's status to "Follow-up Sent"
      try {
        const bidRes    = await fetch(`/api/bids/${bid.id}`)
        const latestBid = await bidRes.json()
        const today     = new Date().toISOString().split('T')[0]
        const updated   = (latestBid.solicitedSuppliers || []).map(s =>
          s.supplierId === supplier.supplierId
            ? { ...s, status: 'Follow-up Sent', lastActivity: today }
            : s
        )
        await fetch(`/api/bids/${bid.id}`, {
          method:  'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ solicitedSuppliers: updated }),
        })
      } catch { /* best-effort status update */ }

      onSent(`Reply sent to ${supplier.supplierName}`)
    } catch (err) {
      setError(err.message)
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-exl-navy flex-shrink-0">
          <div>
            <h3 className="text-white font-bold text-sm">Reply to Supplier</h3>
            {supplier && <p className="text-white/60 text-xs mt-0.5">To: {supplier.supplierName}</p>}
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-gray-100">

          {/* TO — read-only */}
          <div className="px-6 py-3">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1.5">To</p>
            <p className="text-sm text-gray-700 bg-gray-50 rounded-lg px-3 py-2 border border-gray-200">
              {supplier?.supplierName} &lt;{supplier?.supplierEmail}&gt;
            </p>
          </div>

          {/* Subject — editable */}
          <div className="px-6 py-3">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1.5">Subject</p>
            <input
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full text-sm font-medium outline-none bg-transparent border-0 focus:ring-0"
            />
          </div>

          {/* Body — editable */}
          <div className="px-6 py-4">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">Message</p>
            <textarea
              rows={13}
              value={body}
              onChange={e => setBody(e.target.value)}
              className="w-full text-sm text-gray-700 outline-none resize-none leading-relaxed font-sans"
            />
          </div>
        </div>

        {/* Error — stays visible, modal stays open */}
        {error && (
          <div className="px-6 py-2.5 bg-red-50 border-t border-red-100 flex items-center gap-2 text-xs text-red-700 flex-shrink-0">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-4 flex gap-3 bg-gray-50 border-t border-gray-200 flex-shrink-0">
          <button onClick={onClose} className="btn-secondary flex-1 text-sm">Cancel</button>
          <button
            onClick={handleSend}
            disabled={sending}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-exl-orange hover:bg-exl-orange/90 text-white font-semibold text-sm rounded-xl transition-colors disabled:opacity-50"
          >
            {sending
              ? <><Loader className="w-4 h-4 animate-spin" /> Sending…</>
              : <><Send className="w-4 h-4" /> Send Reply</>
            }
          </button>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 10. Toast
// ─────────────────────────────────────────────────────────
function Toast({ message, onDone, type = 'success', duration = 3000 }) {
  useEffect(() => { const t = setTimeout(onDone, duration); return () => clearTimeout(t) }, [])
  const bg = type === 'neutral' ? 'bg-gray-600' : 'bg-emerald-700'
  return (
    <div className={`fixed top-5 right-6 ${bg} text-white text-sm font-semibold px-5 py-3 rounded-xl shadow-xl flex items-center gap-2.5`} style={{ zIndex: 9998 }}>
      <CheckCircle className="w-4 h-4 flex-shrink-0" />{message}
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 10b. Portal Reply Modal (COE → supplier via portal thread)
// ─────────────────────────────────────────────────────────
function PortalReplyModal({ bid, supplier, threadId, onClose, onSent }) {
  const [body,    setBody]    = useState('')
  const [sending, setSending] = useState(false)
  const [error,   setError]   = useState(null)

  const threadUrl = getThreadUrl(bid.id, threadId)

  const handleSend = async () => {
    if (!body.trim()) return
    setSending(true)
    setError(null)
    try {
      const res  = await fetch(`/api/bids/${bid.id}/portal-reply`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          threadId,
          message:       body.trim(),
          supplierEmail: supplier.supplierEmail,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Send failed')
      onSent(`Reply sent to ${supplier.supplierName} via portal`)
    } catch (err) {
      setError(err.message)
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 bg-exl-navy flex-shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-400" />
              <h3 className="text-white font-bold text-sm">Reply via Supplier Portal</h3>
            </div>
            <p className="text-white/60 text-xs mt-0.5">To: {supplier.supplierName} · {supplier.supplierEmail}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {/* Notice */}
          <div className="flex items-start gap-2.5 px-3.5 py-3 bg-emerald-50 border border-emerald-100 rounded-xl text-xs">
            <Globe className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div className="text-emerald-800">
              <p className="font-semibold mb-0.5">🌐 This reply will appear in the supplier's portal thread AND be sent to their email</p>
              <p className="text-emerald-600">
                Supplier portal:&nbsp;
                <a href={threadUrl} target="_blank" rel="noopener noreferrer"
                   className="font-mono font-semibold hover:underline">
                  {threadUrl.replace(PORTAL_BASE, '')}
                </a>
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Message</label>
            <textarea
              autoFocus
              rows={7}
              value={body}
              onChange={e => setBody(e.target.value)}
              placeholder="Type your reply to the supplier…"
              className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange resize-none"
            />
            <p className="text-xs text-gray-400 mt-1">
              Your reply will be saved to the portal thread and emailed to the supplier.
            </p>
          </div>

          {error && (
            <div className="flex items-start gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />{error}
            </div>
          )}
        </div>

        <div className="border-t border-gray-200 px-6 py-4 flex gap-3 bg-gray-50 flex-shrink-0">
          <button onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button
            onClick={handleSend}
            disabled={sending || !body.trim()}
            className="btn-primary flex-1 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {sending
              ? <><Loader className="w-4 h-4 animate-spin" /> Sending…</>
              : <><Globe className="w-4 h-4" /> Send via Portal</>
            }
          </button>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// 11. Main EmailRepoTab
// ─────────────────────────────────────────────────────────
export default function EmailRepoTab({ bid, onSwitchTab, onResponseLogged }) {
  const [groupedData,      setGroupedData]      = useState(null)
  const [loading,          setLoading]          = useState(true)
  const [activeFilter,     setActiveFilter]     = useState(null)   // null = All
  const [selectedId,       setSelectedId]       = useState('__solicitation__')
  const [showLog,          setShowLog]          = useState(false)
  const [logSupplier,      setLogSupplier]      = useState(null)   // prefilled supplier
  const [followUpCtx,      setFollowUpCtx]      = useState(null)   // { supplier }
  const [portalReplyCtx,   setPortalReplyCtx]   = useState(null)   // { supplier, threadId }
  const [awardEmailCtx,    setAwardEmailCtx]    = useState(null)   // { supplier } — confirm award email prompt
  const [sendingAwardEmail, setSendingAwardEmail] = useState(false)
  const [awardModalStep,   setAwardModalStep]   = useState('confirm') // 'confirm' | 'edit'
  const [awardEmailDraft,  setAwardEmailDraft]  = useState({ to: '', subject: '', body: '' })
  const [awardAttachments, setAwardAttachments] = useState([])
  const [awardNotifiedMap, setAwardNotifiedMap] = useState({})      // { supplierId → 'Jun 12' }

  // ── Award modal drag state ────────────────────────────────
  const awardDragState   = useRef({ dragging: false, startX: 0, startY: 0, origX: 0, origY: 0 })
  const [awardOffset,    setAwardOffset]    = useState({ x: 0, y: 0 })
  const [awardDragging,  setAwardDragging]  = useState(false)

  useEffect(() => {
    const onMouseMove = (e) => {
      if (!awardDragState.current.dragging) return
      setAwardOffset({
        x: awardDragState.current.origX + e.clientX - awardDragState.current.startX,
        y: awardDragState.current.origY + e.clientY - awardDragState.current.startY,
      })
    }
    const onMouseUp = () => { awardDragState.current.dragging = false; setAwardDragging(false) }
    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('mouseup',   onMouseUp)
    return () => { window.removeEventListener('mousemove', onMouseMove); window.removeEventListener('mouseup', onMouseUp) }
  }, [])

  const onAwardHeaderMouseDown = (e) => {
    if (e.target.closest('button')) return
    awardDragState.current = { dragging: true, startX: e.clientX, startY: e.clientY, origX: awardOffset.x, origY: awardOffset.y }
    setAwardDragging(true)
    e.preventDefault()
  }
  const [toast,            setToast]            = useState(null)
  const [toastType,        setToastType]        = useState('success')

  // ── Pricing extraction state ──
  const [extractingEmailId, setExtractingEmailId] = useState(null)   // email ID currently being extracted
  const [extractErrors,     setExtractErrors]     = useState({})      // { emailId → error message }
  const [extractMsg,        setExtractMsg]        = useState('')      // progressive message shown under button
  const [extractResult,     setExtractResult]     = useState(null)    // AI extraction result for modal

  // ── Fetch grouped data ──
  // Also fetches the bid record so we can merge inConsideration + Awarded status
  // from solicitedSuppliers — the by-supplier endpoint only groups emails and
  // doesn't include those fields.
  const fetchData = async () => {
    try {
      const [emailRes, bidRes] = await Promise.all([
        fetch(`/api/bids/${bid.id}/emails/by-supplier`),
        fetch(`/api/bids/${bid.id}`),
      ])
      const data    = await emailRes.json()
      const bidData = await bidRes.json()

      // Build a lookup from the bid's solicitedSuppliers so we can overlay
      // inConsideration and status onto each grouped-email supplier row.
      const solMap = {}
      ;(bidData.solicitedSuppliers || []).forEach(s => { solMap[s.supplierId] = s })

      const merged = {
        ...data,
        suppliers: (data.suppliers || []).map(s => ({
          ...s,
          inConsideration: solMap[s.supplierId]?.inConsideration ?? false,
          // Keep Awarded/Complete status from solicitedSuppliers if present
          status: solMap[s.supplierId]?.status ?? s.status,
        })),
      }
      setGroupedData(merged)
      if (!data.solicitation && data.suppliers?.length > 0) {
        setSelectedId(data.suppliers[0].supplierId)
      }
    } catch { }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [bid.id])

  // ── Handlers ──
  const handleLogResponse = (supplier = null) => {
    setLogSupplier(supplier)
    setShowLog(true)
  }

  const handleSaved = async (newEmail) => {
    setShowLog(false)
    setLogSupplier(null)
    setToast('Response logged successfully')

    // Increment responsesReceived on the bid (optimistic + persisted)
    const newCount = (bid.responsesReceived || 0) + 1
    try {
      await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ responsesReceived: newCount }),
      })
    } catch { /* best-effort */ }
    onResponseLogged?.(newCount)   // update parent bid state for tab badge

    // Refresh grouped email data and navigate to supplier thread
    fetchData()
    if (newEmail.supplierId) setSelectedId(newEmail.supplierId)
  }

  const handlePortalReply = (supplier, threadId) => {
    setPortalReplyCtx({ supplier, threadId })
  }

  const handleFollowUp = (supplier) => {
    setFollowUpCtx({ supplier })
  }

  // ── Pricing extraction from email ──
  const handleExtractPricing = async (email) => {
    const EXTRACT_MESSAGES = [
      '📄 Reading attachment...',
      '🤖 AI analyzing pricing data...',
      '🔗 Matching to bid line items...',
    ]
    setExtractingEmailId(email.id)
    setExtractErrors(prev => ({ ...prev, [email.id]: null }))
    setExtractMsg(EXTRACT_MESSAGES[0])
    const t1 = setTimeout(() => setExtractMsg(EXTRACT_MESSAGES[1]), 1500)
    const t2 = setTimeout(() => setExtractMsg(EXTRACT_MESSAGES[2]), 3000)
    try {
      const [res] = await Promise.all([
        fetch(`/api/bids/${bid.id}/emails/${email.id}/extract-pricing`, { method: 'POST' }),
        new Promise(r => setTimeout(r, 800)), // minimum 800ms
      ])
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Extraction failed')
      setExtractResult(data)
    } catch (err) {
      setExtractErrors(prev => ({ ...prev, [email.id]: err.message }))
    } finally {
      clearTimeout(t1); clearTimeout(t2)
      setExtractingEmailId(null)
      setExtractMsg('')
    }
  }

  const handleUpdateEmail = async (supplier, newAddr) => {
    try {
      const bidRes    = await fetch(`/api/bids/${bid.id}`)
      const latestBid = await bidRes.json()
      const today     = new Date().toISOString().split('T')[0]
      const updatedSuppliers = (latestBid.solicitedSuppliers || []).map(s =>
        s.supplierId === supplier.supplierId
          ? { ...s, supplierEmail: newAddr, email: newAddr, status: 'Follow-up Sent',
              hasIssues: false, issueType: null, bouncedAt: null, lastActivity: today }
          : s
      )
      await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ solicitedSuppliers: updatedSuppliers }),
      })
      // Send re-solicitation email to the new address
      await fetch(`/api/bids/${bid.id}/emails`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          direction:     'outbound',
          supplierId:    supplier.supplierId,
          supplierName:  supplier.supplierName,
          supplierEmail: newAddr,
          from:          'COE.BIDS@sysco.com',
          to:            newAddr,
          subject:       `Re-solicitation: ${bid.customer} — ${bid.id} | Pricing Request`,
          body:          `Good morning,\n\nWe had trouble reaching you at your previous email address. We're resending this pricing request to your updated contact.\n\nPlease provide pricing for ${bid.customer} (${bid.id}) by ${bid.internalDue || bid.customerDue || 'the deadline'}.\n\nThank you,\n\nSysco Bid COE\nCOE.BIDS@sysco.com`,
          tags:          ['Re-solicit'],
          attachments:   [],
        }),
      })
      setToast(`Email updated to ${newAddr} — re-solicitation sent`)
      fetchData()
    } catch (err) {
      setToast(`Update failed: ${err.message}`)
    }
  }

  const handleFollowUpSent = (msg) => {
    setFollowUpCtx(null)
    setToast(msg)
    fetchData()
  }

  const handleMarkAwarded = async (supplierId) => {
    const current = (groupedData?.suppliers ?? []).find(s => s.supplierId === supplierId)
    if (!current) return
    const isCurrentlyAwarded = current.status === 'Complete' || current.status === 'Awarded'
    const existing = bid.completedSuppliers || []
    const updated  = isCurrentlyAwarded
      ? existing.filter(id => id !== supplierId)
      : [...existing, supplierId]
    // Also update solicitedSuppliers status so the left panel badge reflects the change
    try {
      const bidRes    = await fetch(`/api/bids/${bid.id}`)
      const latestBid = await bidRes.json()
      const today     = new Date().toISOString().split('T')[0]
      const updatedSuppliers = (latestBid.solicitedSuppliers || []).map(s =>
        s.supplierId === supplierId
          ? { ...s, status: isCurrentlyAwarded ? 'Responded' : 'Awarded', lastActivity: today }
          : s
      )
      await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ completedSuppliers: updated, solicitedSuppliers: updatedSuppliers }),
      })
    } catch {
      await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ completedSuppliers: updated }),
      })
    }
    await fetchData()
    // Show All view so the awarded supplier stays visible in the left panel,
    // and select their thread so the right panel opens on them.
    setActiveFilter(null)
    setSelectedId(supplierId)
    if (!isCurrentlyAwarded) {
      setAwardEmailCtx({ supplier: current, previousStatus: current.status })
    } else {
      setToast(`Awarded status removed from ${current.supplierName}`)
    }
  }

  const handleSendAwardEmail = async () => {
    if (!awardEmailCtx?.supplier) return
    const { supplier } = awardEmailCtx
    setSendingAwardEmail(true)
    try {
      const formData = new FormData()
      formData.append('supplierId',    supplier.supplierId)
      formData.append('supplierName',  supplier.supplierName)
      formData.append('supplierEmail', supplier.emails?.[0]?.from || '')
      formData.append('to',            awardEmailDraft.to)
      formData.append('subject',       awardEmailDraft.subject)
      formData.append('body',          awardEmailDraft.body)
      awardAttachments.forEach(file => formData.append('attachments', file))

      await fetch(`/api/bids/${bid.id}/send-award-email`, { method: 'POST', body: formData })

      const dateLabel = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      setAwardNotifiedMap(prev => ({ ...prev, [supplier.supplierId]: dateLabel }))
      setToastType('success')
      setToast(
        awardAttachments.length > 0
          ? `📧 Award notification sent with ${awardAttachments.length} attachment${awardAttachments.length > 1 ? 's' : ''}`
          : `📧 Award notification sent to ${awardEmailDraft.to || supplier.emails?.[0]?.from || supplier.supplierName}`
      )
    } catch {
      setToastType('success')
      setToast(`🏆 ${supplier.supplierName} marked Awarded`)
    } finally {
      setSendingAwardEmail(false)
      setAwardEmailCtx(null)
      setAwardModalStep('confirm')
      setAwardAttachments([])
      fetchData()
    }
  }

  const handleToggleInConsideration = async (supplierId) => {
    const current = (groupedData?.suppliers ?? []).find(s => s.supplierId === supplierId)
    if (!current) return
    const nowFlagged  = !current.inConsideration
    const newStatus   = nowFlagged ? 'Under Consideration' : 'Responded'

    // Optimistic update — flag turns orange immediately, no wait for API round-trip
    setGroupedData(prev => ({
      ...prev,
      suppliers: (prev.suppliers || []).map(s =>
        s.supplierId === supplierId
          ? { ...s, inConsideration: nowFlagged, status: newStatus }
          : s
      ),
    }))

    try {
      const bidRes    = await fetch(`/api/bids/${bid.id}`)
      const latestBid = await bidRes.json()
      const today     = new Date().toISOString().split('T')[0]
      const existing  = latestBid.solicitedSuppliers || []
      const idx       = existing.findIndex(s => s.supplierId === supplierId)
      let updatedSuppliers
      if (idx >= 0) {
        updatedSuppliers = existing.map(s =>
          s.supplierId === supplierId
            ? { ...s, inConsideration: nowFlagged, status: newStatus, lastActivity: today }
            : s
        )
      } else {
        // Supplier not yet in solicitedSuppliers — append new entry
        updatedSuppliers = [
          ...existing,
          {
            supplierId,
            supplierName:  current.supplierName,
            supplierEmail: current.supplierEmail,
            inConsideration: nowFlagged,
            status: newStatus,
            lastActivity: today,
          },
        ]
      }
      await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ solicitedSuppliers: updatedSuppliers }),
      })
    } catch {
      // Revert optimistic update on failure
      setGroupedData(prev => ({
        ...prev,
        suppliers: (prev.suppliers || []).map(s =>
          s.supplierId === supplierId
            ? { ...s, inConsideration: !nowFlagged, status: current.status }
            : s
        ),
      }))
    }
    setToast(nowFlagged
      ? `🚩 ${current.supplierName} — Under Consideration`
      : `${current.supplierName} removed from consideration`)
  }

  // ── Filtered + sorted suppliers ──
  const STATUS_PRIORITY = { Awarded: 1, 'Under Consideration': 2, Responded: 3, 'Issues Found': 4, 'Follow-up Sent': 5, Solicited: 6, Awaiting: 7, Pending: 8 }
  const allSuppliers = groupedData?.suppliers ?? []
  const filteredSuppliers = (activeFilter
    ? allSuppliers.filter(s => {
        if (activeFilter === 'Responded')        return ['Responded', 'Follow-up Sent', 'Under Consideration', 'Issues Found', 'Awarded', 'Complete'].includes(s.status)
        if (activeFilter === 'Awarded')          return s.status === 'Complete' || s.status === 'Awarded'
        if (activeFilter === 'In Consideration') return s.inConsideration === true
        return s.status === activeFilter
      })
    : allSuppliers
  ).sort((a, b) => (STATUS_PRIORITY[a.status] ?? 9) - (STATUS_PRIORITY[b.status] ?? 9))

  const selectedSupplier = allSuppliers.find(s => s.supplierId === selectedId) ?? null

  // ── Loading ──
  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader className="w-5 h-5 animate-spin text-exl-orange mr-3" />
        <span className="text-sm text-gray-500">Loading email thread…</span>
      </div>
    )
  }

  // ── Empty (no solicitation + no suppliers) ──
  if (!groupedData?.solicitation && allSuppliers.length === 0) {
    return (
      <>
        <div className="card">
          <EmptyState
            icon={Mail}
            title="No emails yet"
            description="Send a solicitation to suppliers to start receiving pricing responses. Replies will appear here automatically."
            action={{ label: 'Go to Supplier List', icon: Users, onClick: () => onSwitchTab?.('suppliers') }}
            secondaryAction={{ label: 'Log a response', onClick: () => handleLogResponse() }}
            size="md"
          />
        </div>
        {showLog && <LogResponseModal bid={bid} prefilledSupplier={logSupplier} suppliers={allSuppliers} onClose={() => setShowLog(false)} onSaved={handleSaved} />}
        {toast && <Toast message={toast} onDone={() => setToast(null)} />}
      </>
    )
  }

  return (
    <>
      {/* ── Page header ── */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-base font-semibold text-gray-900 flex items-center gap-2">
          Email Repository
          <span className="text-xs bg-gray-100 text-gray-600 font-semibold px-2 py-0.5 rounded-full">
            {allSuppliers.reduce((s, x) => s + x.emailCount, 0) + (groupedData?.solicitation ? 1 : 0)} emails
          </span>
        </h2>
        <div className="flex items-center gap-2">
          <button onClick={fetchData} className="text-gray-400 hover:text-gray-600 transition-colors p-1.5 rounded-lg hover:bg-gray-100">
            <RefreshCw className="w-4 h-4" />
          </button>
          <Button variant="primary" size="md" icon={Plus} onClick={() => handleLogResponse()}>
            Log Supplier Response
          </Button>
        </div>
      </div>

      {/* ── Summary bar ── */}
      <SummaryBar
        suppliers={allSuppliers}
        activeFilter={activeFilter}
        onFilter={setActiveFilter}
      />

      {/* ── Two-panel layout ── */}
      <div className="flex border border-gray-200 rounded-xl overflow-hidden bg-white" style={{ minHeight: 580 }}>

        {/* Left panel */}
        <div className="w-72 flex-shrink-0 border-r border-gray-200 overflow-y-auto flex flex-col">
          <SolicitationRow
            solicitation={groupedData?.solicitation}
            active={selectedId === '__solicitation__'}
            onClick={() => setSelectedId('__solicitation__')}
          />
          {filteredSuppliers.length === 0 ? (
            <div className="flex-1 flex items-center justify-center">
              <EmptyState
                icon={CheckCircle}
                title="No suppliers here"
                description="No suppliers match this filter."
                size="sm"
              />
            </div>
          ) : (
            filteredSuppliers.map(s => (
              <SupplierRow
                key={s.supplierId}
                supplier={s}
                active={selectedId === s.supplierId}
                onClick={() => setSelectedId(s.supplierId)}
                notifDate={awardNotifiedMap[s.supplierId]}
              />
            ))
          )}
        </div>

        {/* Right panel */}
        {selectedId === '__solicitation__' && groupedData?.solicitation ? (
          <SolicitationDetail solicitation={groupedData.solicitation} suppliers={groupedData.suppliers ?? []} />
        ) : selectedSupplier ? (
          <SupplierThread
            supplier={selectedSupplier}
            bid={bid}
            onFollowUp={handleFollowUp}
            onLogResponse={handleLogResponse}
            onMarkAwarded={handleMarkAwarded}
            onMarkInConsideration={handleToggleInConsideration}
            onExtractPricing={handleExtractPricing}
            extractMsg={extractMsg}
            onPortalReply={handlePortalReply}
            extractingEmailId={extractingEmailId}
            extractErrors={extractErrors}
            onUpdateEmail={handleUpdateEmail}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-400 text-sm">
            <div className="text-center">
              <MailOpen className="w-10 h-10 mx-auto mb-3 text-gray-300" />
              <p>Select a supplier to view their thread</p>
            </div>
          </div>
        )}
      </div>

      {/* ── Modals ── */}
      {showLog && (
        <LogResponseModal
          bid={bid}
          prefilledSupplier={logSupplier}
          suppliers={allSuppliers}
          onClose={() => { setShowLog(false); setLogSupplier(null) }}
          onSaved={handleSaved}
        />
      )}
      {followUpCtx && (
        <FollowUpComposer
          bid={bid}
          supplier={followUpCtx.supplier}
          onClose={() => setFollowUpCtx(null)}
          onSent={handleFollowUpSent}
        />
      )}

      {/* PORTAL-DEMO: portal reply modal */}
      {portalReplyCtx && (
        <PortalReplyModal
          bid={bid}
          supplier={portalReplyCtx.supplier}
          threadId={portalReplyCtx.threadId}
          onClose={() => setPortalReplyCtx(null)}
          onSent={(msg) => {
            setPortalReplyCtx(null)
            fetchData()
            setToast(msg)
          }}
        />
      )}

      {/* ── Pricing extraction preview modal ── */}
      {extractResult && (
        <PricingExtractModal
          bid={bid}
          result={extractResult}
          onClose={() => setExtractResult(null)}
          onSaved={(count, supplierName, flagged) => {
            setExtractResult(null)
            const base = `✓ ${count} item${count !== 1 ? 's' : ''} saved to Working File from ${supplierName}`
            setToast(flagged ? `${base} · 🚩 ${supplierName} marked Under Consideration` : base)
            if (flagged) fetchData()
          }}
        />
      )}
      {/* ── Award email confirmation modal (two-step) ── */}
      {awardEmailCtx && (() => {
        const sup        = awardEmailCtx.supplier
        const supplierEmail = sup.emails?.[0]?.from || sup.supplierEmail || ''
        const closeModal = async () => {
          // Revert the Awarded status — user cancelled without sending
          try {
            const bidRes    = await fetch(`/api/bids/${bid.id}`)
            const latestBid = await bidRes.json()
            const prevStatus = awardEmailCtx.previousStatus || 'Responded'
            const updatedSuppliers = (latestBid.solicitedSuppliers || []).map(s =>
              s.supplierId === sup.supplierId ? { ...s, status: prevStatus } : s
            )
            const updatedCompleted = (latestBid.completedSuppliers || []).filter(id => id !== sup.supplierId)
            await fetch(`/api/bids/${bid.id}`, {
              method:  'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body:    JSON.stringify({ solicitedSuppliers: updatedSuppliers, completedSuppliers: updatedCompleted }),
            })
          } catch { /* best-effort */ }
          await fetchData()
          setAwardEmailCtx(null)
          setAwardModalStep('confirm')
          setAwardAttachments([])
          setAwardOffset({ x: 0, y: 0 })
        }
        const handleAttachmentAdd = (e) => {
          setAwardAttachments(prev => [...prev, ...Array.from(e.target.files)])
          e.target.value = ''
        }
        const removeAttachment = (idx) => {
          setAwardAttachments(prev => prev.filter((_, i) => i !== idx))
        }

        return createPortal(
          <div
            style={{
              position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
              backgroundColor: 'rgba(0,0,0,0.5)',
              zIndex: 9999,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            {/* ── STEP 1: Confirm ── */}
            {awardModalStep === 'confirm' && (
              <div className="bg-white dark:bg-[#1E293B] rounded-xl shadow-2xl p-6 border border-gray-100 dark:border-gray-700" style={{ width: '480px', maxWidth: '90vw', transform: `translate(${awardOffset.x}px, ${awardOffset.y}px)` }}>
                {/* Trophy + title + close — draggable */}
                <div
                  className="flex items-start justify-between mb-5"
                  style={{ cursor: awardDragging ? 'grabbing' : 'grab' }}
                  onMouseDown={onAwardHeaderMouseDown}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center flex-shrink-0 text-xl">
                      🏆
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white text-base leading-tight">
                        {sup.supplierName} — Awarded
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
                        Send an award notification email to this supplier?
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={closeModal}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 ml-3 flex-shrink-0 p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    title="Cancel"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick info */}
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 mb-5 text-xs text-gray-500 dark:text-gray-400 space-y-1">
                  <p className="font-medium text-gray-700 dark:text-gray-300 mb-1">Email preview:</p>
                  <p>To: {supplierEmail || '—'}</p>
                  <p>Subject: Award Notification — {bid.customer} {bid.id}</p>
                </div>

                {/* Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setAwardEmailDraft(buildAwardEmailDraft({
                        supplierName:  sup.supplierName,
                        supplierEmail: supplierEmail,
                        bid,
                      }))
                      setAwardModalStep('edit')
                    }}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg font-medium text-sm text-white transition-colors hover:opacity-90"
                    style={{ backgroundColor: '#E05A2B' }}
                  >
                    <Mail className="w-3.5 h-3.5" /> Preview &amp; Edit Email
                  </button>
                  <button
                    onClick={() => {
                      // Skip = keep Awarded status, just don't send the email
                      setAwardEmailCtx(null)
                      setAwardModalStep('confirm')
                      setAwardAttachments([])
                      setToastType('neutral')
                      setToast('Award recorded — notification skipped')
                    }}
                    className="px-4 py-2.5 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-lg font-medium text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    Skip
                  </button>
                </div>
              </div>
            )}

            {/* ── STEP 2: Edit ── */}
            {awardModalStep === 'edit' && (
              <div style={{ width: '480px', minWidth: '380px', minHeight: '300px', maxWidth: '90vw', maxHeight: '90vh', resize: 'both', overflow: 'hidden', transform: `translate(${awardOffset.x}px, ${awardOffset.y}px)`, borderRadius: '0.75rem', boxShadow: '0 20px 40px -12px rgba(0,0,0,0.25)' }}>
              <div className="bg-white dark:bg-[#1E293B] rounded-xl shadow-xl p-6 border border-gray-100 dark:border-gray-700" style={{ width: '100%', height: '100%', overflow: 'auto', boxSizing: 'border-box' }}>
                {/* Header — draggable */}
                <div
                  className="flex items-start justify-between mb-5"
                  style={{ cursor: awardDragging ? 'grabbing' : 'grab' }}
                  onMouseDown={onAwardHeaderMouseDown}
                >
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white text-base">Award Notification Email</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Review and edit before sending</p>
                  </div>
                  <button onClick={closeModal} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 ml-4 flex-shrink-0">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* TO */}
                <div className="mb-3">
                  <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">To</label>
                  <input
                    type="email"
                    value={awardEmailDraft.to}
                    onChange={e => setAwardEmailDraft(d => ({ ...d, to: e.target.value }))}
                    className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-2 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B]"
                  />
                </div>

                {/* SUBJECT */}
                <div className="mb-3">
                  <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Subject</label>
                  <input
                    type="text"
                    value={awardEmailDraft.subject}
                    onChange={e => setAwardEmailDraft(d => ({ ...d, subject: e.target.value }))}
                    className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-2 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B]"
                  />
                </div>

                {/* ATTACHMENTS */}
                <div className="mb-4">
                  <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">
                    Attachments (optional)
                  </label>
                  {awardAttachments.map((file, i) => (
                    <div key={i} className="flex items-center gap-2 bg-gray-50 dark:bg-gray-800 rounded-lg px-3 py-2 mb-2 text-sm">
                      <Paperclip className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                      <span className="flex-1 truncate text-gray-700 dark:text-gray-300">{file.name}</span>
                      <span className="text-xs text-gray-400">{(file.size / 1024).toFixed(0)} KB</span>
                      <button type="button" onClick={() => removeAttachment(i)} className="text-gray-400 hover:text-red-500 ml-1">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                  <label className="flex items-center gap-2 px-3 py-2 border border-dashed border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer text-sm text-gray-500 dark:text-gray-400 hover:border-[#E05A2B] hover:text-[#E05A2B] transition-colors">
                    <Paperclip className="w-3.5 h-3.5" />
                    <span>Attach file</span>
                    <input type="file" multiple className="hidden" accept=".pdf,.xlsx,.xls,.doc,.docx,.csv" onChange={handleAttachmentAdd} />
                  </label>
                  <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">PDF, Excel, Word or CSV · Max 10 MB per file</p>
                </div>

                {/* BODY */}
                <div className="mb-5">
                  <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Body</label>
                  <textarea
                    rows={14}
                    value={awardEmailDraft.body}
                    onChange={e => setAwardEmailDraft(d => ({ ...d, body: e.target.value }))}
                    className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-2 text-sm font-mono dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B] resize-y"
                  />
                </div>

                {/* Footer buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => setAwardModalStep('confirm')}
                    className="flex items-center gap-1.5 px-4 py-2.5 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-lg font-medium text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    ← Back
                  </button>
                  <button
                    onClick={handleSendAwardEmail}
                    disabled={sendingAwardEmail || !awardEmailDraft.to.trim()}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg font-medium text-sm text-white disabled:opacity-50 transition-colors hover:opacity-90"
                    style={{ backgroundColor: '#E05A2B' }}
                  >
                    {sendingAwardEmail
                      ? <><Loader className="w-3.5 h-3.5 animate-spin" /> Sending…</>
                      : <><Mail className="w-3.5 h-3.5" /> Send Award Notification</>
                    }
                  </button>
                </div>
              </div>
              </div>
            )}
          </div>
        , document.body)
      })()}

      {toast && <Toast message={toast} onDone={() => setToast(null)} type={toastType} duration={toastType === 'neutral' ? 2000 : 3000} />}
    </>
  )
}
