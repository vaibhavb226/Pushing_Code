import React, { useState, useEffect, useMemo, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  FileSpreadsheet, Download, RefreshCw, CheckCircle, AlertTriangle,
  XCircle, Loader, Brain, ChevronDown, ChevronRight,
  Settings, Plus, Trash2, X,
} from 'lucide-react'
import { Button } from '../UI/Button'
import { EmptyState } from '../UI/EmptyState'

// ── Category abbreviation map ─────────────────────────────
const CA_MAP = {
  'Protein':   'PROT',
  'Dairy':     'DAIRY',
  'Produce':   'PROD',
  'Bakery':    'BKRY',
  'Grocery':   'GROC',
  'Beverage':  'BEV',
  'Paper':     'PPR',
  'Broker':    'BRKR',
  'M/MA':      'M/MA',
  'M/MA+Grain':'M/MA+G',
  'Grain':     'GRAIN',
  'Fruit':     'FRUIT',
  'Snack':     'SNACK',
}
function getCa(cat) {
  return CA_MAP[cat] || (cat || '').slice(0, 5).toUpperCase() || '—'
}

// ── Color constants ───────────────────────────────────────
const BLUE_BG   = { backgroundColor: '#EBF3FB' }
const YELLOW_BG = { backgroundColor: '#FEFCE8' }
const SUB_ROW_BG = { backgroundColor: '#F0F7FF' }

// ── Default column configs ────────────────────────────────
const DEFAULT_SUPPLIER_COLUMNS = [
  { id: 'supcRight',     label: 'SUPC',        visible: true, fixed: true  },
  { id: 'brandRight',    label: 'Brand',       visible: true               },
  { id: 'descRight',     label: 'Description', visible: true, fixed: true  },
  { id: 'trueVendor',    label: 'True Vendor', visible: true, fixed: true  },
  { id: 'suppliedPrice', label: 'Net $/cs',    visible: true, fixed: true  },
  { id: 'devType',       label: 'Dev Type',    visible: true               },
  { id: 'notes',         label: 'Notes',       visible: true               },
  { id: 'allw',          label: 'ALLW $',      visible: true               },
  { id: 'dl',            label: 'DL $',        visible: true               },
  { id: 'priceCase',     label: 'Net $/Case',  visible: true               },
  { id: 'openReview',    label: 'Open Rev.',   visible: true               },
  { id: 'confidence',    label: 'Confidence',  visible: true, fixed: true  },
]

const DEFAULT_INTERNAL_COLUMNS = [
  { id: 'awardDecision',    label: 'Award Decision',    visible: true, type: 'dropdown', options: ['', 'Awarded', 'Pending', 'Rejected', 'Under Review'] },
  { id: 'internalNotes',    label: 'Internal Notes',    visible: true, type: 'text' },
  { id: 'pricingScore',     label: 'Pricing Score',     visible: true, type: 'number' },
  { id: 'followUpRequired', label: 'Follow-up Required',visible: true, type: 'dropdown', options: ['', 'Yes', 'No', 'In Progress'] },
]

// ── Dev type options ──────────────────────────────────────
const DEV_TYPE_OPTIONS = ['ALLW', 'DL', 'NOI', 'COST']

// ── Empty cell placeholder ────────────────────────────────
const EMPTY = <span className="text-gray-300 text-xs">—</span>

// ── Confidence badge ──────────────────────────────────────
function ConfidenceBadge({ confidence, approved }) {
  if (approved) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">
        <CheckCircle className="w-3 h-3" /> Approved
      </span>
    )
  }
  if (!confidence && confidence !== 0) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-500 rounded-full text-xs font-semibold">
        No Response
      </span>
    )
  }
  if (confidence >= 90) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">
        <CheckCircle className="w-3 h-3" /> {confidence}%
      </span>
    )
  }
  if (confidence >= 75) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">
        <AlertTriangle className="w-3 h-3" /> {confidence}%
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-bold">
      <XCircle className="w-3 h-3" /> {confidence}%
    </span>
  )
}

// ── Dev type badge ────────────────────────────────────────
function DevTypeBadge({ type }) {
  if (!type) return <span className="text-gray-300 text-xs">—</span>
  const colours =
    type === 'ALLW' ? 'bg-emerald-100 text-emerald-700' :
    type === 'DL'   ? 'bg-blue-100 text-blue-700' :
    type === 'NOI'  ? 'bg-purple-100 text-purple-700' :
    'bg-gray-100 text-gray-600'
  return (
    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-bold ${colours}`}>
      {type}
    </span>
  )
}

// ── Award Decision badge ──────────────────────────────────
function AwardBadge({ value }) {
  if (!value) return EMPTY
  const colours =
    value === 'Awarded'      ? 'bg-emerald-100 text-emerald-700' :
    value === 'Rejected'     ? 'bg-red-100 text-red-700' :
    value === 'Pending'      ? 'bg-amber-100 text-amber-700' :
    value === 'Under Review' ? 'bg-blue-100 text-blue-700' :
    'bg-gray-100 text-gray-600'
  return (
    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${colours}`}>
      {value}
    </span>
  )
}

// ── Compliance pills ──────────────────────────────────────
function CompliancePills({ item }) {
  const pills = []
  if (item.buyAmerican)    pills.push(<span key="ba"  className="px-1 py-0.5 bg-red-100 text-red-700 text-xs rounded font-semibold">BA</span>)
  if (item.childNutrition) pills.push(<span key="cn"  className="px-1 py-0.5 bg-green-100 text-green-700 text-xs rounded font-semibold">CN</span>)
  if (item.pfsRequired)    pills.push(<span key="pfs" className="px-1 py-0.5 bg-purple-100 text-purple-700 text-xs rounded font-semibold">PFS</span>)
  if (item.exactSpec)      pills.push(<span key="es"  className="px-1 py-0.5 bg-amber-100 text-amber-700 text-xs rounded font-semibold">ES</span>)
  return pills.length > 0
    ? <div className="flex flex-wrap gap-0.5">{pills}</div>
    : <span className="text-gray-300 text-xs">—</span>
}

// ── CSV export ────────────────────────────────────────────
function exportCsv(lineItems, pricingMap, internalData, wfConfig, bidId) {
  const visIntCols = (wfConfig.internalColumns || []).filter(c => c.visible)
  const headers = [
    'Item #', 'SUPC', 'MPC Code', 'UOM', 'Volume', 'Pack', 'Size',
    'Brand', 'Description', 'CA', 'CW', 'STK Type',
    'Buy American', 'CN', 'PFS', 'Exact Spec',
    'Supp. SUPC', 'Supp. Brand', 'Supp. Description',
    'True Vendor', 'Net $/cs', 'Dev Type', 'Notes',
    'ALLW ($)', 'DL ($)', 'Net $/Case', 'Open Review', 'Confidence %',
    ...visIntCols.map(c => c.label),
  ]

  const rows = lineItems.map(li => {
    const p    = pricingMap[li.id]
    const intV = internalData[li.id] || {}
    return [
      li.bidItem, li.supc || '', li.mpcCode || '', li.unit || '', li.qty ?? '',
      li.pack || '', li.size || '', li.brand || '', li.description,
      getCa(li.category), li.cw || 'N', li.stkType || 'A',
      li.buyAmerican    ? 'Yes' : 'No',
      li.childNutrition ? 'Yes' : 'No',
      li.pfsRequired    ? 'Yes' : 'No',
      li.exactSpec      ? 'Yes' : 'No',
      li.supc       || '',
      li.brand      || '',
      li.description || '',
      p?.supplier_name  ?? li.trueVendor    ?? '',
      p?.supplied_price ?? li.suppliedPrice ?? '',
      p?.dev_type       ?? li.devType       ?? '',
      li.notes          ?? '',
      p?.allw           ?? li.allw          ?? '',
      p?.dl             ?? li.dl            ?? '',
      p?.price_case     ?? li.priceCase     ?? '',
      p ? (p.open_review === 'Y' ? 'Yes' : 'No') : (li.openReview ? 'Yes' : 'No'),
      p?.confidence     ?? li.confidence    ?? '',
      ...visIntCols.map(c => intV[c.id] ?? ''),
    ]
  })

  const csv  = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
  const blob = new Blob([csv], { type: 'text/csv' })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement('a')
  a.href     = url
  a.download = `${bidId}_WorkingFile_${new Date().toISOString().split('T')[0]}.csv`
  a.click()
  URL.revokeObjectURL(url)
}

// ── Customize panel — single column row ───────────────────
function ColumnRow({ col, onToggle, onRename, onRemove }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft]     = useState(col.label)
  const inputRef              = useRef(null)

  useEffect(() => { if (editing) inputRef.current?.focus() }, [editing])

  const commit = () => {
    if (draft.trim()) onRename(draft.trim())
    setEditing(false)
  }

  return (
    <div className="flex items-center gap-2 py-1.5 group">
      {/* Visible toggle */}
      <button onClick={onToggle} className="flex-shrink-0 w-4 h-4 flex items-center justify-center">
        {col.visible
          ? <div className="w-4 h-4 rounded border-2 border-exl-orange flex items-center justify-center" style={{ backgroundColor: '#E05A2B' }}>
              <CheckCircle className="w-2.5 h-2.5 text-white" style={{ strokeWidth: 3 }} />
            </div>
          : <div className="w-4 h-4 rounded border-2 border-gray-300" />
        }
      </button>

      {/* Label — click to rename */}
      {editing ? (
        <input
          ref={inputRef}
          value={draft}
          onChange={e => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={e => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(false) }}
          className="flex-1 text-xs border-b outline-none bg-transparent"
          style={{ borderColor: '#E05A2B' }}
        />
      ) : (
        <span
          className={`flex-1 text-xs cursor-pointer transition-colors hover:text-exl-orange ${col.visible ? 'text-gray-700' : 'text-gray-400 line-through'}`}
          onClick={() => { setDraft(col.label); setEditing(true) }}
          title="Click to rename"
        >
          {col.label}
        </span>
      )}

      {col.fixed && <span className="text-xs text-gray-300 flex-shrink-0 italic">fixed</span>}
      {col.type  && !col.fixed && <span className="text-xs text-gray-300 flex-shrink-0">{col.type}</span>}

      {onRemove && (
        <button onClick={onRemove} className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" title="Remove column">
          <Trash2 className="w-3 h-3 text-red-400 hover:text-red-600" />
        </button>
      )}
    </div>
  )
}

// ── Add column form ───────────────────────────────────────
function AddColumnForm({ onAdd, onCancel }) {
  const [name, setName] = useState('')
  const [type, setType] = useState('text')

  return (
    <div className="mt-2 p-3 bg-gray-50 rounded-xl border border-gray-200">
      <input
        value={name}
        onChange={e => setName(e.target.value)}
        placeholder="Column name"
        autoFocus
        className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 mb-2 outline-none"
        style={{ focusBorderColor: '#E05A2B' }}
        onFocus={e => e.target.style.borderColor = '#E05A2B'}
        onBlur={e => e.target.style.borderColor = ''}
        onKeyDown={e => { if (e.key === 'Enter' && name.trim()) onAdd(name.trim(), type) }}
      />
      <select
        value={type}
        onChange={e => setType(e.target.value)}
        className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 mb-2 outline-none bg-white"
      >
        <option value="text">Text</option>
        <option value="number">Number</option>
        <option value="dropdown">Dropdown</option>
      </select>
      <div className="flex gap-2">
        <button
          onClick={() => { if (name.trim()) onAdd(name.trim(), type) }}
          className="flex-1 py-1.5 rounded-lg text-xs font-semibold text-white"
          style={{ backgroundColor: '#E05A2B' }}
        >
          Add
        </button>
        <button
          onClick={onCancel}
          className="px-3 py-1.5 rounded-lg text-xs font-semibold text-gray-600 border border-gray-200 hover:bg-gray-50"
        >
          Cancel
        </button>
      </div>
    </div>
  )
}

// ── Customize Columns slide-in panel ─────────────────────
function CustomizePanel({ config, onClose, onSave }) {
  const [local, setLocal]     = useState(() => JSON.parse(JSON.stringify(config)))
  const [addingTo, setAddingTo] = useState(null) // 'supplierColumns' | 'internalColumns' | null

  const toggleCol = (section, id) =>
    setLocal(p => ({ ...p, [section]: p[section].map(c => c.id === id ? { ...c, visible: !c.visible } : c) }))

  const renameCol = (section, id, label) =>
    setLocal(p => ({ ...p, [section]: p[section].map(c => c.id === id ? { ...c, label } : c) }))

  const removeCol = (section, id) =>
    setLocal(p => ({ ...p, [section]: p[section].filter(c => c.id !== id) }))

  const addCol = (section, name, type) => {
    const id  = `custom_${Date.now()}`
    const col = { id, label: name, visible: true, type, custom: true }
    if (type === 'dropdown') col.options = ['', 'Option 1', 'Option 2', 'Option 3']
    setLocal(p => ({ ...p, [section]: [...p[section], col] }))
    setAddingTo(null)
  }

  return (
    <>
      {/* Dim backdrop */}
      <div className="fixed inset-0 bg-black/10 z-[9996]" onClick={onClose} />

      {/* Panel */}
      <div
        className="fixed right-0 top-0 h-full bg-white shadow-2xl flex flex-col border-l border-gray-200"
        style={{ width: 340, zIndex: 9997 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200 flex-shrink-0">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4" style={{ color: '#E05A2B' }} />
            <span className="font-semibold text-gray-900 text-sm">Customize Columns</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSave(local)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white"
              style={{ backgroundColor: '#E05A2B' }}
            >
              Save
            </button>
            <button
              onClick={onClose}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          <p className="text-xs text-gray-400 mb-5">
            Click a column name to rename it. Uncheck to hide it from the table.
          </p>

          {/* Supplier Responses */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-3 h-3 rounded-sm border border-blue-200" style={{ backgroundColor: '#EBF3FB' }} />
              <p className="text-xs font-bold uppercase tracking-wide" style={{ color: '#1a6db5' }}>
                Supplier Responses
              </p>
            </div>

            {local.supplierColumns.map(col => (
              <ColumnRow
                key={col.id}
                col={col}
                onToggle={() => toggleCol('supplierColumns', col.id)}
                onRename={l => renameCol('supplierColumns', col.id, l)}
                onRemove={col.custom ? () => removeCol('supplierColumns', col.id) : null}
              />
            ))}

            {addingTo === 'supplierColumns' ? (
              <AddColumnForm
                onAdd={(name, type) => addCol('supplierColumns', name, type)}
                onCancel={() => setAddingTo(null)}
              />
            ) : (
              <button
                onClick={() => setAddingTo('supplierColumns')}
                className="flex items-center gap-1.5 text-xs mt-2 transition-colors hover:opacity-80"
                style={{ color: '#1a6db5' }}
              >
                <Plus className="w-3.5 h-3.5" /> Add column
              </button>
            )}
          </div>

          <hr className="border-gray-100 mb-5" />

          {/* Bid COE Internal */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-3 h-3 rounded-sm border border-amber-200" style={{ backgroundColor: '#FEFCE8' }} />
              <p className="text-xs font-bold uppercase tracking-wide" style={{ color: '#B45309' }}>
                Bid COE Internal
              </p>
            </div>

            {local.internalColumns.map(col => (
              <ColumnRow
                key={col.id}
                col={col}
                onToggle={() => toggleCol('internalColumns', col.id)}
                onRename={l => renameCol('internalColumns', col.id, l)}
                onRemove={col.custom ? () => removeCol('internalColumns', col.id) : null}
              />
            ))}

            {addingTo === 'internalColumns' ? (
              <AddColumnForm
                onAdd={(name, type) => addCol('internalColumns', name, type)}
                onCancel={() => setAddingTo(null)}
              />
            ) : (
              <button
                onClick={() => setAddingTo('internalColumns')}
                className="flex items-center gap-1.5 text-xs mt-2 transition-colors hover:opacity-80"
                style={{ color: '#B45309' }}
              >
                <Plus className="w-3.5 h-3.5" /> Add column
              </button>
            )}
          </div>
        </div>
      </div>
    </>
  )
}

// ── Working file row ──────────────────────────────────────
function WorkingFileRow({
  item, pricing, approved, onApprove, onCellSave,
  visibleSupplierColIds, supplierColLabel,
  internalCols, internalValues, onInternalSave,
  portalCustomFields = [],
}) {
  const conf         = pricing?.confidence ?? null
  const hasData      = !!pricing
  const needsApprove = hasData && !approved && conf !== null && conf >= 75 && conf < 90
  const needsReview  = hasData && !approved && conf !== null && conf < 75

  const supplierPricing = item.supplierPricing || []
  const [expanded, setExpanded] = useState(true)

  // ── Supplier-side inline edit state ──────────────────────
  const [editingField, setEditingField] = useState(null)
  const [draft, setDraft]               = useState('')
  const inputRef                        = useRef(null)

  // ── Internal-side inline edit state ──────────────────────
  const [intEditField, setIntEditField] = useState(null)
  const [intDraft, setIntDraft]         = useState('')
  const intInputRef                     = useRef(null)

  useEffect(() => {
    if (editingField && inputRef.current) {
      inputRef.current.focus()
      if (inputRef.current.select) inputRef.current.select()
    }
  }, [editingField])

  useEffect(() => {
    if (intEditField && intInputRef.current) {
      intInputRef.current.focus()
      if (intInputRef.current.select) intInputRef.current.select()
    }
  }, [intEditField])

  const startEdit = (field, val) => {
    setDraft(val != null ? String(val) : '')
    setEditingField(field)
  }

  const commitSave = () => {
    if (!editingField) return
    const realField =
      editingField === 'supcRight'  ? 'supc'  :
      editingField === 'brandRight' ? 'brand' :
      editingField
    onCellSave(realField, draft)
    setEditingField(null)
  }

  const cancelEdit  = () => setEditingField(null)
  const handleKey   = (e) => {
    if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); commitSave() }
    else if (e.key === 'Escape') cancelEdit()
  }

  const startIntEdit = (colId, val) => {
    setIntDraft(val != null ? String(val) : '')
    setIntEditField(colId)
  }

  const commitIntSave = () => {
    if (!intEditField) return
    const col     = internalCols.find(c => c.id === intEditField)
    const value   = col?.type === 'number' ? (intDraft === '' ? null : Number(intDraft)) : intDraft
    onInternalSave(intEditField, value)
    setIntEditField(null)
  }

  const cancelIntEdit = () => setIntEditField(null)
  const handleIntKey  = (e) => {
    if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); commitIntSave() }
    else if (e.key === 'Escape') cancelIntEdit()
  }

  // ── Supplier data resolution ──────────────────────────────
  const firstEntry   = supplierPricing[0] || null
  const extraEntries = expanded ? supplierPricing.slice(1) : []

  const trueVendor    = firstEntry?.supplierName     ?? pricing?.supplier_name ?? item.trueVendor
  const netPriceVal   = firstEntry != null
    ? (firstEntry.unitPrice ?? firstEntry.casePrice ?? null)
    : (pricing?.supplied_price ?? null)
  const devTypeVal    = firstEntry?.devType           ?? pricing?.dev_type      ?? null
  const supplierBrand = firstEntry?.supplierBrand     ?? null
  const supplierDesc  = firstEntry?.supplierDescription ?? null
  const supplierNotes = firstEntry?.notes             ?? null

  const allPrices = supplierPricing
    .map(e => { const p = parseFloat(e.unitPrice ?? e.casePrice); return isNaN(p) ? null : p })
    .filter(p => p != null)
  const bestPrice  = allPrices.length > 1 ? Math.min(...allPrices) : null
  const firstPrice = firstEntry != null
    ? (() => { const p = parseFloat(firstEntry.unitPrice ?? firstEntry.casePrice); return isNaN(p) ? null : p })()
    : null
  const firstIsBest = bestPrice !== null && firstPrice !== null && firstPrice === bestPrice

  // Helper: editable td for supplier side
  const editTd = (field, rawValue, displayContent, opts = {}) => {
    const { isBlue = true, type = 'text', options, className = '' } = opts
    const bgStyle    = isBlue ? BLUE_BG : {}
    const activeStyle = { ...bgStyle, borderBottom: '2px solid #E05A2B' }
    const isEditing  = editingField === field

    if (isEditing) {
      if (type === 'dropdown') {
        return (
          <td key={field} className={`px-2 py-1 text-xs ${className}`} style={activeStyle}>
            <select ref={inputRef} value={draft} onChange={e => setDraft(e.target.value)}
              onBlur={commitSave} onKeyDown={handleKey} className="w-full bg-transparent outline-none text-xs">
              <option value="">—</option>
              {options.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          </td>
        )
      }
      return (
        <td key={field} className={`px-2 py-1 text-xs ${className}`} style={activeStyle}>
          <input ref={inputRef} type={type === 'number' ? 'number' : 'text'}
            step={type === 'number' ? '0.01' : undefined}
            value={draft} onChange={e => setDraft(e.target.value)}
            onBlur={commitSave} onKeyDown={handleKey}
            className="w-full bg-transparent outline-none text-xs min-w-[60px]" />
        </td>
      )
    }

    return (
      <td key={field}
        className={`px-2 py-2.5 text-xs cursor-pointer hover:bg-blue-50/60 transition-colors ${className}`}
        style={bgStyle} onClick={() => startEdit(field, rawValue)} title="Click to edit">
        {displayContent ?? (rawValue != null && rawValue !== '' ? rawValue : EMPTY)}
      </td>
    )
  }

  // Visible supplier column check
  const vis = (id) => visibleSupplierColIds.has(id)

  // Number of visible supplier columns (for sub-row colSpan)
  const visSupplierCount = visibleSupplierColIds.size

  return (
    <>
    {/* ── MAIN ROW ── */}
    <tr className="border-b border-gray-100 dark:border-gray-700 hover:bg-[#F0F7FF] dark:hover:bg-[#253347] transition-colors">

      {/* ── LEFT SIDE — Customer RFP (white, always shown) ── */}
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] font-mono text-gray-500 dark:text-gray-400 whitespace-nowrap text-xs sticky left-0 z-10 shadow-[2px_0_4px_rgba(0,0,0,0.04)]">{item.bidItem}</td>

      {editingField === 'supc' ? (
        <td className="px-2 py-1 bg-white font-mono text-xs whitespace-nowrap" style={{ borderBottom: '2px solid #E05A2B' }}>
          <input ref={inputRef} value={draft} onChange={e => setDraft(e.target.value)}
            onBlur={commitSave} onKeyDown={handleKey}
            className="w-full bg-transparent outline-none font-mono text-xs min-w-[70px]" placeholder="Enter SUPC" />
        </td>
      ) : (
        <td className="px-2 py-2.5 bg-white font-mono text-xs whitespace-nowrap cursor-pointer hover:bg-blue-50/60 transition-colors"
          onClick={() => startEdit('supc', item.supc)} title="Click to edit">
          {item.supc
            ? <span className="text-gray-700">{item.supc}</span>
            : <span className="text-gray-300 italic text-xs">TBD</span>}
        </td>
      )}

      <td className="px-2 py-2.5 bg-white font-mono text-gray-600 text-xs whitespace-nowrap">{item.mpcCode || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white text-gray-600 text-xs whitespace-nowrap">{item.unit || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white text-right font-semibold text-gray-700 text-xs">{item.qty?.toLocaleString() || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white text-gray-600 text-xs whitespace-nowrap">{item.pack || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white text-gray-600 text-xs whitespace-nowrap">{item.size || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white text-gray-700 text-xs whitespace-nowrap">{item.brand || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white max-w-[200px]">
        <p className="font-medium text-gray-900 text-xs truncate" title={item.description}>{item.description}</p>
      </td>
      <td className="px-2 py-2.5 bg-white text-xs"><span className="font-semibold text-gray-600">{getCa(item.category)}</span></td>
      <td className="px-2 py-2.5 bg-white text-center text-xs font-semibold text-gray-500">{item.cw || 'N'}</td>
      <td className="px-2 py-2.5 bg-white text-center text-xs font-semibold text-gray-500">{item.stkType || 'A'}</td>
      <td className="px-2 py-2.5 bg-white"><CompliancePills item={item} /></td>

      {/* Divider: RFP → Supplier */}
      <td className="py-2.5 w-px bg-white"><div className="w-px h-8 bg-gray-200 mx-auto" /></td>

      {/* ── RIGHT SIDE — Supplier Responses (blue, configurable) ── */}

      {vis('supcRight') && editTd('supcRight', item.supc,
        item.supc
          ? <span className="font-mono text-gray-700">{item.supc}</span>
          : <span className="text-gray-300 italic">TBD</span>,
        { isBlue: true, className: 'px-2 w-[70px] whitespace-nowrap font-mono' }
      )}

      {vis('brandRight') && editTd('brandRight', supplierBrand,
        supplierBrand ? <span className="text-gray-800">{supplierBrand}</span> : null,
        { isBlue: true, className: 'px-2 w-[90px]' }
      )}

      {vis('descRight') && (
        <td className="px-2 py-2.5 text-xs max-w-[180px]" style={BLUE_BG}>
          <p className="text-gray-700 truncate" title={supplierDesc || ''}>
            {supplierDesc
              ? supplierDesc.length > 30 ? supplierDesc.slice(0, 30) + '…' : supplierDesc
              : EMPTY}
          </p>
        </td>
      )}

      {vis('trueVendor') && (
        editingField === 'trueVendor' ? (
          <td className="px-3 py-1 text-xs" style={{ ...BLUE_BG, borderBottom: '2px solid #E05A2B' }}>
            <input ref={inputRef} value={draft} onChange={e => setDraft(e.target.value)}
              onBlur={commitSave} onKeyDown={handleKey}
              className="w-full bg-transparent outline-none text-xs min-w-[80px]" placeholder="Enter vendor name" />
          </td>
        ) : (
          <td className="px-3 py-2.5 text-xs cursor-pointer hover:bg-blue-50/60 transition-colors"
            style={BLUE_BG} onClick={() => startEdit('trueVendor', trueVendor)} title="Click to edit">
            <div className="flex items-center gap-1.5 flex-wrap">
              {trueVendor
                ? <span className="font-medium text-gray-800">{trueVendor}</span>
                : <span className="text-gray-400 italic">Awaiting</span>}
              {supplierPricing.length > 1 && (
                <button
                  onClick={e => { e.stopPropagation(); setExpanded(p => !p) }}
                  className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold hover:bg-blue-200 transition-colors"
                >
                  {supplierPricing.length} suppliers
                  {expanded ? <ChevronDown className="w-2.5 h-2.5" /> : <ChevronRight className="w-2.5 h-2.5" />}
                </button>
              )}
            </div>
          </td>
        )
      )}

      {vis('suppliedPrice') && (
        editingField === 'suppliedPrice' ? (
          <td className="px-3 py-1 text-xs text-right" style={{ ...BLUE_BG, borderBottom: '2px solid #E05A2B' }}>
            <input ref={inputRef} type="number" step="0.01" value={draft}
              onChange={e => setDraft(e.target.value)} onBlur={commitSave} onKeyDown={handleKey}
              className="w-full bg-transparent outline-none text-xs text-right min-w-[60px]" placeholder="0.00" />
          </td>
        ) : (
          <td className="px-3 py-2.5 text-right text-xs cursor-pointer hover:bg-blue-50/60 transition-colors"
            style={BLUE_BG} onClick={() => startEdit('suppliedPrice', netPriceVal)} title="Click to edit">
            <div className="flex items-center justify-end gap-1">
              {firstIsBest && <span className="text-xs text-emerald-600 font-semibold">Best</span>}
              <span className={`font-semibold ${firstIsBest ? 'text-emerald-700' : 'text-gray-900'}`}>
                {netPriceVal != null ? `$${Number(netPriceVal).toFixed(2)}` : EMPTY}
              </span>
            </div>
          </td>
        )
      )}

      {vis('devType') && editTd('devType', devTypeVal,
        <DevTypeBadge type={devTypeVal} />,
        { isBlue: true, type: 'dropdown', options: DEV_TYPE_OPTIONS, className: 'px-3' }
      )}

      {vis('notes') && editTd('notes', supplierNotes,
        supplierNotes
          ? <span className="text-gray-600 truncate block max-w-[140px]" title={supplierNotes}>{supplierNotes}</span>
          : null,
        { isBlue: true, className: 'px-3 max-w-[160px]' }
      )}

      {/* PORTAL-TEMPLATE-START */}
      {portalCustomFields.map(field => {
        const value = pricing?.customFieldValues?.[field.id] || pricing?.customFields?.[field.id] || ''
        return (
          <td key={field.id}
            className="px-3 py-2.5 text-xs"
            style={{ ...BLUE_BG, minWidth: field.columnWidth || 100 }}>
            {value ? (
              field.type === 'yes_no' ? (
                <span className={value === 'Yes' ? 'text-green-600 font-medium' : 'text-gray-400'}>
                  {value === 'Yes' ? '✓ Yes' : '✗ No'}
                </span>
              ) : (
                <span className="text-gray-700 truncate block" title={String(value)}>{value}</span>
              )
            ) : (
              <span className="text-gray-300">—</span>
            )}
          </td>
        )
      })}
      {/* PORTAL-TEMPLATE-END */}

      {vis('allw') && (
        <td className="px-3 py-2.5 text-right text-emerald-700 font-semibold text-xs" style={BLUE_BG}>
          {(pricing?.allw ?? item.allw) != null
            ? `$${Number(pricing?.allw ?? item.allw).toFixed(2)}` : EMPTY}
        </td>
      )}

      {vis('dl') && (
        <td className="px-3 py-2.5 text-right text-blue-700 font-semibold text-xs" style={BLUE_BG}>
          {(pricing?.dl ?? item.dl) != null
            ? `$${Number(pricing?.dl ?? item.dl).toFixed(2)}` : EMPTY}
        </td>
      )}

      {vis('priceCase') && (
        <td className="px-3 py-2.5 text-right font-bold text-xs" style={{ ...BLUE_BG, color: '#1F3864' }}>
          {(pricing?.price_case ?? item.priceCase) != null
            ? `$${Number(pricing?.price_case ?? item.priceCase).toFixed(2)}` : EMPTY}
        </td>
      )}

      {vis('openReview') && (
        <td className="px-3 py-2.5 text-center text-xs font-semibold" style={BLUE_BG}>
          {pricing?.open_review === 'Y' || item.openReview === true
            ? <span className="text-amber-600">Y</span>
            : pricing?.open_review === 'N'
              ? <span className="text-gray-400">N</span>
              : EMPTY}
        </td>
      )}

      {vis('confidence') && (
        <td className="px-3 py-2.5" style={BLUE_BG}>
          <div className="flex items-center justify-end gap-1.5">
            <ConfidenceBadge confidence={conf} approved={approved} />
            {needsApprove && (
              <button onClick={() => onApprove(item.id)}
                className="px-2 py-0.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded transition-colors">
                Approve
              </button>
            )}
            {needsReview && <span className="text-xs text-red-500 font-semibold">Review</span>}
          </div>
        </td>
      )}

      {/* Any visible custom supplier columns */}
      {(internalCols.length === 0 ? [] : []).map(() => null)}

      {/* ── Divider: Supplier → COE Internal ── */}
      {internalCols.length > 0 && (
        <td className="py-2.5 w-px" style={YELLOW_BG}>
          <div className="w-px h-8 bg-amber-200 mx-auto" />
        </td>
      )}

      {/* ── COE INTERNAL (yellow, configurable) ── */}
      {internalCols.map(col => {
        const rawVal  = internalValues?.[col.id] ?? ''
        const isEdit  = intEditField === col.id
        const activeY = { ...YELLOW_BG, borderBottom: '2px solid #E05A2B' }

        if (isEdit) {
          if (col.type === 'dropdown') {
            return (
              <td key={col.id} className="px-2 py-1 text-xs" style={activeY}>
                <select ref={intInputRef} value={intDraft} onChange={e => setIntDraft(e.target.value)}
                  onBlur={commitIntSave} onKeyDown={handleIntKey}
                  className="w-full bg-transparent outline-none text-xs">
                  {(col.options || []).map(o => <option key={o} value={o}>{o || '—'}</option>)}
                </select>
              </td>
            )
          }
          return (
            <td key={col.id} className="px-2 py-1 text-xs" style={activeY}>
              <input ref={intInputRef} type={col.type === 'number' ? 'number' : 'text'}
                step={col.type === 'number' ? '1' : undefined}
                value={intDraft} onChange={e => setIntDraft(e.target.value)}
                onBlur={commitIntSave} onKeyDown={handleIntKey}
                className="w-full bg-transparent outline-none text-xs min-w-[60px]" />
            </td>
          )
        }

        return (
          <td key={col.id}
            className="px-3 py-2.5 text-xs cursor-pointer hover:bg-amber-50 transition-colors"
            style={YELLOW_BG}
            onClick={() => startIntEdit(col.id, rawVal)}
            title="Click to edit"
          >
            {col.id === 'awardDecision'
              ? (() => {
                  const syncedAward = supplierPricing.find(sp => sp.awardStatus === 'awarded')
                  if (syncedAward) return (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-teal-100 text-teal-700">
                      🏆 Awarded
                    </span>
                  )
                  return <AwardBadge value={rawVal} />
                })()
              : rawVal !== '' && rawVal != null
                ? <span className="text-gray-700">{String(rawVal)}</span>
                : EMPTY}
          </td>
        )
      })}
    </tr>

    {/* ── ADDITIONAL SUPPLIER SUB-ROWS ── */}
    {expanded && extraEntries.map((entry, idx) => {
      const ep     = (() => { const p = parseFloat(entry.unitPrice ?? entry.casePrice); return isNaN(p) ? null : p })()
      const isBest = bestPrice !== null && ep !== null && ep === bestPrice
      return (
        <tr key={`sub-${item.id}-${idx}`} style={{ ...SUB_ROW_BG, borderBottom: '1px solid #dbeafe' }}>
          {/* Spacer — left side (13 cols) + divider */}
          <td colSpan={14} className="bg-white" style={{ borderBottom: '1px solid #f3f4f6' }} />

          {vis('supcRight') && (
            <td className="px-2 py-2 text-xs font-mono" style={SUB_ROW_BG}>
              <span className="text-gray-300 italic">TBD</span>
            </td>
          )}
          {vis('brandRight') && (
            <td className="px-2 py-2 text-xs" style={SUB_ROW_BG}>
              {entry.supplierBrand
                ? <span className="text-gray-700">{entry.supplierBrand}</span>
                : EMPTY}
            </td>
          )}
          {vis('descRight') && (
            <td className="px-2 py-2 text-xs max-w-[180px]" style={SUB_ROW_BG}>
              <p className="text-gray-700 truncate" title={entry.supplierDescription || ''}>
                {entry.supplierDescription
                  ? entry.supplierDescription.length > 30
                    ? entry.supplierDescription.slice(0, 30) + '…'
                    : entry.supplierDescription
                  : EMPTY}
              </p>
            </td>
          )}
          {vis('trueVendor') && (
            <td className="px-3 py-2 text-xs" style={SUB_ROW_BG}>
              <span className="font-medium text-gray-700">{entry.supplierName || EMPTY}</span>
            </td>
          )}
          {vis('suppliedPrice') && (
            <td className="px-3 py-2 text-right text-xs" style={SUB_ROW_BG}>
              <div className="flex items-center justify-end gap-1">
                {isBest && <span className="text-xs text-emerald-600 font-semibold">Best</span>}
                <span className={`font-semibold ${isBest ? 'text-emerald-700' : 'text-gray-700'}`}>
                  {ep != null ? `$${ep.toFixed(2)}` : EMPTY}
                </span>
              </div>
            </td>
          )}
          {vis('devType') && (
            <td className="px-3 py-2 text-xs" style={SUB_ROW_BG}>
              <DevTypeBadge type={entry.devType} />
            </td>
          )}
          {vis('notes') && (
            <td className="px-3 py-2 text-xs max-w-[160px]" style={SUB_ROW_BG}>
              {entry.notes
                ? <span className="text-gray-600 truncate block max-w-[140px]" title={entry.notes}>{entry.notes}</span>
                : EMPTY}
            </td>
          )}
          {/* allw/dl/priceCase/openReview/confidence — blank for sub-rows */}
          {vis('allw')      && <td style={SUB_ROW_BG} />}
          {vis('dl')        && <td style={SUB_ROW_BG} />}
          {vis('priceCase') && <td style={SUB_ROW_BG} />}
          {vis('openReview')&& <td style={SUB_ROW_BG} />}
          {vis('confidence')&& <td style={SUB_ROW_BG} />}

          {/* PORTAL-TEMPLATE-START — blank for sub-rows */}
          {portalCustomFields.map(field => <td key={field.id} style={SUB_ROW_BG} />)}
          {/* PORTAL-TEMPLATE-END */}

          {/* COE internal — empty for sub-rows */}
          {internalCols.length > 0 && (
            <td colSpan={internalCols.length + 1} style={YELLOW_BG} />
          )}
        </tr>
      )
    })}
    </>
  )
}

// ── Empty state ───────────────────────────────────────────
function WorkingFileEmptyState({ onUploadRFP }) {
  return (
    <EmptyState
      icon={FileSpreadsheet}
      title="No line items yet"
      description="Upload an Excel item list or RFP PDF in the Bid Documents section. BEX AI will automatically import all line items."
      action={{ label: 'Upload RFP with BEX AI', icon: Brain, onClick: onUploadRFP }}
      size="lg"
    />
  )
}

// ── Main WorkingFileTab ───────────────────────────────────
export default function WorkingFileTab({ bid }) {
  const navigate = useNavigate()
  const [lineItems,   setLineItems]   = useState([])
  const [pricingMap,  setPricingMap]  = useState({})
  const [approved,    setApproved]    = useState({})
  const [loading,     setLoading]     = useState(true)
  const [importing,   setImporting]   = useState(false)
  const [error,       setError]       = useState(null)
  const [toast,       setToast]       = useState(null)
  const [saveStatus,  setSaveStatus]  = useState(null)
  const [hasEdited,   setHasEdited]   = useState(false)
  const saveTimerRef = useRef(null)

  // ── Column configuration state ────────────────────────────
  const [wfConfig, setWfConfig] = useState(() => {
    const saved = bid.workingFileConfig
    return {
      supplierColumns: saved?.supplierColumns || DEFAULT_SUPPLIER_COLUMNS,
      internalColumns: saved?.internalColumns || DEFAULT_INTERNAL_COLUMNS,
    }
  })

  // ── Internal (COE) cell data per line item ─────────────────
  const [internalData, setInternalData] = useState({})

  // ── Customize panel visibility ────────────────────────────
  const [showCustomizePanel, setShowCustomizePanel] = useState(false)

  const showSaveStatus = (status) => {
    setSaveStatus(status)
    if (status === 'saved') {
      clearTimeout(saveTimerRef.current)
      saveTimerRef.current = setTimeout(() => setSaveStatus(null), 2000)
    }
  }

  // Fetch line items
  useEffect(() => {
    fetch(`/api/bids/${bid.id}/line-items`)
      .then(r => r.json())
      .then(data => {
        setLineItems(Array.isArray(data) ? data : [])

        const initApproved = {}
        const initPricing  = {}
        const initInternal = {}

        data.forEach(li => {
          if (li.confidence != null && li.confidence >= 90) initApproved[li.id] = true
          if (li.suppliedPrice != null) {
            initPricing[li.id] = {
              supplier_name:  li.trueVendor || li.currentSupplier || '—',
              dev_type:       li.devType,
              supplied_price: li.suppliedPrice,
              allw:           li.allw,
              dl:             li.dl,
              price_case:     li.priceCase,
              open_review:    li.openReview ? 'Y' : 'N',
              confidence:     li.confidence,
            }
          }
          if (li.coeInternal) initInternal[li.id] = li.coeInternal
        })

        setApproved(initApproved)
        setPricingMap(initPricing)
        setInternalData(initInternal)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [bid.id])

  // ── Cell save handler (supplier side) ─────────────────────
  const handleCellSave = async (lineId, field, value) => {
    const coerced = field === 'suppliedPrice' ? (value === '' ? null : Number(value)) : value

    setLineItems(prev => prev.map(li =>
      li.id === lineId ? { ...li, [field]: coerced } : li
    ))

    if (field === 'trueVendor') {
      setPricingMap(prev => prev[lineId]
        ? { ...prev, [lineId]: { ...prev[lineId], supplier_name: value } }
        : prev)
    }
    if (field === 'suppliedPrice') {
      setPricingMap(prev => prev[lineId]
        ? { ...prev, [lineId]: { ...prev[lineId], supplied_price: coerced } }
        : prev)
    }
    if (field === 'devType') {
      setPricingMap(prev => prev[lineId]
        ? { ...prev, [lineId]: { ...prev[lineId], dev_type: value } }
        : prev)
    }

    setHasEdited(true)
    showSaveStatus('saving')

    try {
      await fetch(`/api/bids/${bid.id}/line-items/${lineId}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ [field]: coerced }),
      })
      showSaveStatus('saved')
    } catch {
      showSaveStatus(null)
    }
  }

  // ── Internal cell save handler ────────────────────────────
  const handleInternalSave = async (lineId, colId, value) => {
    const updated = { ...internalData[lineId], [colId]: value }
    setInternalData(prev => ({ ...prev, [lineId]: updated }))
    try {
      await fetch(`/api/bids/${bid.id}/line-items/${lineId}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ coeInternal: updated }),
      })
    } catch { /* silent */ }
  }

  // ── Save column config to backend ─────────────────────────
  const saveConfig = async (newConfig) => {
    setWfConfig(newConfig)
    setShowCustomizePanel(false)
    try {
      await fetch(`/api/bids/${bid.id}/working-file-config`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(newConfig),
      })
      setToast('Column configuration saved')
    } catch { /* silent */ }
  }

  // ── Import supplier pricing ───────────────────────────────
  const handleImport = async () => {
    setImporting(true)
    setError(null)
    try {
      const res     = await fetch('/api/extract-pricing', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ bidId: bid.id }),
      })
      const matches = await res.json()
      if (!res.ok) throw new Error(matches.error || 'Extract failed')

      if (!matches.length) {
        setToast('No supplier responses found for this bid — log responses first')
        return
      }

      const newMap     = {}
      matches.forEach(m => { newMap[m.rfp_line_id] = m })
      setPricingMap(newMap)

      const newApproved = { ...approved }
      matches.forEach(m => { if (m.confidence >= 90) newApproved[m.rfp_line_id] = true })
      setApproved(newApproved)

      await Promise.all(
        matches
          .filter(m => m.confidence >= 90)
          .map(m => fetch(`/api/bids/${bid.id}/line-items/${m.rfp_line_id}`, {
            method:  'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({
              trueVendor:    m.supplier_name,
              suppliedPrice: m.supplied_price,
              allw:          m.allw,
              dl:            m.dl,
              priceCase:     m.price_case,
              devType:       m.dev_type,
              openReview:    m.open_review === 'Y',
              confidence:    m.confidence,
              status:        'Priced',
            }),
          }))
      )

      setToast(`${matches.length} items imported — ${matches.filter(m => m.confidence >= 90).length} auto-approved`)
    } catch (err) {
      setError(err.message)
    } finally {
      setImporting(false)
    }
  }

  // ── Approve amber row ─────────────────────────────────────
  const handleApprove = async (lineId) => {
    setApproved(prev => ({ ...prev, [lineId]: true }))
    const m = pricingMap[lineId]
    if (m) {
      await fetch(`/api/bids/${bid.id}/line-items/${lineId}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          trueVendor:    m.supplier_name,
          suppliedPrice: m.supplied_price,
          allw:          m.allw,
          dl:            m.dl,
          priceCase:     m.price_case,
          devType:       m.dev_type,
          openReview:    m.open_review === 'Y',
          confidence:    m.confidence,
          status:        'Priced',
        }),
      }).catch(() => {})
    }
    setToast('Row approved')
  }

  // ── Derived values ────────────────────────────────────────
  const matched         = useMemo(() => Object.keys(pricingMap).length, [pricingMap])
  const pendingApproval = useMemo(() =>
    Object.entries(pricingMap).filter(([id, m]) => !approved[id] && m.confidence >= 75 && m.confidence < 90).length,
    [pricingMap, approved]
  )
  const noResponse   = useMemo(() => lineItems.filter(li => !pricingMap[li.id]).length, [lineItems, pricingMap])
  const awardedCount = useMemo(() =>
    lineItems.filter(li => (li.supplierPricing || []).some(sp => sp.awardStatus === 'awarded')).length,
    [lineItems]
  )

  // ── Visible column helpers ────────────────────────────────
  const visibleSupplierCols    = useMemo(() => wfConfig.supplierColumns.filter(c => c.visible), [wfConfig])
  const visibleSupplierColIds  = useMemo(() => new Set(visibleSupplierCols.map(c => c.id)), [visibleSupplierCols])
  const supplierColLabel       = useMemo(() => Object.fromEntries(wfConfig.supplierColumns.map(c => [c.id, c.label])), [wfConfig])
  const visibleInternalCols    = useMemo(() => wfConfig.internalColumns.filter(c => c.visible), [wfConfig])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader className="w-6 h-6 animate-spin text-exl-orange" />
        <span className="ml-3 text-gray-500 text-sm">Loading working file…</span>
      </div>
    )
  }

  if (lineItems.length === 0) {
    return (
      <div className="card">
        <WorkingFileEmptyState onUploadRFP={() => navigate('/bex')} />
      </div>
    )
  }

  return (
    <div className="min-h-[400px]">
      {/* ── Customize Columns slide-in panel ── */}
      {showCustomizePanel && (
        <CustomizePanel
          config={wfConfig}
          onClose={() => setShowCustomizePanel(false)}
          onSave={saveConfig}
        />
      )}

      {/* ── Header ── */}
      <div className="flex items-center justify-between mb-1">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-base font-semibold text-gray-900">Working File</h2>
            {saveStatus === 'saving' && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <Loader className="w-3 h-3 animate-spin" /> Saving…
              </span>
            )}
            {saveStatus === 'saved' && (
              <span className="text-xs text-emerald-600 flex items-center gap-1 font-medium">
                <CheckCircle className="w-3.5 h-3.5" /> Saved
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-0.5">
            {lineItems.length} line items
            {' · '}
            {(() => {
              const src = lineItems[0]?._source || bid._lineItemSource
              if (src === 'excel') return 'Imported from Excel'
              if (src === 'pdf')   return 'Extracted from RFP PDF by AI'
              return bid.customer
            })()}
          </p>
          {!hasEdited && (
            <p className="text-xs text-gray-400 mt-0.5 italic">Click any cell to edit</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="md"
            icon={Download}
            onClick={() => exportCsv(lineItems, pricingMap, internalData, wfConfig, bid.id)}
          >
            Export CSV
          </Button>
          <Button
            variant="ghost"
            size="md"
            icon={Settings}
            onClick={() => setShowCustomizePanel(true)}
          >
            Customize Columns
          </Button>
          <Button
            variant="primary"
            size="md"
            icon={importing ? undefined : RefreshCw}
            loading={importing}
            onClick={handleImport}
          >
            {importing ? 'Importing…' : 'Import Supplier Pricing'}
          </Button>
        </div>
      </div>

      {/* ── Summary bar ── */}
      {(matched > 0 || noResponse > 0) && (
        <div className="flex items-center gap-4 bg-gray-50 dark:bg-[#1E293B] border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2.5 mb-4 text-sm mt-3">
          <span className="flex items-center gap-1.5 font-semibold text-emerald-700">
            <CheckCircle className="w-4 h-4" /> {matched} Matched
          </span>
          {pendingApproval > 0 && (
            <span className="flex items-center gap-1.5 font-semibold text-amber-700">
              <AlertTriangle className="w-4 h-4" /> {pendingApproval} Pending Approval
            </span>
          )}
          {noResponse > 0 && (
            <span className="flex items-center gap-1.5 font-semibold text-gray-500">
              <XCircle className="w-4 h-4" /> {noResponse} No Response
            </span>
          )}
          {awardedCount > 0 && (
            <span className="flex items-center gap-1.5 font-semibold text-teal-700 ml-auto">
              🏆 {awardedCount} of {lineItems.length} items awarded
            </span>
          )}
        </div>
      )}

      {/* ── Error ── */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700 mb-4">{error}</div>
      )}

      {/* ── Grid ── */}
      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 'calc(100vh - 280px)', contain: 'layout style', willChange: 'transform' }}>
          <table className="w-full text-xs min-w-[2200px]">
            <thead>
              {/* ── Section label row ── */}
              <tr className="border-b border-gray-100 sticky top-0 z-20">
                <th
                  colSpan={13}
                  className="px-3 py-1.5 text-left text-xs font-semibold text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-[#253347] tracking-wide uppercase"
                >
                  Customer RFP
                </th>
                <th className="bg-white dark:bg-[#1E293B] w-px" />
                <th
                  colSpan={visibleSupplierCols.length}
                  className="px-3 py-1.5 text-left text-xs font-semibold tracking-wide uppercase"
                  style={{ ...BLUE_BG, color: '#1a6db5' }}
                >
                  Supplier Responses
                </th>
                {visibleInternalCols.length > 0 && (
                  <>
                    <th className="w-px" style={YELLOW_BG} />
                    <th
                      colSpan={visibleInternalCols.length}
                      className="px-3 py-1.5 text-left text-xs font-semibold tracking-wide uppercase"
                      style={{ ...YELLOW_BG, color: '#B45309' }}
                    >
                      Bid COE Internal
                    </th>
                  </>
                )}
              </tr>

              {/* ── Column header row ── */}
              <tr className="border-b-2 border-gray-200 sticky top-[30px] z-20">
                {/* Customer RFP — fixed */}
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-12 sticky left-0 z-30">Item #</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-400 bg-gray-50 w-20">
                  <span className="flex items-center gap-1" title="Sysco internal product code — editable">
                    SUPC <span className="text-gray-300 text-xs font-normal italic">›item master</span>
                  </span>
                </th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-24">MPC Code</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-14">UOM</th>
                <th className="px-2 py-2.5 text-right font-semibold text-gray-500 bg-gray-50 w-16">Volume</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-16">Pack</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-20">Size</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-24">Brand</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 min-w-[160px]">Description</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-14">CA</th>
                <th className="px-2 py-2.5 text-center font-semibold text-gray-500 bg-gray-50 w-10">CW</th>
                <th className="px-2 py-2.5 text-center font-semibold text-gray-500 bg-gray-50 w-10">STK</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-20">Flags</th>
                {/* Divider */}
                <th className="w-px bg-white" />
                {/* Supplier Responses — configurable */}
                {visibleSupplierCols.map(col => {
                  const isRight = ['text-right', 'text-center']
                  const align =
                    col.id === 'suppliedPrice' || col.id === 'allw' || col.id === 'dl' || col.id === 'priceCase' ? 'text-right' :
                    col.id === 'openReview' || col.id === 'confidence' ? 'text-center' :
                    'text-left'
                  return (
                    <th key={col.id}
                      className={`px-2 py-2.5 font-semibold ${align}`}
                      style={{ ...BLUE_BG, color: '#1a6db5' }}>
                      {supplierColLabel[col.id] || col.label}
                    </th>
                  )
                })}
                {/* PORTAL-TEMPLATE-START */}
                {(bid?.portalConfig?.customFields || []).filter(f => f.showInWorkingFile).map(field => (
                  <th key={field.id}
                    className="px-3 py-2.5 text-left font-semibold whitespace-nowrap"
                    style={{ ...BLUE_BG, color: '#1a6db5', minWidth: field.columnWidth || 100 }}>
                    {field.label}
                  </th>
                ))}
                {/* PORTAL-TEMPLATE-END */}
                {/* COE Internal — configurable */}
                {visibleInternalCols.length > 0 && <th className="w-px" style={YELLOW_BG} />}
                {visibleInternalCols.map(col => (
                  <th key={col.id}
                    className="px-3 py-2.5 text-left font-semibold whitespace-nowrap"
                    style={{ ...YELLOW_BG, color: '#B45309' }}>
                    {col.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {lineItems.map(li => (
                <WorkingFileRow
                  key={li.id}
                  item={li}
                  pricing={pricingMap[li.id] || null}
                  approved={!!approved[li.id]}
                  onApprove={handleApprove}
                  onCellSave={(field, value) => handleCellSave(li.id, field, value)}
                  visibleSupplierColIds={visibleSupplierColIds}
                  supplierColLabel={supplierColLabel}
                  internalCols={visibleInternalCols}
                  internalValues={internalData[li.id] || {}}
                  onInternalSave={(colId, value) => handleInternalSave(li.id, colId, value)}
                  portalCustomFields={(bid?.portalConfig?.customFields || []).filter(f => f.showInWorkingFile)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Toast ── */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-700 text-white text-sm font-medium px-4 py-3 rounded-xl shadow-lg flex items-center gap-2">
          <CheckCircle className="w-4 h-4" /> {toast}
          <button onClick={() => setToast(null)} className="ml-2 opacity-70 hover:opacity-100">×</button>
        </div>
      )}
    </div>
  )
}
