import React, { useState, useRef } from 'react'
import { ArrowLeft, Send, Paperclip, X, Plus, CheckCircle, Loader2, Mail, AlertTriangle } from 'lucide-react'
import { PORTAL_URL as PORTAL_BASE } from '../../config.js'

// ── Compliance body lines ─────────────────────────────────
const COMPLIANCE_LINES = {
  'Child Nutrition': '• Child Nutrition (CN) labels',
  'PFS':             '• Product Formulation Statements (PFS)',
  'Buy American':    '• Buy American Act compliance documentation',
  'Halal':           '• Halal certification documentation',
  'Kosher':          '• Kosher certification documentation',
}

function buildBody(bid) {
  const hour       = new Date().getHours()
  const greeting   = hour < 12 ? 'morning' : 'afternoon'
  const dueDateStr = bid.customerDue
    ? new Date(bid.customerDue).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : '[Due Date TBD]'
  const compLines = (bid.compliance || [])
    .map(c => COMPLIANCE_LINES[c])
    .filter(Boolean)
    .join('\n')

  // PORTAL-DEMO: portal URL placed right after opening paragraph
  const portalUrl = `${PORTAL_BASE}/submit/${bid.id}`

  const body = `Good ${greeting},

As we move forward in the bid process for ${bid.customer}, Sysco requests that you provide pricing for the attached item list no later than ${dueDateStr}.

Please also include the following documentation where applicable:
${compLines || '• Standard compliance documentation as applicable'}

Please return all pricing to: COE.BIDS@sysco.com

Starting July 1, 2026, the Sysco Supplier Portal will become the primary communication channel for all bid submissions and correspondence. Until then, please submit your pricing by replying to this email with your pricing document attached.

For early access to the portal, visit:
→ ${portalUrl}

If you have any questions please contact us at the email above.

Thank you for your assistance.

Sysco Bid COE
COE.BIDS@sysco.com`

  // Confirm portal URL appears in final body string
  console.log('[EmailComposer] buildBody — portalUrl:', portalUrl)
  console.log('[EmailComposer] buildBody — body preview:', body.slice(0, 300))

  return body
}

// ── BCC email tag ─────────────────────────────────────────
function EmailTag({ email, onRemove }) {
  return (
    <span className="inline-flex items-center gap-1 bg-exl-navy/10 text-exl-navy text-xs font-medium px-2 py-1 rounded-full">
      {email}
      <button onClick={() => onRemove(email)} className="hover:text-gray-500 transition-colors ml-0.5">
        <X className="w-3 h-3" />
      </button>
    </span>
  )
}

// ── Main EmailComposer ────────────────────────────────────
export default function EmailComposer({ bid, selectedSuppliers, onCancel, onSent }) {
  const defaultBcc  = selectedSuppliers.map(s => s.contact)
  // PORTAL-DEMO: cleaner subject with due date
  const dueFmt      = bid.customerDue
    ? new Date(bid.customerDue).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : 'TBD'
  const defaultSubj = `Pricing Request: ${bid.customer} — ${bid.id} | Due ${dueFmt}`
  const defaultBody = buildBody(bid)

  const [bccList,   setBccList]   = useState(defaultBcc)
  const [bccInput,  setBccInput]  = useState('')
  const [subject,   setSubject]   = useState(defaultSubj)
  const [body,      setBody]      = useState(defaultBody)
  const [sending,   setSending]   = useState(false)
  const [sent,      setSent]      = useState(false)
  const [error,     setError]     = useState(null)
  const bccRef = useRef(null)

  // Detect internal / non-supplier addresses in BCC
  const INTERNAL_DOMAINS = ['@exlservice.com', '@anthropic.com', '@sysco.com']
  const internalBcc = bccList.filter(e =>
    INTERNAL_DOMAINS.some(d => e.toLowerCase().includes(d))
  )

  // Attachments (display only)
  const attachments = [
    `${bid.customer.replace(/\s+/g, '_')}_RFP_${bid.id}.pdf`,
    `${bid.customer.replace(/\s+/g, '_')}_Item_List_${bid.id}.xlsx`,
  ]

  // Add BCC email
  const addBcc = (raw) => {
    const email = raw.trim()
    if (email && !bccList.includes(email)) {
      setBccList(prev => [...prev, email])
    }
    setBccInput('')
  }

  const removeBcc = (email) => setBccList(prev => prev.filter(e => e !== email))

  // Send solicitation
  const handleSend = async () => {
    setSending(true)
    setError(null)
    const minDelay = new Promise(r => setTimeout(r, 600))
    try {
      // 1. Send real email + save to emailThreads.json + save solicitedSuppliers to bid
      const res  = await fetch(`/api/bids/${bid.id}/emails`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          direction:   'outbound',
          from:        'COE.BIDS@sysco.com',
          to:          '',
          bcc:         bccList,
          subject,
          body,
          attachments,
          tags:        ['Solicitation'],
          // Pass explicit supplier list so backend saves solicitedSuppliers accurately
          supplierContacts: selectedSuppliers
            .filter(s => bccList.includes(s.contact))   // only those still in BCC
            .map(s => ({
              supplierId:   s.id,
              supplierName: s.name,
              email:        s.contact,
              category:     s.category || '',
            })),
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        const msg = [data.error, data.hint].filter(Boolean).join('\n')
        throw new Error(msg || 'Send failed')
      }

      // 2. Update bid status → "Solicitation" and suppliersContacted
      // (Backend also does this, but keep PATCH for immediate frontend sync)
      await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ status: 'Solicitation', suppliersContacted: bccList.length }),
      })

      await minDelay
      setSent(true)
      setTimeout(() => onSent(bccList.length), 1500)
    } catch (err) {
      await minDelay
      setError(err.message)
    } finally {
      setSending(false)
    }
  }

  if (sent) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4 animate-bounce-once">
          <CheckCircle className="w-8 h-8 text-emerald-600" />
        </div>
        <p className="text-lg font-bold text-gray-900">Solicitation Sent!</p>
        <p className="text-sm text-gray-500 mt-1">
          ✓ Emailed to <span className="font-semibold text-emerald-700">{bccList.length} suppliers</span>
        </p>
        <p className="text-xs text-gray-400 mt-2">Redirecting to Email Repo…</p>
        {/* Fixed toast */}
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-700 text-white text-sm font-semibold
                        px-5 py-3 rounded-xl shadow-xl flex items-center gap-2.5 animate-slide-up">
          <CheckCircle className="w-4 h-4 flex-shrink-0" />
          ✓ Solicitation sent to {bccList.length} suppliers
        </div>
      </div>
    )
  }

  return (
    <div>
      {/* ── Composer header ── */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={onCancel}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-exl-navy font-medium transition-colors group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          Back to Suppliers
        </button>
        <span className="text-gray-300">/</span>
        <span className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
          <Mail className="w-4 h-4 text-exl-orange" />
          Solicitation Email — {bid.id}
        </span>
      </div>

      <div className="card overflow-hidden">
        {/* ── To field (greyed out) ── */}
        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide w-16 flex-shrink-0">To</span>
          <span className="text-sm text-gray-300 italic">(not used — all recipients go to BCC)</span>
        </div>

        {/* ── BCC field ── */}
        <div className="px-5 py-3 border-b border-gray-100">
          <div className="flex items-start gap-3">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide w-16 flex-shrink-0 mt-2">BCC</span>
            <div
              className="bcc-input-container flex-1 flex flex-wrap gap-1.5 min-h-[36px] cursor-text"
              onClick={() => bccRef.current?.focus()}
            >
              {bccList.map(email => (
                <EmailTag key={email} email={email} onRemove={removeBcc} />
              ))}
              <input
                ref={bccRef}
                type="text"
                value={bccInput}
                onChange={e => setBccInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' || e.key === ',' || e.key === ' ') {
                    e.preventDefault()
                    addBcc(bccInput)
                  }
                  if (e.key === 'Backspace' && !bccInput && bccList.length) {
                    removeBcc(bccList[bccList.length - 1])
                  }
                }}
                onBlur={() => bccInput.trim() && addBcc(bccInput)}
                placeholder={bccList.length === 0 ? 'Add email address…' : ''}
                className="flex-1 min-w-[180px] outline-none border-none bg-transparent text-sm text-gray-700 placeholder-gray-400 focus:ring-0 py-0.5"
              />
            </div>
            <span className="text-xs text-gray-400 mt-2 flex-shrink-0">{bccList.length} recipients</span>
          </div>
        </div>

        {/* ── Internal domain warning ── */}
        {internalBcc.length > 0 && (
          <div className="px-5 py-2.5 bg-amber-50 border-b border-amber-200 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 font-medium leading-relaxed">
              <span className="font-bold">{internalBcc.length} recipient{internalBcc.length > 1 ? 's appear' : ' appears'} to be an internal address</span>
              {' '}({internalBcc.join(', ')}). Verify before sending — these are not supplier contacts.
            </p>
          </div>
        )}

        {/* ── Subject ── */}
        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide w-16 flex-shrink-0">Subject</span>
          <input
            type="text"
            value={subject}
            onChange={e => setSubject(e.target.value)}
            className="flex-1 text-sm text-gray-900 font-medium outline-none focus:ring-0 border-0 bg-transparent"
          />
        </div>

        {/* ── Body ── */}
        <div className="px-5 py-4 border-b border-gray-100">
          <textarea
            value={body}
            onChange={e => setBody(e.target.value)}
            rows={14}
            className="w-full text-sm text-gray-700 leading-relaxed outline-none resize-none font-sans"
          />
        </div>

        {/* ── Attachments ── */}
        <div className="px-5 py-3 bg-gray-50 border-b border-gray-100">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
            <Paperclip className="w-3.5 h-3.5 inline mr-1" />
            Attachments
          </p>
          <div className="flex flex-wrap gap-2">
            {attachments.map(a => (
              <span
                key={a}
                className="inline-flex items-center gap-1.5 bg-white border border-gray-200 text-gray-700 text-xs font-medium px-3 py-1.5 rounded-lg"
              >
                <Paperclip className="w-3 h-3 text-gray-400" />
                {a}
              </span>
            ))}
          </div>
        </div>

        {/* ── Error ── */}
        {error && (
          <div className="px-5 py-4 bg-red-50 border-b border-red-100">
            <div className="flex items-start gap-2 text-sm text-red-700">
              <span className="font-semibold flex-shrink-0">⚠ Send failed:</span>
              <span className="whitespace-pre-wrap">{error}</span>
            </div>
          </div>
        )}

        {/* ── Actions ── */}
        <div className="px-5 py-4 flex items-center justify-between bg-gray-50">
          <button onClick={onCancel} className="btn-secondary">
            Cancel
          </button>
          <button
            onClick={handleSend}
            disabled={sending || bccList.length === 0}
            className="btn-primary flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {sending
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Sending to {bccList.length} recipients...</>
              : <><Send className="w-4 h-4" /> Send Solicitation ({bccList.length} recipients)</>
            }
          </button>
        </div>
      </div>
    </div>
  )
}
