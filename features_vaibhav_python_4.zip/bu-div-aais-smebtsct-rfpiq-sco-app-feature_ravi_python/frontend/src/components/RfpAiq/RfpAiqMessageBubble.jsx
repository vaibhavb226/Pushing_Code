import React, { useState } from 'react'

// ── Action pill with clipboard copy + tooltip ─────────────
function ActionPill({ action }) {
  const [copied, setCopied] = useState(false)

  const handleClick = () => {
    navigator.clipboard.writeText(action).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="relative inline-block">
      <button
        onClick={handleClick}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold border border-exl-orange text-exl-orange rounded-full hover:bg-exl-orange hover:text-white transition-colors"
      >
        <span>→</span> {action}
      </button>
      {copied && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2.5 py-1 bg-gray-900 text-white text-xs font-medium rounded-lg whitespace-nowrap z-10 pointer-events-none">
          Copied to clipboard
          <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-gray-900" />
        </div>
      )}
    </div>
  )
}

// ── Main message bubble ───────────────────────────────────
export default function RfpAiqMessageBubble({ message }) {
  // ── User bubble ──
  if (message.role === 'user') {
    return (
      <div className="flex justify-end mb-4">
        <div
          className="max-w-[80%] px-4 py-3 text-sm text-white rounded-2xl rounded-tr-sm leading-relaxed"
          style={{ backgroundColor: '#E05A2B' }}
        >
          {message.content}
        </div>
      </div>
    )
  }

  // ── RFP AIQ bubble — parse "Suggested action:" lines ──
  const lines = message.content.split('\n')
  const actionLines = []
  const bodyLines   = []

  lines.forEach(line => {
    if (line.trim().startsWith('Suggested action:')) {
      const text = line.replace(/^Suggested action:\s*/i, '').trim()
      if (text) actionLines.push(text)
    } else {
      bodyLines.push(line)
    }
  })

  // Trim trailing blank lines from body
  while (bodyLines.length && bodyLines[bodyLines.length - 1].trim() === '') {
    bodyLines.pop()
  }
  const bodyText = bodyLines.join('\n')

  return (
    <div className="flex items-start gap-3 mb-4">
      {/* Avatar */}
      <div
        className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
        style={{ backgroundColor: '#1F3864' }}
      >
        <span className="text-[9px] font-black tracking-tight" style={{ color: '#E05A2B' }}>
          AIQ
        </span>
      </div>

      <div className="flex-1 min-w-0">
        {/* Message body */}
        <div className="inline-block max-w-full bg-white dark:bg-[#253347] border border-gray-200 dark:border-gray-600 rounded-2xl rounded-tl-sm px-4 py-3 text-sm text-gray-800 dark:text-gray-200 leading-relaxed whitespace-pre-wrap">
          {bodyText}
        </div>

        {/* Action pills */}
        {actionLines.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {actionLines.map((action, i) => (
              <ActionPill key={i} action={action} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
