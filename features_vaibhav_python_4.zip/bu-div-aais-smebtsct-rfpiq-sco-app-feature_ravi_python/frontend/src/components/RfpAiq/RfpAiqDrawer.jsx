import React, { useState, useRef, useEffect } from 'react'
import { BrainCircuit, X, Send, Loader } from 'lucide-react'
import RfpAiqMessageBubble from './RfpAiqMessageBubble'

// ── Starter prompts shown when chat is empty ──────────────
const STARTER_PROMPTS = [
  "Which bids have suppliers that haven't responded?",
  'What pricing did suppliers submit for the latest bid?',
  'What are the compliance requirements for active bids?',
  'Summarize all uploaded RFP and pricing documents',
  'What items were in the Lakeview USD 2025 bid?',
  'What items are new in the 2026 Lakeview bid that were not in prior years?',
  'Which Lakeview items had the biggest quantity increase from 2022 to 2026?',
  'Were any items removed from the Lakeview bid between 2022 and 2026?',
]

// ── Typing indicator (animated 3 dots + delayed "thinking" label) ──
function TypingIndicator() {
  const [showLabel, setShowLabel] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setShowLabel(true), 500)
    return () => clearTimeout(t)
  }, [])
  return (
    <div className="flex items-start gap-3 mb-4">
      <div
        className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
        style={{ backgroundColor: '#1F3864' }}
      >
        <span className="text-[9px] font-black tracking-tight" style={{ color: '#E05A2B' }}>
          AIQ
        </span>
      </div>
      <div className="flex flex-col gap-1">
        <div className="bg-white dark:bg-[#253347] border border-gray-200 dark:border-gray-600 rounded-2xl rounded-tl-sm px-4 py-3.5 flex items-center gap-1.5">
          {[0, 150, 300].map(delay => (
            <span
              key={delay}
              className="w-2 h-2 rounded-full animate-bounce"
              style={{ backgroundColor: '#1F3864', animationDelay: `${delay}ms` }}
            />
          ))}
        </div>
        <span
          className="text-xs text-gray-400 pl-1 transition-opacity duration-300"
          style={{ opacity: showLabel ? 1 : 0 }}
        >
          RFP AIQ is thinking...
        </span>
      </div>
    </div>
  )
}

// ── Main drawer ───────────────────────────────────────────
export default function RfpAiqDrawer({ isOpen, onClose, messages, setMessages }) {
  const [input,     setInput]     = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error,     setError]     = useState(null)
  const bottomRef   = useRef(null)
  const inputRef    = useRef(null)

  // Auto-scroll to bottom after each message or typing indicator
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  // Focus input when drawer opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300)
    }
  }, [isOpen])

  const handleSend = async (text) => {
    const content = (text ?? input).trim()
    if (!content || isLoading) return

    setInput('')
    setError(null)

    const updatedMessages = [...messages, { role: 'user', content }]
    setMessages(updatedMessages)
    setIsLoading(true)

    try {
      const res  = await fetch('/api/ai/chat', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ messages: updatedMessages }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'RFP AIQ is unavailable right now')
      setMessages(prev => [...prev, { role: 'assistant', content: data.content }])
    } catch (err) {
      setError(err.message)
      // Remove the user message on hard failure so they can retry
      setMessages(prev => prev.slice(0, -1))
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/30 z-40 transition-opacity duration-300
          ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />

      {/* Drawer panel */}
      <div
        className={`fixed right-0 top-0 h-full bg-white dark:bg-[#1E293B] shadow-2xl z-50 flex flex-col
          transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
        style={{ width: 420 }}
      >
        {/* ── Header ── */}
        <div
          className="flex-shrink-0 px-5 py-4"
          style={{ backgroundColor: '#1F3864' }}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2.5">
              <BrainCircuit className="w-5 h-5" style={{ color: '#E05A2B' }} />
              <span className="text-white font-bold text-base tracking-wide">RFP AIQ</span>
            </div>
            <button
              onClick={onClose}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-white/50 text-xs">
            Ask anything about your bids, suppliers, documents &amp; emails
          </p>
        </div>

        {/* ── Chat area ── */}
        <div className="flex-1 overflow-y-auto px-5 py-5 dark:bg-[#0F172A]" style={{ backgroundColor: '#F7F8FA' }}>

          {/* Empty state — starter prompts */}
          {messages.length === 0 && !isLoading && (
            <div className="h-full flex flex-col items-center justify-center">
              <div className="text-center mb-6">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3"
                  style={{ backgroundColor: '#EBF3FB' }}
                >
                  <BrainCircuit size={22} style={{ color: '#1F3864' }} />
                </div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-200">Ask anything about your bids</p>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                  RFP AIQ has access to all bids, suppliers, emails and documents
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 w-full">
                {STARTER_PROMPTS.map(prompt => (
                  <button
                    key={prompt}
                    onClick={() => handleSend(prompt)}
                    className="text-left px-3 py-3 text-xs text-gray-700 dark:text-gray-300 font-medium bg-white dark:bg-[#253347] rounded-xl border border-gray-200 dark:border-gray-600 hover:border-exl-orange hover:text-exl-orange dark:hover:border-exl-orange dark:hover:text-orange-300 transition-colors leading-snug"
                    style={{ '--tw-ring-color': '#E05A2B' }}
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Messages */}
          {messages.length > 0 && (
            <>
              {messages.map((msg, i) => (
                <RfpAiqMessageBubble key={i} message={msg} />
              ))}
              {isLoading && <TypingIndicator />}
              {error && (
                <div className="mb-4 px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
                  ⚠ {error}
                </div>
              )}
            </>
          )}

          <div ref={bottomRef} />
        </div>

        {/* ── Input area ── */}
        <div className="flex-shrink-0 px-4 py-3 bg-white dark:bg-[#1E293B] border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-end gap-2">
            <textarea
              ref={inputRef}
              rows={1}
              value={input}
              onChange={e => {
                setInput(e.target.value)
                // Auto-grow textarea
                e.target.style.height = 'auto'
                e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
              }}
              onKeyDown={handleKeyDown}
              placeholder="Ask about your bids, suppliers, or documents…"
              disabled={isLoading}
              className="flex-1 resize-none px-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:border-exl-orange bg-white leading-relaxed disabled:opacity-50"
              style={{
                minHeight: 42,
                maxHeight: 120,
                '--tw-ring-color': 'rgba(224,90,43,0.3)',
              }}
            />
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
              className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center text-white transition-colors disabled:opacity-40"
              style={{ backgroundColor: '#E05A2B' }}
            >
              {isLoading
                ? <Loader className="w-4 h-4 animate-spin" />
                : <Send className="w-4 h-4" />
              }
            </button>
          </div>
          <p className="text-center text-xs text-gray-400 mt-2">
            RFP AIQ · Powered by EXL Service · Responses based on platform data only
          </p>
        </div>
      </div>
    </>
  )
}
