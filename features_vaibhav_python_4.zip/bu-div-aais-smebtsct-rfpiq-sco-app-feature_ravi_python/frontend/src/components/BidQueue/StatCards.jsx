import React from 'react'
import { TrendingUp, AlertTriangle, BarChart2, Layers } from 'lucide-react'
import { computeStats } from '../../utils/bidUtils'

// ── Info tooltip ──────────────────────────────────────────
// Small grey ⓘ circle; on hover shows a navy tooltip box below
function InfoTooltip({ text }) {
  return (
    <div className="relative group inline-flex flex-shrink-0">
      {/* Icon */}
      <span
        className="w-[15px] h-[15px] rounded-full bg-gray-200 hover:bg-gray-300 text-gray-500
                   text-[9px] font-bold flex items-center justify-center cursor-default
                   select-none leading-none transition-colors"
      >
        i
      </span>

      {/* Tooltip box — hidden until hover */}
      <div
        className="absolute left-0 top-[20px] z-50 hidden group-hover:block
                   w-[220px] bg-exl-navy text-white text-xs rounded-lg
                   px-3 py-2.5 shadow-xl leading-relaxed pointer-events-none"
      >
        {text}
      </div>
    </div>
  )
}

// ── Stat card ─────────────────────────────────────────────
function StatCard({ icon: Icon, label, value, sub, subCls, accent, iconBg, tooltip, subTitle, borderCls = '', pulse = false }) {
  return (
    <div className={`card px-5 py-4 flex items-center gap-4 card-hover border-l-4 ${borderCls} dark:shadow-gray-900`}>
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${iconBg}`}>
        <Icon className={`w-5 h-5 ${accent}`} />
      </div>

      <div className="min-w-0 flex-1">
        {/* Label row + tooltip icon */}
        <div className="flex items-center gap-1.5 mb-0.5">
          <p className="text-xs text-gray-500 font-medium uppercase tracking-wide leading-none">
            {label}
          </p>
          {tooltip && <InfoTooltip text={tooltip} />}
        </div>

        {/* Value */}
        <p className={`text-2xl font-bold leading-tight ${accent}`}>{value}</p>

        {/* Subtext */}
        {sub && (
          <div className="flex items-center gap-1.5 mt-0.5">
            {pulse && <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse flex-shrink-0" />}
            <p className={`text-xs truncate ${subCls ?? 'text-gray-400'}`} title={subTitle ?? sub}>{sub}</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ── StatCards container ───────────────────────────────────
export default function StatCards({ bids }) {
  const { total, atRisk, avgRate, segments, segmentNames } = computeStats(bids)

  // Card 4: segment names joined with · (full list in title attr for hover)
  const segmentSub = segmentNames.join(' · ')

  return (
    <div className="grid grid-cols-4 gap-4 mb-6">

      {/* ── Card 1: Active Bids ── */}
      <StatCard
        icon={Layers}
        label="Active Bids"
        value={total}
        sub={`across ${segments} segments`}
        accent="text-exl-navy"
        iconBg="bg-exl-navy/10"
        borderCls="border-l-[#1F3864]"
        tooltip="All bids currently in the system including Active, Solicitation, Working File, and Review stages. Excludes Awarded and Cancelled bids."
      />

      {/* ── Card 2: At Risk ── */}
      <StatCard
        icon={AlertTriangle}
        label="At Risk"
        value={atRisk}
        sub="internal due date within 7 days"
        subCls="text-red-700 font-semibold"
        accent="text-red-600"
        iconBg="bg-red-50"
        borderCls="border-l-red-500"
        pulse={atRisk > 0}
        tooltip="Bids where the internal due date is today or within the next 7 days, or where the due date has already passed. These bids need immediate action from the Bid COE team."
      />

      {/* ── Card 3: Supplier Response Rate ── */}
      <StatCard
        icon={BarChart2}
        label="Supplier Response Rate"
        value={`${avgRate}%`}
        sub="across bids in Solicitation stage"
        accent="text-exl-orange"
        iconBg="bg-exl-orange/10"
        borderCls="border-l-[#E05A2B]"
        tooltip="The average percentage of solicited suppliers who have submitted pricing responses, calculated only across bids currently in the Solicitation stage. Example: if 10 suppliers were solicited and 8 responded, the rate is 80%."
      />

      {/* ── Card 4: Segments Active ── */}
      <StatCard
        icon={TrendingUp}
        label="Segments Active"
        value={`${segments}/7`}
        sub={segmentSub}
        subTitle={segmentSub}
        accent="text-emerald-600"
        iconBg="bg-emerald-50"
        borderCls="border-l-emerald-500"
        tooltip="Number of distinct customer segments with at least one active bid in the system."
      />

    </div>
  )
}
