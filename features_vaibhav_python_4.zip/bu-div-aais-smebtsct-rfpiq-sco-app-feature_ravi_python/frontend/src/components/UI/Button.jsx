import React from 'react'
import { Loader2 } from 'lucide-react'

const variants = {
  primary:   'bg-[#E05A2B] hover:bg-[#C44E22] text-white border-transparent',
  secondary: 'bg-white hover:bg-gray-50 text-[#1F3864] border-[#1F3864] dark:bg-[#253347] dark:hover:bg-[#334155] dark:text-blue-300 dark:border-blue-400',
  ghost:     'bg-transparent hover:bg-gray-100 text-gray-600 border-transparent dark:hover:bg-gray-700 dark:text-gray-300',
  danger:    'bg-[#DC2626] hover:bg-red-700 text-white border-transparent',
  success:   'bg-[#16A34A] hover:bg-green-700 text-white border-transparent',
}

const sizes = {
  sm: 'px-3 py-1.5 text-xs gap-1.5 h-7',
  md: 'px-4 py-2 text-sm gap-2 h-9',
  lg: 'px-5 py-2.5 text-sm gap-2 h-11',
}

export const Button = ({
  variant = 'primary',
  size = 'md',
  icon: Icon,
  iconRight: IconRight,
  loading,
  disabled,
  children,
  className = '',
  ...props
}) => (
  <button
    disabled={disabled || loading}
    className={`
      inline-flex items-center justify-center
      font-medium rounded-lg border
      transition-all duration-150
      disabled:opacity-40 disabled:cursor-not-allowed
      focus:outline-none focus:ring-2
      focus:ring-[#E05A2B] focus:ring-offset-1
      ${variants[variant]}
      ${sizes[size]}
      ${className}
    `}
    {...props}
  >
    {loading ? (
      <Loader2 size={14} className="animate-spin" />
    ) : Icon ? (
      <Icon size={size === 'sm' ? 12 : 14} />
    ) : null}
    {children}
    {IconRight && !loading && (
      <IconRight size={size === 'sm' ? 12 : 14} />
    )}
  </button>
)

export const IconButton = ({
  icon: Icon,
  size = 'md',
  variant = 'ghost',
  title,
  className = '',
  ...props
}) => (
  <button
    title={title}
    className={`
      inline-flex items-center justify-center
      rounded-lg border transition-all duration-150
      disabled:opacity-40 disabled:cursor-not-allowed
      focus:outline-none focus:ring-2
      focus:ring-[#E05A2B] focus:ring-offset-1
      ${variants[variant]}
      ${size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-11 h-11' : 'w-9 h-9'}
      ${className}
    `}
    {...props}
  >
    <Icon size={size === 'sm' ? 12 : size === 'lg' ? 18 : 14} />
  </button>
)
