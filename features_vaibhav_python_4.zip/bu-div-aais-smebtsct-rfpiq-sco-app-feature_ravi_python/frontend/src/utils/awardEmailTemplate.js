export const buildAwardEmailSubject = (bid) =>
  `Award Notification — ${bid.customer} ${bid.id}`

export const buildAwardEmailBody = ({
  supplierName,
  customerName,
  bidId,
  contractStart = 'July 1, 2026',
  contractEnd   = 'June 30, 2027',
}) => `Dear ${supplierName},

We are pleased to inform you that Sysco has selected your company as part of the ${customerName} bid (${bidId}).

Please refer to the attached file for details of awarded items specific to your submission.

Contract Period: ${contractStart} — ${contractEnd}

Please ensure all compliance documentation (CN labels, PFS, Buy American certifications) is submitted within 5 business days.

Please confirm receipt of this award notification by replying to this email.

Thank you for your partnership.

Regards,
Sysco Bid COE
COE.BIDS@sysco.com`

export const buildAwardEmailDraft = ({ supplierName, supplierEmail, bid }) => ({
  to:      supplierEmail || '',
  subject: buildAwardEmailSubject(bid),
  body:    buildAwardEmailBody({ supplierName, customerName: bid.customer, bidId: bid.id }),
})
