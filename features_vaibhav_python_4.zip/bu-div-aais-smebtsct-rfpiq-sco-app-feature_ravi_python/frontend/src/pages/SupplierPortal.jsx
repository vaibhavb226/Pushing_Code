import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  CheckCircle, Upload, FileSpreadsheet, FileText, X,
  Loader, AlertCircle, Info, Send, Paperclip,
  ChevronDown, ChevronRight, MessageSquare, ArrowRight, Lock,
  Moon, Sun,
} from 'lucide-react'

// ─────────────────────────────────────────────────────────
// Dark mode hook — persists to localStorage['portal_theme']
// ─────────────────────────────────────────────────────────
function useDark() {
  const [dark, setDark] = useState(() => {
    try { return localStorage.getItem('portal_theme') === 'dark' } catch { return false }
  })
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
    try { localStorage.setItem('portal_theme', dark ? 'dark' : 'light') } catch {}
  }, [dark])
  return [dark, () => setDark(d => !d)]
}

// ─────────────────────────────────────────────────────────
// Utilities
// ─────────────────────────────────────────────────────────
function relativeTime(ts) {
  const diff = Date.now() - new Date(ts).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1)  return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24)  return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  if (days === 1) return 'yesterday'
  if (days < 30)  return `${days}d ago`
  return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

function fmtFull(ts) {
  return new Date(ts).toLocaleString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: 'numeric', minute: '2-digit', hour12: true,
  })
}

function getInitials(name) {
  if (!name) return '?'
  return name.trim().split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase()
}

// ─────────────────────────────────────────────────────────
// Shared sub-components
// ─────────────────────────────────────────────────────────
function CompliancePill({ label, color }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${color}`}>
      {label}
    </span>
  )
}

function ItemFlags({ item }) {
  return (
    <div className="flex gap-1 flex-wrap">
      {item.buyAmerican    && <span className="px-1 py-0.5 bg-red-100 text-red-700 text-xs rounded font-semibold dark:bg-red-900/40 dark:text-red-300">BA</span>}
      {item.childNutrition && <span className="px-1 py-0.5 bg-green-100 text-green-700 text-xs rounded font-semibold dark:bg-green-900/40 dark:text-green-300">CN</span>}
      {item.pfsRequired    && <span className="px-1 py-0.5 bg-purple-100 text-purple-700 text-xs rounded font-semibold dark:bg-purple-900/40 dark:text-purple-300">PFS</span>}
      {item.exactSpec      && <span className="px-1 py-0.5 bg-amber-100 text-amber-700 text-xs rounded font-semibold dark:bg-amber-900/40 dark:text-amber-300">ES</span>}
    </div>
  )
}

function FileDropZone({ file, onFile, onRemove, label = 'Drop file here or click to browse', sub = 'PDF or Excel · Max 25 MB' }) {
  const ref = useRef(null)
  const [dragging, setDragging] = useState(false)
  const accept = (f) => {
    if (!f) return
    if (!['pdf', 'xlsx', 'xls'].includes(f.name.split('.').pop().toLowerCase())) return
    onFile(f)
  }
  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => { e.preventDefault(); setDragging(false); accept(e.dataTransfer.files[0]) }}
      onClick={() => !file && ref.current?.click()}
      className={`border-2 border-dashed rounded-xl text-center transition-all cursor-pointer flex items-center justify-center
        ${file ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-600'
               : dragging ? 'border-[#E05A2B] bg-orange-50/30 dark:bg-orange-900/10'
               : 'border-gray-200 dark:border-gray-600 hover:border-[#E05A2B]/50 hover:bg-gray-50 dark:hover:bg-gray-700/30'}`}
      style={{ minHeight: 120 }}
    >
      <input ref={ref} type="file" accept=".pdf,.xlsx,.xls" className="hidden" onChange={e => accept(e.target.files[0])} />
      {file ? (
        <div className="flex items-center justify-center gap-2 px-4 py-3">
          {file.name.endsWith('.pdf')
            ? <FileText className="w-5 h-5 text-red-400" />
            : <FileSpreadsheet className="w-5 h-5 text-emerald-600" />}
          <span className="text-sm font-medium text-gray-800 dark:text-gray-200">{file.name}</span>
          <button type="button" onClick={e => { e.stopPropagation(); onRemove() }} className="text-gray-400 hover:text-red-500 ml-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="px-4 py-3">
          <Upload className="w-7 h-7 text-gray-300 dark:text-gray-500 mx-auto mb-2" />
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{label}</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{sub}</p>
        </div>
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// Portal header — shared by form and thread views
// ─────────────────────────────────────────────────────────
function PortalHeader({ customerName, bidId, segment, dueDate, complianceRequirements, dark, onToggleDark }) {
  const dueFmt = dueDate
    ? new Date(dueDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : null
  return (
    <>
      {/* Top nav bar */}
      <div className="bg-[#1F3864] sticky top-0 z-10 shadow-md">
        <div className="max-w-4xl mx-auto px-5 py-3.5 flex items-center gap-4">
          <div className="w-1 h-7 rounded-full bg-[#E05A2B] flex-shrink-0" />
          <div>
            <p className="text-white font-bold text-sm leading-tight tracking-tight">Sysco RFP AIQ</p>
            <p className="text-blue-300/80 text-xs">Supplier Pricing Portal</p>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-white/50 text-xs">Questions?</p>
              <a href="mailto:COE.BIDS@sysco.com" className="text-[#E05A2B] text-xs font-semibold hover:underline">
                COE.BIDS@sysco.com
              </a>
            </div>
            {onToggleDark && (
              <button
                type="button"
                onClick={onToggleDark}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors"
                title={dark ? 'Switch to light mode' : 'Switch to dark mode'}
              >
                {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            )}
          </div>
        </div>
        <div className="h-[3px] bg-gradient-to-r from-[#E05A2B] via-[#E05A2B]/70 to-transparent" />
      </div>

      {/* Bid info card */}
      {customerName && (
        <div className="max-w-4xl mx-auto px-4 sm:px-5 pt-5">
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl px-6 py-4 shadow-sm">
            <div className="flex items-start justify-between flex-wrap gap-3">
              <div>
                <p className="text-[10px] font-bold text-[#E05A2B] uppercase tracking-widest mb-1">Pricing Request</p>
                <h1 className="text-xl font-bold text-[#1F3864] dark:text-white leading-tight">{customerName}</h1>
                <div className="flex items-center gap-2.5 mt-1.5 text-sm text-gray-500 dark:text-gray-400 flex-wrap">
                  <span className="font-mono font-bold text-gray-700 dark:text-gray-300 text-xs">{bidId}</span>
                  {segment && <><span className="text-gray-300 dark:text-gray-600">·</span><span className="text-xs">{segment}</span></>}
                  {dueFmt  && <><span className="text-gray-300 dark:text-gray-600">·</span><span className="text-xs">Due <strong className="text-gray-800 dark:text-gray-200">{dueFmt}</strong></span></>}
                </div>
              </div>
              {complianceRequirements?.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {complianceRequirements.map((c, i) => <CompliancePill key={i} label={c.label} color={c.color} />)}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}

// ─────────────────────────────────────────────────────────
// Step indicator — 3-step progress bar
// ─────────────────────────────────────────────────────────
function StepIndicator({ steps, current }) {
  return (
    <div className="max-w-4xl mx-auto px-5 pt-4 pb-1">
      <div className="flex items-center gap-0">
        {steps.map((label, i) => {
          const idx   = i + 1
          const done  = idx < current
          const active = idx === current
          return (
            <React.Fragment key={idx}>
              <div className="flex items-center gap-2 min-w-0">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-colors
                    ${done   ? 'bg-emerald-500 text-white'
                             : active ? 'bg-[#E05A2B] text-white ring-4 ring-[#E05A2B]/20'
                             : 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500'}`}
                >
                  {done ? <CheckCircle className="w-4 h-4" /> : idx}
                </div>
                <span className={`text-xs font-semibold hidden sm:block whitespace-nowrap
                  ${active ? 'text-[#E05A2B]' : done ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-400 dark:text-gray-500'}`}>
                  {label}
                </span>
              </div>
              {i < steps.length - 1 && (
                <div className={`flex-1 h-0.5 mx-3 rounded-full ${done ? 'bg-emerald-400' : 'bg-gray-200 dark:bg-gray-700'}`} />
              )}
            </React.Fragment>
          )
        })}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// Avatar — colored circle with initials
// ─────────────────────────────────────────────────────────
function Avatar({ name, isSupplier }) {
  return (
    <div
      className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0 select-none"
      style={{ backgroundColor: isSupplier ? '#E05A2B' : '#1F3864' }}
      title={name}
    >
      {getInitials(name)}
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// Submission event card — top of every thread
// ─────────────────────────────────────────────────────────
function SubmissionEventCard({ thread }) {
  const [expanded, setExpanded] = useState(false)
  const lineItems = thread.lineItems || []
  const hasItems  = lineItems.some(li => parseFloat(li.unitPrice) > 0 || parseFloat(li.casePrice) > 0 || li.noBid)

  return (
    <div className="flex gap-3">
      <Avatar name={thread.contactName || thread.supplierName} isSupplier={true} />
      <div className="flex-1 min-w-0">

        <div className="flex items-baseline gap-2 mb-1.5 flex-wrap">
          <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{thread.contactName || thread.supplierName}</span>
          <span className="text-xs text-gray-500 dark:text-gray-400">submitted pricing</span>
          <span className="text-xs text-gray-400 dark:text-gray-500 cursor-default" title={fmtFull(thread.submittedAt)}>
            {relativeTime(thread.submittedAt)}
          </span>
        </div>

        <div
          className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-sm overflow-hidden"
          style={{ borderLeft: '4px solid #E05A2B' }}
        >
          <div className="px-5 py-4">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-base">📋</span>
              <span className="text-sm font-semibold text-gray-800 dark:text-gray-200">Pricing submitted via Supplier Portal</span>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400 mb-2">
              <span>
                <span className="font-semibold text-gray-900 dark:text-gray-100">{thread.pricedCount ?? 0}</span>
                {' '}item{(thread.pricedCount ?? 0) !== 1 ? 's' : ''} priced
              </span>
              {(thread.noBidCount ?? 0) > 0 && (
                <span>
                  <span className="font-semibold text-gray-900 dark:text-gray-100">{thread.noBidCount}</span> no-bid
                </span>
              )}
              {thread.pricingFile && (
                <span className="flex items-center gap-1 text-gray-500 dark:text-gray-400 text-xs">
                  <Paperclip className="w-3.5 h-3.5" />
                  <span className="font-mono">{thread.pricingFile}</span>
                </span>
              )}
            </div>

            <p className="text-xs text-gray-400 dark:text-gray-500 mb-3">
              Confirmation: <span className="font-mono text-gray-600 dark:text-gray-300">{thread.confirmationId}</span>
            </p>

            {hasItems && (
              <>
                <button
                  onClick={() => setExpanded(p => !p)}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#E05A2B] hover:underline"
                >
                  {expanded
                    ? <><ChevronDown className="w-3.5 h-3.5" /> Hide line items</>
                    : <><ChevronRight className="w-3.5 h-3.5" /> View line items</>
                  }
                </button>
                {expanded && (
                  <div className="mt-3 rounded-xl border border-gray-100 dark:border-gray-700 overflow-auto">
                    <table className="w-full text-xs" style={{ minWidth: 560 }}>
                      <thead>
                        <tr className="bg-gray-50 dark:bg-gray-700/60 border-b border-gray-100 dark:border-gray-600">
                          <th className="px-3 py-2 text-left font-semibold text-gray-500 dark:text-gray-400 w-14">Item #</th>
                          <th className="px-3 py-2 text-left font-semibold text-gray-500 dark:text-gray-400">Description</th>
                          <th className="px-3 py-2 text-right font-semibold text-gray-500 dark:text-gray-400 w-22">FOB $</th>
                          <th className="px-3 py-2 text-right font-semibold text-gray-500 dark:text-gray-400 w-24">Delivered $</th>
                          <th className="px-3 py-2 text-right font-semibold text-gray-500 dark:text-gray-400 w-20">Allowance $</th>
                          <th className="px-3 py-2 text-left font-semibold text-gray-500 dark:text-gray-400 w-20">Dev Type</th>
                          <th className="px-3 py-2 text-center font-semibold text-gray-500 dark:text-gray-400 w-20">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {lineItems.map((li, i) => {
                          const delivered = parseFloat(li.deliveredPrice || li.unitPrice) || 0
                          const fob       = parseFloat(li.fobPrice)       || 0
                          const allw      = parseFloat(li.allowance)      || 0
                          const priced    = !li.noBid && (delivered > 0 || fob > 0 || parseFloat(li.casePrice) > 0)
                          return (
                            <tr key={i} className="border-b border-gray-50 dark:border-gray-700/50 last:border-0">
                              <td className="px-3 py-1.5 font-mono text-gray-500 dark:text-gray-400">{li.itemNo}</td>
                              <td className="px-3 py-1.5 text-gray-700 dark:text-gray-300 max-w-[180px] truncate" title={li.description}>
                                {li.description}
                              </td>
                              <td className="px-3 py-1.5 text-right font-mono text-gray-700 dark:text-gray-300">
                                {fob > 0 ? `$${fob.toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-1.5 text-right font-mono text-gray-700 dark:text-gray-300 font-medium">
                                {delivered > 0 ? `$${delivered.toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-1.5 text-right font-mono text-gray-700 dark:text-gray-300">
                                {allw > 0 ? `$${allw.toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-1.5 text-gray-500 dark:text-gray-400">{li.devType || '—'}</td>
                              <td className="px-3 py-1.5 text-center">
                                {li.noBid
                                  ? <span className="px-1.5 py-0.5 bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 rounded font-semibold">No Bid</span>
                                  : priced
                                    ? <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 rounded font-semibold">Priced</span>
                                    : <span className="px-1.5 py-0.5 bg-gray-100 text-gray-400 rounded">—</span>
                                }
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// Message card — GitHub Issues style, all left-aligned
// ─────────────────────────────────────────────────────────
function MessageCard({ msg, supplierName }) {
  const isSupplier = msg.direction === 'inbound'
  const name       = msg.fromName || (isSupplier ? supplierName : 'Sysco Bid COE')
  const isUnread   = !isSupplier && !msg.readBySupplier

  return (
    <div className="flex gap-3">
      <Avatar name={isSupplier ? name : 'Sysco Bid COE'} isSupplier={isSupplier} />

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1.5 flex-wrap">
          <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{name}</span>
          {!isSupplier && (
            <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-[#1F3864]/10 dark:bg-[#1F3864]/40 text-[#1F3864] dark:text-blue-300">
              Sysco Bid COE
            </span>
          )}
          <span
            className="text-xs text-gray-400 cursor-default ml-auto"
            title={fmtFull(msg.timestamp)}
          >
            {relativeTime(msg.timestamp)}
          </span>
        </div>

        <div
          className={`rounded-2xl border shadow-sm overflow-hidden ${
            isUnread
              ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-700'
              : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
          }`}
          style={!isSupplier ? { borderLeft: '4px solid #1F3864' } : {}}
        >
          <div className="px-5 py-4">
            <p className="text-sm text-gray-800 dark:text-gray-200 leading-relaxed whitespace-pre-wrap">{msg.body}</p>

            {msg.attachments?.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {msg.attachments.map((a, i) => (
                  <a
                    key={i}
                    href={`/api/bids/portal-file/${encodeURIComponent(a)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 border border-gray-200 dark:border-gray-600 px-2.5 py-1 rounded-lg transition-colors"
                  >
                    <Paperclip className="w-3 h-3" />{a}
                  </a>
                ))}
              </div>
            )}

            {isUnread && (
              <p className="text-xs text-blue-500 font-semibold mt-2 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 inline-block" />
                New reply from Sysco Bid COE
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// THREAD VIEW  (/submit/:bidId/thread/:threadId)
// ─────────────────────────────────────────────────────────
function ThreadView({ bidId, threadId }) {
  const [dark, toggleDark] = useDark()

  const [emailInput,  setEmailInput]  = useState('')
  const [verified,    setVerified]    = useState(false)
  const [verifying,   setVerifying]   = useState(false)
  const [verifyError, setVerifyError] = useState(null)

  const [thread,    setThread]    = useState(null)
  const [messages,  setMessages]  = useState([])
  const [bid,       setBid]       = useState(null)

  const [msgText,   setMsgText]   = useState('')
  const [msgFile,   setMsgFile]   = useState(null)
  const [sending,   setSending]   = useState(false)
  const [sendError, setSendError] = useState(null)

  const [newMsgBanner, setNewMsgBanner] = useState(false)
  const [isScrolledUp, setIsScrolledUp] = useState(false)
  const threadEndRef  = useRef(null)
  const scrollAreaRef = useRef(null)
  const verifiedEmail = useRef('')

  useEffect(() => {
    fetch(`/api/submit/${bidId}`)
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (d) setBid(d) })
      .catch(() => {})
  }, [bidId])

  const fetchThread = useCallback(async (email) => {
    const r = await fetch(
      `/api/submit/${bidId}/thread/${threadId}?email=${encodeURIComponent(email)}`
    )
    if (!r.ok) {
      const d = await r.json()
      throw new Error(d.error || 'Verification failed')
    }
    return r.json()
  }, [bidId, threadId])

  const applyThreadData = (data) => {
    const { messages: msgs, ...meta } = data
    setThread(meta)
    setMessages(msgs || [])
  }

  const handleVerify = async () => {
    if (!emailInput.trim()) { setVerifyError('Please enter your email address.'); return }
    setVerifying(true)
    setVerifyError(null)
    try {
      const data = await fetchThread(emailInput.trim())
      verifiedEmail.current = emailInput.trim()
      applyThreadData(data)
      setVerified(true)
    } catch (err) {
      setVerifyError(err.message)
    } finally {
      setVerifying(false)
    }
  }

  const scrollToBottom = (smooth = true) => {
    threadEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'instant' })
  }

  const handleScroll = () => {
    const el = scrollAreaRef.current
    if (!el) return
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80
    setIsScrolledUp(!atBottom)
    if (atBottom) setNewMsgBanner(false)
  }

  useEffect(() => {
    if (verified && messages.length > 0) {
      setTimeout(() => scrollToBottom(false), 60)
    }
  }, [verified])

  useEffect(() => {
    if (!verified) return
    if (isScrolledUp) {
      setNewMsgBanner(true)
    } else {
      scrollToBottom()
    }
  }, [messages.length]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!verified) return
    const poll = setInterval(async () => {
      try {
        const data = await fetchThread(verifiedEmail.current)
        if (data.messageCount > messages.length) {
          applyThreadData(data)
          if (!isScrolledUp) {
            setTimeout(() => scrollToBottom(), 50)
          }
        }
      } catch { /* silent */ }
    }, 15000)
    return () => clearInterval(poll)
  }, [verified, messages.length, isScrolledUp, fetchThread])

  const handleSendMessage = async (e) => {
    e.preventDefault()
    if (!msgText.trim()) return
    setSending(true)
    setSendError(null)
    try {
      const form = new FormData()
      form.append('threadId',      threadId)
      form.append('supplierEmail', verifiedEmail.current)
      form.append('message',       msgText.trim())
      if (msgFile) form.append('file', msgFile)

      const r = await fetch(`/api/submit/${bidId}/message`, { method: 'POST', body: form })
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Send failed') }

      setMsgText('')
      setMsgFile(null)
      setIsScrolledUp(false)
      setNewMsgBanner(false)

      const fresh = await fetchThread(verifiedEmail.current)
      applyThreadData(fresh)
      setTimeout(() => scrollToBottom(), 50)
    } catch (err) {
      setSendError(err.message)
    } finally {
      setSending(false)
    }
  }

  if (!verified) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <PortalHeader
          customerName={bid?.customerName}
          bidId={bidId}
          segment={bid?.segment}
          dueDate={bid?.dueDate}
          complianceRequirements={bid?.complianceRequirements}
          dark={dark}
          onToggleDark={toggleDark}
        />
        <div className="flex items-center justify-center min-h-[calc(100vh-120px)] p-6">
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl p-8 shadow-sm w-full max-w-sm text-center">
            <div className="w-14 h-14 bg-gray-100 dark:bg-gray-700 rounded-2xl flex items-center justify-center mx-auto mb-5">
              <Lock className="w-7 h-7 text-gray-500 dark:text-gray-400" />
            </div>
            <h2 className="text-lg font-bold text-[#1F3864] dark:text-white mb-1">Verify your identity</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Enter the email address you used to submit your pricing response.
            </p>

            <div className="text-left mb-4">
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                value={emailInput}
                onChange={e => setEmailInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleVerify()}
                placeholder="pricing@company.com"
                className="w-full px-3 py-2.5 text-sm border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E05A2B]/30 focus:border-[#E05A2B] bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500"
                autoFocus
              />
            </div>

            {verifyError && (
              <div className="flex items-center gap-2 text-xs text-red-600 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-700 rounded-lg px-3 py-2 mb-3">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />{verifyError}
              </div>
            )}

            <button
              onClick={handleVerify}
              disabled={verifying}
              className="w-full py-2.5 rounded-xl text-white font-semibold text-sm disabled:opacity-50 flex items-center justify-center gap-2 mb-4"
              style={{ backgroundColor: '#E05A2B' }}
            >
              {verifying
                ? <><Loader className="w-4 h-4 animate-spin" /> Verifying…</>
                : <>Continue <ArrowRight className="w-4 h-4" /></>
              }
            </button>

            <p className="text-xs text-gray-400 dark:text-gray-500">
              Having trouble?{' '}
              <a href="mailto:COE.BIDS@sysco.com" className="text-[#E05A2B] hover:underline">
                Contact COE.BIDS@sysco.com
              </a>
            </p>
          </div>
        </div>
      </div>
    )
  }

  const conversationMessages = messages.slice(1)

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col">
      <PortalHeader
        customerName={thread?.customerName}
        bidId={bidId}
        segment={bid?.segment}
        dueDate={bid?.dueDate}
        complianceRequirements={bid?.complianceRequirements}
        dark={dark}
        onToggleDark={toggleDark}
      />

      <div className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-5 py-6 flex flex-col">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-[#1F3864] dark:text-white mb-1">
            Pricing Submission — {thread?.supplierName}
          </h2>
          <div className="flex items-center flex-wrap gap-2 text-sm text-gray-500 dark:text-gray-400">
            <span className="font-mono text-xs text-gray-400 dark:text-gray-500">#{thread?.confirmationId}</span>
            <span className="text-gray-300 dark:text-gray-600">·</span>
            <span>
              Opened{' '}
              <span className="cursor-default" title={fmtFull(thread?.submittedAt)}>
                {relativeTime(thread?.submittedAt)}
              </span>
              {' '}by{' '}
              <strong className="text-gray-700 dark:text-gray-300">{thread?.contactName}</strong>
            </span>
            <span className="text-gray-300 dark:text-gray-600">·</span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              Responded
            </span>
            <span className="ml-auto text-xs text-gray-400 dark:text-gray-500">
              {messages.length} message{messages.length !== 1 ? 's' : ''}
            </span>
          </div>
        </div>

        <div
          ref={scrollAreaRef}
          onScroll={handleScroll}
          className="space-y-5 overflow-y-auto pb-4"
          style={{ maxHeight: 'calc(100vh - 420px)', minHeight: 260 }}
        >
          {thread && <SubmissionEventCard thread={thread} />}

          {conversationMessages.map(msg => (
            <MessageCard
              key={msg.id}
              msg={msg}
              supplierName={thread?.contactName || thread?.supplierName}
            />
          ))}

          <div ref={threadEndRef} />
        </div>

        {newMsgBanner && (
          <button
            onClick={() => {
              setIsScrolledUp(false)
              setNewMsgBanner(false)
              scrollToBottom()
            }}
            className="flex items-center justify-center gap-2 w-full py-2 mb-3 rounded-xl text-sm font-semibold text-white hover:opacity-90 transition-opacity shadow-md"
            style={{ backgroundColor: '#1F3864' }}
          >
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            New message from Sysco Bid COE — click to view
          </button>
        )}

        <div className="mt-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-sm overflow-hidden">
          <div className="flex gap-3 px-5 pt-4 pb-2">
            <Avatar
              name={thread?.contactName || thread?.supplierName}
              isSupplier={true}
            />
            <textarea
              value={msgText}
              onChange={e => setMsgText(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  if (msgText.trim()) handleSendMessage(e)
                }
              }}
              placeholder="Leave a comment… (Enter to send, Shift+Enter for new line)"
              rows={3}
              className="flex-1 px-0 py-1 text-sm text-gray-800 dark:text-gray-200 border-0 focus:outline-none focus:ring-0 resize-none placeholder-gray-400 dark:placeholder-gray-500 bg-transparent leading-relaxed"
            />
          </div>

          {msgFile && (
            <div className="mx-5 mb-2 flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-700 rounded-lg px-3 py-1.5">
              <Paperclip className="w-3.5 h-3.5 text-emerald-600" />{msgFile.name}
              <button type="button" onClick={() => setMsgFile(null)} className="ml-auto text-gray-400 hover:text-red-500">
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          {sendError && (
            <p className="mx-5 mb-2 text-xs text-red-600">{sendError}</p>
          )}

          <div className="flex items-center gap-2 px-5 pb-4 border-t border-gray-100 dark:border-gray-700 pt-3">
            <label className="cursor-pointer inline-flex items-center gap-1.5 text-xs font-semibold text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors">
              <Paperclip className="w-3.5 h-3.5" /> Attach file
              <input
                type="file"
                accept=".pdf,.xlsx,.xls"
                className="hidden"
                onChange={e => e.target.files[0] && setMsgFile(e.target.files[0])}
              />
            </label>
            <button
              onClick={handleSendMessage}
              disabled={sending || !msgText.trim()}
              className="ml-auto flex items-center gap-2 px-4 py-2 rounded-xl text-white font-semibold text-sm disabled:opacity-50 transition-opacity hover:opacity-90"
              style={{ backgroundColor: '#E05A2B' }}
            >
              {sending
                ? <><Loader className="w-4 h-4 animate-spin" /> Sending…</>
                : <><Send className="w-4 h-4" /> Send Message</>
              }
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-gray-400 dark:text-gray-500 mt-4 pb-6">
          Replies are also sent to your email · Questions?{' '}
          <a href="mailto:COE.BIDS@sysco.com" className="text-[#E05A2B] hover:underline">COE.BIDS@sysco.com</a>
        </p>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// SUBMISSION FORM  (/submit/:bidId)
// ─────────────────────────────────────────────────────────
function SubmissionForm({ bidId }) {
  const navigate = useNavigate()
  const [dark, toggleDark] = useDark()

  const [bid,       setBid]       = useState(null)
  const [loading,   setLoading]   = useState(true)
  const [fetchErr,  setFetchErr]  = useState(null)

  const [supplierName, setSupplierName] = useState('')
  const [contactName,  setContactName]  = useState('')
  const [email,        setEmail]        = useState('')
  const [phone,        setPhone]        = useState('')
  const [notes,        setNotes]        = useState('')
  const [file,         setFile]         = useState(null)
  const [prices,       setPrices]       = useState([])
  const [submitting,   setSubmitting]   = useState(false)
  const [submitted,    setSubmitted]    = useState(null)
  const [submitErr,    setSubmitErr]    = useState(null)

  useEffect(() => {
    fetch(`/api/submit/${bidId}`)
      .then(r => r.ok ? r.json() : r.json().then(d => Promise.reject(new Error(d.error || 'Not found'))))
      .then(d => {
        setBid(d)
        setPrices(d.lineItems.map(li => ({
          itemId:         li.id,
          itemNo:         li.bidItem,
          mpcCode:        li.mpcCode     || '',
          description:    li.description || '',
          category:       li.category    || '',
          fobPrice:       '',
          deliveredPrice: '',
          allowance:      '',
          ptvValue:       '',
          devType:        '',
          noBid:          false,
          notes:          '',
          // PORTAL-TEMPLATE-START
          customFields:   {},
          // PORTAL-TEMPLATE-END
        })))
      })
      .catch(err => setFetchErr(err.message))
      .finally(() => setLoading(false))
  }, [bidId])

  const updatePrice = (idx, field, value) =>
    setPrices(prev => prev.map((p, i) => {
      if (i !== idx) return p
      if (field === 'noBid' && value) {
        return { ...p, noBid: true, fobPrice: '', deliveredPrice: '', allowance: '', ptvValue: '', devType: '', notes: '' }
      }
      return { ...p, [field]: value }
    }))

  // PORTAL-TEMPLATE-START
  const updateCustomField = (idx, fieldId, val) =>
    setPrices(prev => prev.map((p, i) => i !== idx ? p : {
      ...p,
      customFields: { ...(p.customFields || {}), [fieldId]: val },
    }))
  // PORTAL-TEMPLATE-END

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitErr(null)
    if (!supplierName.trim()) { setSubmitErr('Company Name is required.'); return }
    if (!contactName.trim())  { setSubmitErr('Contact Name is required.'); return }
    if (!email.trim())        { setSubmitErr('Email Address is required.'); return }
    setSubmitting(true)
    try {
      const form = new FormData()
      form.append('supplierName',   supplierName.trim())
      form.append('supplierEmail',  email.trim())
      form.append('contactName',    contactName.trim())
      form.append('phone',          phone.trim())
      form.append('notes',          notes.trim())
      form.append('lineItemPrices', JSON.stringify(prices.map(p => ({
        itemId:         p.itemId,
        itemNo:         p.itemNo,
        mpcCode:        p.mpcCode,
        description:    p.description,
        fobPrice:       parseFloat(p.fobPrice)       || 0,
        deliveredPrice: parseFloat(p.deliveredPrice) || 0,
        allowance:      parseFloat(p.allowance)      || 0,
        ptvValue:       parseFloat(p.ptvValue)        || 0,
        devType:        p.devType || '',
        noBid:          p.noBid,
        notes:          p.notes,
        // PORTAL-TEMPLATE-START
        customFieldValues: p.customFields || {},
        // PORTAL-TEMPLATE-END
      }))))
      if (file) form.append('pricingFile', file)
      const res  = await fetch(`/api/submit/${bidId}`, { method: 'POST', body: form })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Submission failed')
      setSubmitted(data)
    } catch (err) {
      setSubmitErr(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  // Derive current step for indicator
  const detailsDone = supplierName.trim() && contactName.trim() && email.trim()
  const anyPriced   = prices.some(p => p.noBid || p.deliveredPrice || p.fobPrice || p.allowance)
  const currentStep = !detailsDone ? 1 : !anyPriced ? 2 : 3

  const pricedCount = prices.filter(p => !p.noBid && (p.deliveredPrice || p.fobPrice)).length
  const noBidCount  = prices.filter(p => p.noBid).length

  const inputCls = 'w-full px-3 py-2.5 text-sm border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E05A2B]/30 focus:border-[#E05A2B] bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500'
  const labelCls = 'block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1.5'
  const sectionHeadCls = 'text-sm font-bold text-[#1F3864] dark:text-white flex items-center gap-2.5'

  if (loading) return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
      <Loader className="w-6 h-6 animate-spin text-[#E05A2B]" />
      <span className="ml-3 text-gray-500 dark:text-gray-400">Loading bid information…</span>
    </div>
  )

  if (fetchErr || !bid) return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-6">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-8 max-w-md w-full text-center">
        <AlertCircle className="w-10 h-10 text-red-400 mx-auto mb-4" />
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Bid Not Found</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">{fetchErr || `No bid found for "${bidId}".`}</p>
        <p className="text-xs text-gray-400 dark:text-gray-500 mt-3">
          Contact <a href="mailto:COE.BIDS@sysco.com" className="text-[#E05A2B] hover:underline">COE.BIDS@sysco.com</a>
        </p>
      </div>
    </div>
  )

  // ── Success screen ──────────────────────────────────────
  if (submitted) {
    const dueFmt = bid.dueDate
      ? new Date(bid.dueDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
      : ''
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <PortalHeader
          customerName={bid.customerName}
          bidId={bid.bidId}
          segment={bid.segment}
          dueDate={bid.dueDate}
          complianceRequirements={bid.complianceRequirements}
          dark={dark}
          onToggleDark={toggleDark}
        />
        <div className="flex items-center justify-center min-h-[calc(100vh-160px)] p-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-8 max-w-lg w-full text-center">
            {/* Animated checkmark */}
            <div className="relative w-20 h-20 mx-auto mb-6">
              <div className="absolute inset-0 rounded-full bg-emerald-100 dark:bg-emerald-900/40 animate-ping opacity-20" />
              <div className="relative w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>

            <h2 className="text-2xl font-bold text-[#1F3864] dark:text-white mb-2">Submission Received</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Thank you <strong className="text-gray-800 dark:text-gray-200">{submitted.supplierName}</strong>. Your pricing response for{' '}
              <strong className="text-gray-800 dark:text-gray-200">{submitted.customerName}</strong> has been received.
            </p>

            {/* Confirmation box */}
            <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-700 rounded-xl px-5 py-4 text-left space-y-2 mb-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Confirmation ID</span>
                <span className="font-mono font-bold text-[#1F3864] dark:text-white">{submitted.confirmationId}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Submitted to</span>
                <span className="font-medium text-gray-800 dark:text-gray-200">{submitted.customerName}</span>
              </div>
              {dueFmt && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">Bid due date</span>
                  <span className="font-medium text-gray-800 dark:text-gray-200">{dueFmt}</span>
                </div>
              )}
            </div>

            {/* Pricing summary */}
            {(submitted.pricedCount != null || submitted.noBidCount != null) && (
              <div className="bg-white dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 rounded-xl px-5 py-4 text-left mb-6">
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2.5">Pricing Summary</p>
                <div className="space-y-1.5">
                  {submitted.dlCount > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300"><span className="font-semibold">{submitted.dlCount}</span> items — Delivered (DL)</span>
                    </div>
                  )}
                  {submitted.allwCount > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300"><span className="font-semibold">{submitted.allwCount}</span> items — Allowance (ALLW)</span>
                    </div>
                  )}
                  {submitted.otherPricedCount > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300"><span className="font-semibold">{submitted.otherPricedCount}</span> items priced</span>
                    </div>
                  )}
                  {submitted.noBidCount > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <X className="w-4 h-4 text-red-400 flex-shrink-0" />
                      <span className="text-gray-500 dark:text-gray-400"><span className="font-semibold">{submitted.noBidCount}</span> items No Bid</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {submitted.threadId && (
              <button
                onClick={() => navigate(`/submit/${bidId}/thread/${submitted.threadId}`)}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-white font-semibold text-sm mb-3 hover:opacity-90 transition-opacity"
                style={{ backgroundColor: '#E05A2B' }}
              >
                <MessageSquare className="w-4 h-4" /> View Conversation <ArrowRight className="w-4 h-4" />
              </button>
            )}

            <p className="text-xs text-gray-400 dark:text-gray-500">
              Save your Confirmation ID for your records. Questions?{' '}
              <a href="mailto:COE.BIDS@sysco.com" className="text-[#E05A2B] hover:underline">COE.BIDS@sysco.com</a>
            </p>
          </div>
        </div>
      </div>
    )
  }

  const dueFmt = bid.dueDate
    ? new Date(bid.dueDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : 'TBD'

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-24">
      <PortalHeader
        customerName={bid.customerName}
        bidId={bid.bidId}
        segment={bid.segment}
        dueDate={bid.dueDate}
        complianceRequirements={bid.complianceRequirements}
        dark={dark}
        onToggleDark={toggleDark}
      />

      <StepIndicator
        steps={['Your Details', 'Line Item Pricing', 'Submit']}
        current={currentStep}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-5 py-4">
        {/* Instruction banner */}
        <div className="flex items-start gap-2.5 px-3.5 py-3 bg-[#EBF3FB] dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-xl mb-5">
          <Info className="w-3.5 h-3.5 text-blue-500 dark:text-blue-400 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-blue-700 dark:text-blue-300">
            Complete pricing below and submit by <strong>{dueFmt}</strong>.
            You may also upload a pricing document. After submitting you can view and continue the conversation.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* ── Step 1: Company Details ───────────────────── */}
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl overflow-hidden shadow-sm">
            <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-700" style={{ borderLeft: '4px solid #1F3864' }}>
              <h2 className={sectionHeadCls}>
                <span className="w-6 h-6 rounded-full bg-[#1F3864] dark:bg-[#1F3864]/80 text-white text-xs flex items-center justify-center font-bold flex-shrink-0">1</span>
                Your Company Details
              </h2>
            </div>
            <div className="px-6 py-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Company Name <span className="text-red-500">*</span></label>
                  <input type="text" value={supplierName} onChange={e => setSupplierName(e.target.value)} placeholder="e.g. Schwan's Food Service, Inc." required className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Contact Name <span className="text-red-500">*</span></label>
                  <input type="text" value={contactName} onChange={e => setContactName(e.target.value)} placeholder="Your full name" required className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Email Address <span className="text-red-500">*</span></label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="pricing@company.com" required className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Phone (optional)</label>
                  <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="800-000-0000" className={inputCls} />
                </div>
              </div>
            </div>
          </div>

          {/* ── Step 2: Line Item Pricing ─────────────────── */}
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl overflow-hidden shadow-sm">
            <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-700" style={{ borderLeft: '4px solid #1F3864' }}>
              <div className="flex items-center justify-between">
                <h2 className={sectionHeadCls}>
                  <span className="w-6 h-6 rounded-full bg-[#1F3864] dark:bg-[#1F3864]/80 text-white text-xs flex items-center justify-center font-bold flex-shrink-0">2</span>
                  Line Item Pricing
                  <span className="text-xs font-normal text-gray-500 dark:text-gray-400 ml-1">({bid.lineItems.length} items)</span>
                </h2>
                {(pricedCount > 0 || noBidCount > 0) && (
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400">{pricedCount}</span> priced
                    {noBidCount > 0 && <> · <span className="font-semibold text-red-500">{noBidCount}</span> no bid</>}
                  </span>
                )}
              </div>
            </div>

            {/* Field legend */}
            <div className="mx-5 mt-4 mb-2 flex items-start gap-2 px-3.5 py-2.5 bg-[#EBF3FB] dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-xl">
              <Info className="w-3.5 h-3.5 text-blue-500 dark:text-blue-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-blue-700 dark:text-blue-300 italic">
                <span className="font-semibold not-italic">★ Delivered $/cs</span> is the primary pricing field Sysco uses.
                FOB, Allowance and PTV are supplementary — leave blank if not applicable to your submission.
              </p>
            </div>

            <div className="overflow-x-auto pb-2">
              <table className="text-xs" style={{ minWidth: 1100, width: '100%' }}>
                <thead>
                  {/* Sticky navy header */}
                  <tr className="sticky top-0 z-[5]" style={{ backgroundColor: '#1F3864' }}>
                    <th className="px-2 py-3 text-left font-semibold text-white/80" style={{ width: 50 }}>Item #</th>
                    <th className="px-2 py-3 text-left font-semibold text-white/80" style={{ width: 200 }}>Description</th>
                    <th className="px-2 py-3 text-left font-semibold text-white/80" style={{ width: 80 }}>Category</th>
                    <th className="px-2 py-3 text-left font-semibold text-white/80" style={{ width: 80 }}>Flags</th>
                    <th className="px-2 py-3 text-right font-semibold text-white/80" style={{ width: 90 }} title="FOB (Free on Board) — price at point of origin before freight">FOB $/cs</th>
                    <th className="px-2 py-3 text-right font-semibold" style={{ width: 110, color: '#F5C842' }} title="Final delivered price per case including all freight charges">
                      Delivered $/cs ★
                    </th>
                    <th className="px-2 py-3 text-right font-semibold text-white/80" style={{ width: 90 }} title="Off-invoice allowance per case (ALLW) — discount applied after invoice">Allowance $</th>
                    <th className="px-2 py-3 text-right font-semibold text-white/80" style={{ width: 80 }} title="Pass-Through Value — USDA commodity value per case for NOI items">PTV $</th>
                    <th className="px-2 py-3 text-left font-semibold text-white/80" style={{ width: 120 }} title="Development type — how the pricing allowance is structured">Dev Type</th>
                    <th className="px-2 py-3 text-center font-semibold text-white/80" style={{ width: 60 }}>No Bid</th>
                    <th className="px-2 py-3 text-left font-semibold text-white/80" style={{ width: 120 }}>Notes</th>
                    {/* PORTAL-TEMPLATE-START */}
                    {(bid.portalConfig?.customFields || []).map(field => (
                      <th key={field.id} className="px-2 py-3 text-left font-semibold text-white/80" style={{ width: field.columnWidth || 100 }}>
                        {field.label}{field.required && <span className="text-red-400 ml-0.5">*</span>}
                      </th>
                    ))}
                    {/* PORTAL-TEMPLATE-END */}
                  </tr>
                </thead>
                <tbody>
                  {bid.lineItems.map((li, idx) => {
                    const row = prices[idx] || {}
                    const dis = !!row.noBid
                    // Borderless inputs with bottom border, focus shows orange underline
                    const numBase = `w-full px-1 py-1 text-right bg-transparent border-0 border-b focus:outline-none focus:border-[#E05A2B] text-xs transition-colors`
                    const numCls  = `${numBase} ${dis ? 'border-gray-100 dark:border-gray-700 text-gray-300 dark:text-gray-600' : 'border-gray-200 dark:border-gray-600 text-gray-800 dark:text-gray-200'}`
                    return (
                      <tr
                        key={li.id}
                        className={`border-b border-gray-50 dark:border-gray-700/50 transition-colors group
                          ${idx % 2 === 0 ? 'bg-white dark:bg-gray-800' : 'bg-gray-50/40 dark:bg-gray-750'}
                          ${dis ? 'opacity-50' : 'hover:bg-[#EBF3FB] dark:hover:bg-blue-900/10'}`}
                      >
                        <td className="px-2 py-2 font-mono text-gray-500 dark:text-gray-400">{li.bidItem}</td>
                        <td className="px-2 py-2">
                          <p className="font-medium text-gray-900 dark:text-gray-100 truncate" style={{ maxWidth: 190 }} title={li.description}>{li.description}</p>
                        </td>
                        <td className="px-2 py-2 text-gray-500 dark:text-gray-400">{li.category || '—'}</td>
                        <td className="px-2 py-2"><ItemFlags item={li} /></td>
                        <td className="px-2 py-1.5">
                          <input type="number" step="0.01" min="0" value={row.fobPrice || ''} disabled={dis}
                            onChange={e => updatePrice(idx, 'fobPrice', e.target.value)} placeholder="0.00"
                            className={numCls} />
                        </td>
                        <td className="px-2 py-1.5">
                          <input type="number" step="0.01" min="0" value={row.deliveredPrice || ''} disabled={dis}
                            onChange={e => updatePrice(idx, 'deliveredPrice', e.target.value)} placeholder="0.00"
                            className={`${numCls} ${!dis ? 'font-semibold text-[#1F3864] dark:text-blue-300 border-[#E05A2B]/50' : ''}`} />
                        </td>
                        <td className="px-2 py-1.5">
                          <input type="number" step="0.01" min="0" value={row.allowance || ''} disabled={dis}
                            onChange={e => updatePrice(idx, 'allowance', e.target.value)} placeholder="0.00"
                            className={numCls} />
                        </td>
                        <td className="px-2 py-1.5">
                          <input type="number" step="0.01" min="0" value={row.ptvValue || ''} disabled={dis}
                            onChange={e => updatePrice(idx, 'ptvValue', e.target.value)} placeholder="0.00"
                            className={numCls} />
                        </td>
                        <td className="px-2 py-1.5">
                          <select value={row.devType || ''} disabled={dis}
                            onChange={e => updatePrice(idx, 'devType', e.target.value)}
                            className={`w-full px-1 py-1 border-0 border-b focus:outline-none focus:border-[#E05A2B] text-xs bg-transparent transition-colors cursor-pointer
                              ${dis ? 'border-gray-100 dark:border-gray-700 text-gray-300 dark:text-gray-600' : 'border-gray-200 dark:border-gray-600 text-gray-800 dark:text-gray-200'}`}>
                            <option value="">-- Select --</option>
                            <option value="DL">DL (Delivered)</option>
                            <option value="ALLW">ALLW (Allowance)</option>
                            <option value="NOI">NOI (Net Off Invoice)</option>
                            <option value="COST">COST (Cost Plus)</option>
                          </select>
                        </td>
                        <td className="px-2 py-2 text-center">
                          <input type="checkbox" checked={!!row.noBid}
                            onChange={e => updatePrice(idx, 'noBid', e.target.checked)}
                            className="w-4 h-4 rounded border-gray-300 cursor-pointer"
                            style={{ accentColor: '#E05A2B' }} />
                        </td>
                        <td className="px-2 py-1.5">
                          <input type="text" value={row.notes || ''} disabled={dis}
                            onChange={e => updatePrice(idx, 'notes', e.target.value)} placeholder="e.g. MOQ 50cs"
                            className={`w-full px-1 py-1 border-0 border-b focus:outline-none focus:border-[#E05A2B] text-xs bg-transparent transition-colors
                              ${dis ? 'border-gray-100 dark:border-gray-700 text-gray-300 dark:text-gray-600' : 'border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300'}`} />
                        </td>
                        {/* PORTAL-TEMPLATE-START */}
                        {(bid.portalConfig?.customFields || []).map(field => (
                          <td key={field.id} className="px-2 py-1.5">
                            {field.type === 'yes_no' ? (
                              <select
                                value={row.customFields?.[field.id] || ''}
                                onChange={e => updateCustomField(idx, field.id, e.target.value)}
                                className="w-full px-1 py-1 border-0 border-b border-gray-200 dark:border-gray-600 bg-transparent focus:outline-none focus:border-[#E05A2B] text-xs text-gray-800 dark:text-gray-200 transition-colors"
                              >
                                <option value="">—</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                              </select>
                            ) : field.type === 'number' ? (
                              <input
                                type="number"
                                value={row.customFields?.[field.id] || ''}
                                onChange={e => updateCustomField(idx, field.id, e.target.value)}
                                placeholder="0"
                                className="w-full px-1 py-1 text-right border-0 border-b border-gray-200 dark:border-gray-600 bg-transparent focus:outline-none focus:border-[#E05A2B] text-xs text-gray-800 dark:text-gray-200 transition-colors"
                              />
                            ) : (
                              <input
                                type="text"
                                value={row.customFields?.[field.id] || ''}
                                onChange={e => updateCustomField(idx, field.id, e.target.value)}
                                placeholder={field.placeholder || '—'}
                                className="w-full px-1 py-1 border-0 border-b border-gray-200 dark:border-gray-600 bg-transparent focus:outline-none focus:border-[#E05A2B] text-xs text-gray-700 dark:text-gray-300 transition-colors"
                              />
                            )}
                          </td>
                        ))}
                        {/* PORTAL-TEMPLATE-END */}
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* ── File upload ───────────────────────────────── */}
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl px-6 py-5 shadow-sm">
            <div className="mb-3" style={{ borderLeft: '4px solid #1F3864', paddingLeft: '0.875rem' }}>
              <h2 className="text-sm font-bold text-[#1F3864] dark:text-white">
                Upload Pricing Document{' '}
                <span className="text-xs font-normal text-gray-400 dark:text-gray-500">(optional)</span>
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Upload a completed pricing Excel or PDF in addition to the line-item prices above.</p>
            </div>
            <FileDropZone file={file} onFile={setFile} onRemove={() => setFile(null)} />
          </div>

          {/* ── Notes ────────────────────────────────────── */}
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl px-6 py-5 shadow-sm">
            <label className={labelCls}>Additional Notes or Comments</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3}
              placeholder="Include any qualifications, exceptions, or notes about your submission…"
              className={`${inputCls} resize-none`} />
          </div>

          {submitErr && (
            <div className="flex items-start gap-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-xl px-4 py-3">
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700 dark:text-red-300">{submitErr}</p>
            </div>
          )}
        </form>
      </div>

      {/* ── Sticky submit bar ─────────────────────────────── */}
      <div className="fixed bottom-0 left-0 right-0 z-20 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-[0_-4px_16px_rgba(0,0,0,0.08)]">
        <div className="max-w-4xl mx-auto px-5 py-3.5 flex items-center gap-4">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {pricedCount > 0 || noBidCount > 0 ? (
                <>
                  <span className="font-semibold text-emerald-600 dark:text-emerald-400">{pricedCount}</span> of {prices.length} items priced
                  {noBidCount > 0 && <> · <span className="font-semibold text-red-500">{noBidCount}</span> No Bid</>}
                </>
              ) : (
                <span className="text-gray-400 dark:text-gray-500">Fill in pricing for at least one line item</span>
              )}
            </p>
          </div>
          <button
            type="submit"
            form=""
            onClick={handleSubmit}
            disabled={submitting}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-white font-semibold text-sm disabled:opacity-50 hover:opacity-90 active:scale-[0.99] transition-all shadow-sm"
            style={{ backgroundColor: '#E05A2B' }}
          >
            {submitting
              ? <><Loader className="w-4 h-4 animate-spin" /> Submitting…</>
              : <><CheckCircle className="w-4 h-4" /> Submit Pricing Response</>
            }
          </button>
        </div>
      </div>

      <p className="text-center text-xs text-gray-400 dark:text-gray-500 pb-2 max-w-4xl mx-auto px-5">
        Questions?{' '}
        <a href="mailto:COE.BIDS@sysco.com" className="text-[#E05A2B] hover:underline">COE.BIDS@sysco.com</a>
      </p>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// Root router
// ─────────────────────────────────────────────────────────
export default function SupplierPortal() {
  const { bidId, threadId } = useParams()
  if (threadId) return <ThreadView bidId={bidId} threadId={threadId} />
  return <SubmissionForm bidId={bidId} />
}
