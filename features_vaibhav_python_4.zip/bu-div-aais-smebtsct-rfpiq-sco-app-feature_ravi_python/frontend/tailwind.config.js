/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        exl: {
          orange: '#E05A2B',
          'orange-dark': '#C04A1E',
          'orange-light': '#F47A52',
          navy: '#1F3864',
          'navy-dark': '#152849',
          'navy-light': '#2E518E',
        },
        sysco: {
          blue: '#003087',
          'blue-light': '#0052CC',
        },
        brand: {
          orange:        '#E05A2B',
          'orange-dark': '#C44E22',
          'orange-light':'#FFF7F5',
          navy:          '#1F3864',
          'navy-dark':   '#162847',
          'navy-light':  '#EBF3FB',
        },
        status: {
          success:      '#16A34A',
          'success-bg': '#DCFCE7',
          warning:      '#D97706',
          'warning-bg': '#FEF3C7',
          danger:       '#DC2626',
          'danger-bg':  '#FEE2E2',
          info:         '#2563EB',
          'info-bg':    '#DBEAFE',
          neutral:      '#6B7280',
          'neutral-bg': '#F9FAFB',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'card':       '0 1px 3px rgba(0,0,0,0.08)',
        'card-hover': '0 4px 12px rgba(0,0,0,0.12)',
        'modal':      '0 8px 32px rgba(0,0,0,0.16)',
        'drawer':     '0 16px 48px rgba(0,0,0,0.20)',
      },
      borderRadius: {
        'xl':  '12px',
        '2xl': '16px',
      },
    },
  },
  plugins: [],
}
