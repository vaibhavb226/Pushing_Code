"""
Logging configuration — call configure_logging() once at process startup.

Sets up structlog to use Python's stdlib logging as backend, routing log
records to three rotating files and the console:

  logs/app.log     — all INFO+ events (catch-all)
  logs/errors.log  — WARNING and ERROR only
  logs/ai.log      — events whose name starts with an AI-related prefix

All existing log.info/warning/error() call-sites work without changes.
"""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

import structlog

# Events whose name starts with any of these go to ai.log in addition to app.log
_AI_EVENT_PREFIXES = frozenset([
    "rfp_parser.",
    "analyse_response.",
    "pricing.",
    "extract_json.",
    "ai_chat.",
])

_ROTATE_BYTES = 10 * 1024 * 1024  # 10 MB per file
_BACKUP_COUNT = 10                  # keep 10 rotated copies → 100 MB max per category


class _RoutingHandler(logging.Handler):
    """
    Single handler registered on the root logger.
    Fans each LogRecord out to the appropriate file handler(s):
      - app_h   : always (INFO+)
      - errors_h: when level >= WARNING
      - ai_h    : when the structlog event name starts with an AI prefix
    """

    def __init__(
        self,
        app_h: logging.Handler,
        errors_h: logging.Handler,
        ai_h: logging.Handler,
    ) -> None:
        super().__init__(logging.DEBUG)
        self._app = app_h
        self._errors = errors_h
        self._ai = ai_h

    def emit(self, record: logging.LogRecord) -> None:
        self._app.emit(record)

        if record.levelno >= logging.WARNING:
            self._errors.emit(record)

        # structlog passes the full event_dict as record.msg when using
        # ProcessorFormatter.wrap_for_formatter — check the event name there.
        if isinstance(record.msg, dict):
            event: str = record.msg.get("event", "")
        else:
            event = str(record.msg)

        if any(event.startswith(p) for p in _AI_EVENT_PREFIXES):
            self._ai.emit(record)


def _make_json_formatter() -> structlog.stdlib.ProcessorFormatter:
    return structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.processors.JSONRenderer(),
        ],
        foreign_pre_chain=[
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
        ],
    )


def _make_console_formatter() -> structlog.stdlib.ProcessorFormatter:
    return structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.dev.ConsoleRenderer(colors=True),
        ],
        foreign_pre_chain=[
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
        ],
    )


def _rotating(path: Path, formatter: logging.Formatter) -> logging.handlers.RotatingFileHandler:
    handler = logging.handlers.RotatingFileHandler(
        path,
        maxBytes=_ROTATE_BYTES,
        backupCount=_BACKUP_COUNT,
        encoding="utf-8",
    )
    handler.setFormatter(formatter)
    return handler


def configure_logging(logs_dir: Path) -> None:
    """
    Configure structlog + stdlib logging to write to rotating log files.
    Call once at process startup before any log.* calls.
    """
    logs_dir.mkdir(parents=True, exist_ok=True)

    json_fmt = _make_json_formatter()

    routing = _RoutingHandler(
        app_h=_rotating(logs_dir / "app.log", json_fmt),
        errors_h=_rotating(logs_dir / "errors.log", json_fmt),
        ai_h=_rotating(logs_dir / "ai.log", json_fmt),
    )

    console = logging.StreamHandler()
    console.setFormatter(_make_console_formatter())

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    # Remove any handlers already attached (e.g. uvicorn defaults)
    root.handlers.clear()
    root.addHandler(routing)
    root.addHandler(console)

    # Silence noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
