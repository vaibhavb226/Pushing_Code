"""
GET /api/logs         — Query log entries with filters
GET /api/logs/files   — Metadata (size, exists) for each log file
"""
from __future__ import annotations

import json
from datetime import date as date_type
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query

from dependencies import LOGS_DIR

router = APIRouter(tags=["logs"])

_LOG_FILES: dict[str, str] = {
    "app": "app.log",
    "errors": "errors.log",
    "ai": "ai.log",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _tail_lines(path: Path, n: int) -> list[str]:
    """Read the last n lines of a file without loading it all into memory."""
    if not path.exists():
        return []
    with open(path, "rb") as f:
        f.seek(0, 2)
        buf = bytearray()
        pos = f.tell()
        while pos > 0 and buf.count(b"\n") <= n:
            chunk = min(8192, pos)
            pos -= chunk
            f.seek(pos)
            buf = bytearray(f.read(chunk)) + buf
    return buf.decode("utf-8", errors="replace").splitlines()[-n:]


def _parse_entries(raw_lines: list[str]) -> list[dict[str, Any]]:
    """Parse JSON lines, silently skipping unparseable rows."""
    entries: list[dict[str, Any]] = []
    for line in raw_lines:
        line = line.strip()
        if not line:
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return entries


def _in_date_range(
    ts: str,
    date: Optional[str],
    date_from: Optional[str],
    date_to: Optional[str],
) -> bool:
    """True if the ISO timestamp string falls within the requested date range."""
    day = ts[:10]  # "YYYY-MM-DD"
    if date and day != date:
        return False
    if date_from and day < date_from:
        return False
    if date_to and day > date_to:
        return False
    return True


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("/files")
async def list_log_files() -> dict[str, Any]:
    """Return size metadata for each log file."""
    files = []
    for log_type, filename in _LOG_FILES.items():
        path = LOGS_DIR / filename
        files.append({
            "type": log_type,
            "file": filename,
            "exists": path.exists(),
            "size_bytes": path.stat().st_size if path.exists() else 0,
        })
    return {"files": files}


@router.get("")
async def get_logs(
    type: str = Query("app", description="Log type: app | errors | ai"),
    lines: int = Query(100, ge=1, le=5000, description="Last N lines to read"),
    date: Optional[str] = Query(None, description="Filter by ISO date YYYY-MM-DD"),
    dateFrom: Optional[str] = Query(None, description="Date range start YYYY-MM-DD"),
    dateTo: Optional[str] = Query(None, description="Date range end YYYY-MM-DD"),
    level: Optional[str] = Query(None, description="Filter by level: info | warning | error"),
    search: Optional[str] = Query(None, description="Substring match in event name"),
    bidId: Optional[str] = Query(None, description="Match bid_id field in log entry"),
) -> dict[str, Any]:
    """
    Return the last N log entries from the requested log file, with optional filtering.
    Filters are applied after reading: date range → level → search → bidId.
    """
    if type not in _LOG_FILES:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown log type '{type}'. Valid values: {list(_LOG_FILES)}",
        )

    path = LOGS_DIR / _LOG_FILES[type]
    if not path.exists():
        return {
            "type": type,
            "file": _LOG_FILES[type],
            "total_scanned": 0,
            "returned": 0,
            "entries": [],
            "note": "Log file does not exist yet — no events have been written.",
        }

    raw = _tail_lines(path, lines)
    entries = _parse_entries(raw)
    total_scanned = len(entries)

    # Apply filters
    filtered: list[dict[str, Any]] = []
    for entry in entries:
        ts: str = entry.get("timestamp", "")
        if (date or dateFrom or dateTo) and not _in_date_range(ts, date, dateFrom, dateTo):
            continue
        if level:
            if entry.get("level", "").lower() != level.lower():
                continue
        if search:
            if search.lower() not in entry.get("event", "").lower():
                continue
        if bidId:
            if entry.get("bid_id") != bidId and entry.get("bidId") != bidId:
                continue
        filtered.append(entry)

    return {
        "type": type,
        "file": _LOG_FILES[type],
        "total_scanned": total_scanned,
        "returned": len(filtered),
        "entries": filtered,
    }
