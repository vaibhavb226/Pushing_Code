"""Pydantic v2 schemas for BEX AI parse response."""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class BEXLineItem(BaseModel):
    line_number: Optional[str] = None
    mpc_code: Optional[str] = None
    uom: Optional[str] = None
    volume: Optional[int] = None
    pack: Optional[str] = None
    size: Optional[str] = None
    brand: Optional[str] = None
    description: str = ""
    category: Optional[str] = None
    storage: Optional[str] = None
    buy_american: Optional[bool] = None
    child_nutrition: Optional[bool] = None
    pfs_required: Optional[bool] = None
    exact_spec: Optional[bool] = None


class BEXMetadata(BaseModel):
    bid_id: Optional[str] = None
    customer_name: Optional[str] = None
    segment: Optional[str] = None
    opco_code: Optional[str] = None
    opco_name: Optional[str] = None
    region: Optional[str] = None
    customer_due_date: Optional[str] = None
    compliance_flags: list[str] = Field(default_factory=list)
    total_items: Optional[int] = None
    parsing_confidence: Optional[int] = None


class BEXResponse(BaseModel):
    metadata: BEXMetadata = Field(default_factory=BEXMetadata)
    line_items: list[BEXLineItem] = Field(default_factory=list)
    supplier_targeting: Optional[dict] = None
    parsing_warnings: list[str] = Field(default_factory=list)
