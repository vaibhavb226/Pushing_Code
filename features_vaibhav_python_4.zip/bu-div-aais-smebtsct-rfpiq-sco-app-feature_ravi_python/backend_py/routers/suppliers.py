"""
GET  /api/suppliers         — list with filters
GET  /api/suppliers/search  — typeahead (must be before /{id})
POST /api/suppliers/auto-populate
POST /api/suppliers         — create new supplier
"""
from __future__ import annotations

import re
import uuid
from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query

from constants import CATEGORY_MAP
from dependencies import get_suppliers_repo
from repositories.suppliers_repo import SuppliersRepository
from schemas.supplier import AutoPopulateRequest, SupplierCreate, SupplierResponse

log = structlog.get_logger()
router = APIRouter(tags=["suppliers"])


# ── IMPORTANT: /search and /auto-populate BEFORE /{id} ───────────────────────


@router.get("/search", response_model=list[dict[str, Any]])
async def search_suppliers(
    q: str = Query("", min_length=0),
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> list[dict[str, Any]]:
    """Typeahead supplier search — matches name, email, or category. Returns up to 10 results.

    Query param: `?q=schwan`
    """
    if not q.strip():
        return []
    term = q.strip().lower()
    suppliers = await repo.load()
    results = [
        s for s in suppliers
        if term in s.get("name", "").lower()
        or term in s.get("contact", "").lower()
        or term in s.get("category", "").lower()
    ]
    return results[:10]


@router.post("/auto-populate", response_model=dict[str, Any])
async def auto_populate(
    body: AutoPopulateRequest,
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Auto-populate a supplier list for a bid based on item categories.

    Matches suppliers whose category covers any of the bid's item categories.
    Brokers are always included. Returns `{ suppliers, bouncedCount }`.

    Sample input:
    ```json
    { "itemCategories": ["DAIRY", "PROTEINS"], "excludeBounced": true }
    ```
    """
    all_suppliers = await repo.load()

    # Map item categories to supplier categories
    needed_categories: set[str] = set()
    for cat in body.itemCategories:
        needed_categories.update(CATEGORY_MAP.get(cat, [cat]))
    # Always include Broker
    needed_categories.add("Broker")

    matched = [
        s for s in all_suppliers
        if s.get("category") in needed_categories
        or any(sub in needed_categories for sub in s.get("subcategories", []))
    ]

    bounced_count = sum(1 for s in matched if s.get("bounce", False))

    if body.excludeBounced:
        matched = [s for s in matched if not s.get("bounce", False)]

    log.info("suppliers.auto_populate", matched=len(matched), bounced=bounced_count)
    return {"suppliers": matched, "bouncedCount": bounced_count}


@router.get("/", response_model=list[dict[str, Any]])
async def list_suppliers(
    category: str | None = None,
    segment: str | None = None,
    region: str | None = None,
    exclude_bounced: bool = Query(False, alias="excludeBounced"),
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> list[dict[str, Any]]:
    """List all suppliers with optional filters.

    Query params: `?category=Proteins&segment=K-12&region=South&excludeBounced=true`
    """
    suppliers = await repo.load()

    if category:
        suppliers = [s for s in suppliers if s.get("category") == category]
    if segment:
        suppliers = [s for s in suppliers if segment in s.get("segments", [])]
    if region:
        suppliers = [s for s in suppliers if s.get("region") == region]
    if exclude_bounced:
        suppliers = [s for s in suppliers if not s.get("bounce", False)]

    return suppliers


@router.post("/", response_model=dict[str, Any], status_code=201)
async def create_supplier(
    body: SupplierCreate,
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Create a new supplier record. Email must be unique across all suppliers.

    Sample input:
    ```json
    {
      "name": "Pacific Coast Produce",
      "contact": "bids@demo-pcproduce.test",
      "category": "Produce",
      "region": "West",
      "segments": ["K-12", "Healthcare"]
    }
    ```
    Auto-assigns ID in the format `SM-XXX`.
    """
    all_suppliers = await repo.load()

    # Check email uniqueness
    contact = body.contact.strip().lower()
    if contact and any(s.get("contact", "").lower() == contact for s in all_suppliers):
        raise HTTPException(status_code=409, detail="A supplier with this email already exists")

    # Auto-generate ID: SM-XXX
    existing_ids = [s.get("id", "") for s in all_suppliers if s.get("id", "").startswith("SM-")]
    max_num = 0
    for sid in existing_ids:
        m = re.match(r"SM-(\d+)", sid)
        if m:
            max_num = max(max_num, int(m.group(1)))
    new_id = f"SM-{max_num + 1:03d}"

    supplier = {"id": new_id, "bounce": False, **body.model_dump()}
    await repo.append(supplier)
    log.info("supplier.created", id=new_id, name=body.name)
    return supplier
