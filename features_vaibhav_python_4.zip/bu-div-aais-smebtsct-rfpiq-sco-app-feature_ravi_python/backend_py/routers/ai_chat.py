"""
POST /api/ai/chat
RFP AIQ — conversational intelligence endpoint.
Assembles full platform context from JSON data files, then calls the LLM.
"""
from __future__ import annotations

import io
from pathlib import Path
from typing import Any

import structlog
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from dependencies import (
    DATA_DIR,
    UPLOADS_DIR,
    get_bids_repo,
    get_documents_repo,
    get_email_threads_repo,
    get_line_items_repo,
    get_llm_service,
)
from repositories.bids_repo import BidsRepository
from repositories.documents_repo import DocumentsRepository
from repositories.email_threads_repo import EmailThreadsRepository
from repositories.line_items_repo import LineItemsRepository
from routers.prompts import RFPAIQ_IDENTITY
from services.llm.provider import LLMService

log = structlog.get_logger()
router = APIRouter(tags=["ai"])


class ChatRequest(BaseModel):
    messages: list[dict[str, str]]  # [{"role": "user"|"assistant", "content": str}]


class ChatResponse(BaseModel):
    role: str = "assistant"
    content: str


@router.post("/chat", response_model=ChatResponse)
async def chat(
    body: ChatRequest,
    llm: LLMService = Depends(get_llm_service),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    documents_repo: DocumentsRepository = Depends(get_documents_repo),
) -> ChatResponse:
    """RFP AIQ conversational intelligence — multi-turn chat with full platform context.

    Assembles live context from all bids, supplier activity, email threads, and documents,
    then calls the LLM with the full conversation history.

    Sample input:
    ```json
    {
      "messages": [
        { "role": "user", "content": "Which bids are at risk this week?" }
      ]
    }
    ```

    Sample response:
    ```json
    { "role": "assistant", "content": "Three bids are currently at risk: BID-601 (Darden)..." }
    ```
    """
    system_prompt = await _build_system_prompt(
        bids_repo, line_items_repo, email_threads_repo, documents_repo
    )

    result = await llm.chat_with_history(
        system=system_prompt,
        messages=body.messages,
        max_tokens=1024,
    )

    log.info("ai_chat.response", chars=len(result.content))
    return ChatResponse(role="assistant", content=result.content)


async def _build_system_prompt(
    bids_repo: BidsRepository,
    line_items_repo: LineItemsRepository,
    email_threads_repo: EmailThreadsRepository,
    documents_repo: DocumentsRepository,
) -> str:
    bids = await bids_repo.load()
    line_items = await line_items_repo.load()
    emails = await email_threads_repo.load()
    documents = await documents_repo.load()

    # ── [BIDS SUMMARY] ───────────────────────────────────────
    bids_section = "[BIDS SUMMARY]\n"
    for bid in bids:
        bid_id = bid.get("id", "")
        items_for_bid = [li for li in line_items if li.get("bidId") == bid_id]
        cats = list({li.get("category", "") for li in items_for_bid if li.get("category")})
        bids_section += (
            f"- {bid_id}: {bid.get('customer', '')} | {bid.get('segment', '')} | "
            f"Status: {bid.get('status', '')} | Items: {len(items_for_bid)} | "
            f"OpCo: {bid.get('opcoName', '')} | Region: {bid.get('region', '')} | "
            f"CustomerDue: {bid.get('customerDue', '')} | InternalDue: {bid.get('internalDue', '')} | "
            f"Compliance: {', '.join(bid.get('compliance', []))} | "
            f"Categories: {', '.join(cats[:5])} | Notes: {(bid.get('notes', '') or '')[:100]}\n"
        )

    # ── [SUPPLIER ACTIVITY] ──────────────────────────────────
    supplier_section = "\n[SUPPLIER ACTIVITY]\n"
    for bid in bids:
        bid_id = bid.get("id", "")
        solicited = bid.get("solicitedSuppliers", [])
        if not solicited:
            continue
        responded = sum(
            1 for s in solicited
            if s.get("status") in {"Responded", "Issues Found", "Follow-up Sent", "Complete"}
        )
        supplier_section += (
            f"\n{bid_id} — {bid.get('customer', '')} ({len(solicited)} solicited, "
            f"{responded} responded):\n"
        )
        for s in solicited[:10]:
            supplier_section += (
                f"  • {s.get('supplierName', '')} <{s.get('email', '')}> "
                f"| Status: {s.get('status', '')} | Last: {s.get('lastActivity', '')}\n"
            )

    # ── [DOCUMENT VAULT] ─────────────────────────────────────
    doc_section = "\n[DOCUMENT VAULT]\n"
    for doc in documents:
        doc_section += (
            f"- {doc.get('fileName', '')} | Bid: {doc.get('bidId', '')} | "
            f"Type: {doc.get('documentType', '')} | Supplier: {doc.get('supplier', '')} | "
            f"Status: {doc.get('status', '')}\n"
        )

    # ── [RECENT EMAIL ACTIVITY] ───────────────────────────────
    email_section = "\n[RECENT EMAIL ACTIVITY]\n"
    bid_emails: dict[str, list[dict[str, Any]]] = {}
    for e in emails:
        bid_id = e.get("bidId", "")
        bid_emails.setdefault(bid_id, []).append(e)

    for bid_id, bid_email_list in bid_emails.items():
        # Sort by date desc, take last 3
        sorted_emails = sorted(
            bid_email_list,
            key=lambda x: x.get("date", ""),
            reverse=True,
        )[:3]
        for e in sorted_emails:
            body_snippet = (e.get("body", "") or "")[:300].replace("\n", " ")
            email_section += (
                f"- [{bid_id}] {e.get('direction', '')} | {e.get('date', '')[:10]} | "
                f"{e.get('subject', '')} | Tags: {', '.join(e.get('tags', []))} | "
                f"Snippet: {body_snippet}\n"
            )

    # ── [DOCUMENT VAULT CONTENTS] — extract text from first 10 uploaded files ──
    contents_section = ""
    upload_files = sorted(UPLOADS_DIR.iterdir()) if UPLOADS_DIR.exists() else []
    processed = 0
    for fp in upload_files:
        if processed >= 10:
            break
        if fp.suffix.lower() in {".pdf", ".xlsx", ".xls"}:
            text = _extract_file_text(fp)
            if text.strip():
                # Find which bid this file belongs to
                bid_ref = fp.stem.split("_")[0] if "_" in fp.stem else ""
                contents_section += (
                    f"\n[FILE: {fp.name} | Bid: {bid_ref}]\n"
                    f"{text[:3000]}\n"
                )
                processed += 1

    if contents_section:
        contents_section = "\n[DOCUMENT VAULT CONTENTS]\n" + contents_section

    # ── [LAKEVIEW HISTORICAL DATA] — optional ────────────────
    lakeview_section = ""
    lakeview_path = UPLOADS_DIR / "Lakeview_USD_MultiYear_B2600042_2022-2026.xlsx"
    if lakeview_path.exists():
        lakeview_text = _extract_file_text(lakeview_path)
        if lakeview_text:
            lakeview_section = (
                "\n[LAKEVIEW HISTORICAL BID DATA]\n"
                f"{lakeview_text[:5000]}\n"
            )

    context = (
        bids_section
        + supplier_section
        + doc_section
        + email_section
        + contents_section
        + lakeview_section
    )

    return RFPAIQ_IDENTITY.replace("{context}", context)


def _extract_file_text(path: Path) -> str:
    try:
        if path.suffix.lower() == ".pdf":
            import pdfplumber
            with pdfplumber.open(str(path)) as pdf:
                return "\n".join(page.extract_text() or "" for page in pdf.pages)
        else:
            import openpyxl
            wb = openpyxl.load_workbook(str(path), data_only=True)
            lines: list[str] = []
            for ws in wb.worksheets:
                lines.append(f"=== {ws.title} ===")
                for row in ws.iter_rows(values_only=True):
                    row_str = "\t".join("" if v is None else str(v) for v in row)
                    if row_str.strip():
                        lines.append(row_str)
            return "\n".join(lines)
    except Exception:
        return ""
