"""
POST /api/parse-rfp         — Upload PDF + Excel, call BEX AI, return parsed bid + line items
POST /api/parse-rfp/create  — Save parsed data to JSON files, return created bid
"""
from __future__ import annotations

import io
import json
import time
from datetime import date
from pathlib import Path
from typing import Any

import aiofiles
import structlog
from fastapi import APIRouter, Depends, Form, UploadFile

from dependencies import UPLOADS_DIR, get_bids_repo, get_line_items_repo, get_llm_service
from repositories.bids_repo import BidsRepository
from repositories.line_items_repo import LineItemsRepository
from routers.bex_schemas import BEXResponse
from routers.prompts import BEX_SYSTEM_PROMPT
from services.llm.provider import LLMService

log = structlog.get_logger()
router = APIRouter(tags=["rfp-parser"])

_PDF_MAX_PAGES_PER_BATCH = 10  # pages extracted in parallel per thread


# ── Shared helper — also used by bids.py ────────────────────────────────────

def _s(val: Any) -> str:
    """Coerce to string, treating None and the literal string 'null' as empty."""
    if val is None:
        return ""
    s = str(val).strip()
    return "" if s.lower() == "null" else s


def build_line_item(li: dict[str, Any], bid_id: str, idx: int) -> dict[str, Any]:
    """
    Construct a lineItems.json record from a parsed AI line item.
    Mirrors buildLineItem() in backend/routes/rfpParser.js exactly.
    """
    return {
        "id": f"LI-{bid_id}-{idx + 1:03d}",
        "bidId": bid_id,
        "bidItem": _s(li.get("line_number")) or str(idx + 1).zfill(4),
        "mpcCode": _s(li.get("mpc_code")) or _s(li.get("mfg_code")),
        "brand": _s(li.get("brand")),
        "description": _s(li.get("description")),
        "pack": _s(li.get("pack")),
        "size": _s(li.get("size")),
        "unit": _s(li.get("uom")),
        "category": _s(li.get("category")),
        "qty": int(float(li.get("volume") or li.get("est_qty") or 0)),
        "storage": _s(li.get("storage")),
        "cw": "N",
        "stkType": "A",
        "buyAmerican": bool(li.get("buy_american")),
        "childNutrition": bool(li.get("child_nutrition")),
        "pfsRequired": bool(li.get("pfs_required")),
        "exactSpec": bool(li.get("exact_spec")),
        "rfpPopulated": True,
        "_source": "pdf",
        "trueVendor": None,
        "suppliedPrice": None,
        "allw": None,
        "dl": None,
        "priceCase": None,
        "devType": None,
        "openReview": False,
        "status": "No Response",
        "confidence": None,
        "supplierPricing": [],
    }


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("", response_model=dict[str, Any])
async def parse_rfp(
    pdf: UploadFile | None = None,
    excel: UploadFile | None = None,
    demo: bool = Form(False),
    llm: LLMService = Depends(get_llm_service),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    """Parse an RFP PDF and/or Excel item list using BEX AI to extract bid metadata and line items.

    Multipart form fields: `pdf` (RFP document), `excel` (item list), `demo` (bool, use demo data).
    PDF text is used for bid metadata only; Excel is used for line item extraction.
    Returns `{ metadata, line_items, supplier_targeting, parsing_warnings, tempPdfPath, tempExcelPath }`.

    Sample response (metadata):
    ```json
    { "bid_id": "B2600042", "customer_name": "Lakeview Unified School District", "segment": "K-12", "compliance_flags": ["Child Nutrition", "Buy American"], "total_items": 33 }
    ```
    """
    # ── Save uploaded files to disk FIRST (before any processing) ───────────
    # Temp files are needed by /create fallback if AI returns 0 items.
    ts = int(time.time() * 1000)
    temp_pdf_path = temp_excel_path = ""
    pdf_original_name = excel_original_name = ""
    pdf_size = excel_size = 0
    pdf_bytes = excel_bytes = b""

    if pdf:
        pdf_bytes = await pdf.read()
        pdf_original_name = pdf.filename or "rfp.pdf"
        pdf_size = len(pdf_bytes)
        fname = f"temp_{ts}_rfp.pdf"
        async with aiofiles.open(UPLOADS_DIR / fname, "wb") as fh:
            await fh.write(pdf_bytes)
        temp_pdf_path = f"uploads/{fname}"
        log.info("rfp_parser.saved_pdf", path=temp_pdf_path, size=pdf_size)

    if excel:
        excel_bytes = await excel.read()
        excel_original_name = excel.filename or "items.xlsx"
        excel_size = len(excel_bytes)
        ext = excel_original_name.rsplit(".", 1)[-1].lower() if "." in excel_original_name else "xlsx"
        fname = f"temp_{ts}_items.{ext}"
        async with aiofiles.open(UPLOADS_DIR / fname, "wb") as fh:
            await fh.write(excel_bytes)
        temp_excel_path = f"uploads/{fname}"
        log.info("rfp_parser.saved_excel", path=temp_excel_path, size=excel_size)

    file_meta = {
        "tempPdfPath":       temp_pdf_path,
        "tempExcelPath":     temp_excel_path,
        "pdfOriginalName":   pdf_original_name,
        "excelOriginalName": excel_original_name,
        "pdfSize":           pdf_size,
        "excelSize":         excel_size,
    }

    if demo:
        return {**await _demo_response(line_items_repo), **file_meta}

    pdf_text = ""
    excel_text = ""
    data_row_count = 0

    if pdf_bytes:
        pdf_text = await _extract_pdf_text(pdf_bytes)

    if excel_bytes:
        excel_text, data_row_count = _extract_excel_text(excel_bytes)

    if not pdf_text and not excel_text:
        return {**await _demo_response(line_items_repo), **file_meta}

    # Build user prompt
    user_prompt = ""
    if pdf_text:
        user_prompt += (
            "PDF CONTENT (use for bid metadata ONLY — extract customer_name, bid_id, "
            "segment, opco, region, due dates, compliance requirements from here):\n"
            f"{pdf_text[:40000]}\n\n"
        )
    if excel_text:
        user_prompt += (
            f"EXCEL ITEM LIST (extract ALL individual line items from here):\n"
            f"{excel_text[:50000]}\n\n"
            f"CRITICAL: The Excel has {data_row_count} data rows. "
            f"Your line_items array MUST contain exactly {data_row_count} separate objects "
            "— one per row. Do NOT group rows by category."
        )

    try:
        parsed: BEXResponse = await llm.chat_structured(
            system=BEX_SYSTEM_PROMPT,
            user=user_prompt,
            schema=BEXResponse,
            max_tokens=8000,
        )
    except Exception as exc:
        log.error("rfp_parser.ai_failed", error=str(exc))
        return {**await _demo_response(line_items_repo), **file_meta}

    log.info("rfp_parser.done", customer=parsed.metadata.customer_name, items=len(parsed.line_items))
    line_items_raw = [item.model_dump(mode="json") for item in parsed.line_items]
    return {
        "metadata":           parsed.metadata.model_dump(mode="json"),
        "line_items":         line_items_raw,
        "supplier_targeting": parsed.supplier_targeting or {},
        "parsing_warnings":   parsed.parsing_warnings,
        **file_meta,
    }


@router.post("/create", response_model=dict[str, Any], status_code=201)
async def create_bid_from_parse(
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    llm: LLMService = Depends(get_llm_service),
) -> dict[str, Any]:
    """Save the parsed bid and line items from the BEX AI step-2 confirmation form.

    Accepts the full body returned by `POST /api/parse-rfp` merged with user-confirmed
    step-2 fields (`customer_name`, `segment`, `opco`, `customer_due`, `compliance_flags`, etc.).
    If AI returned 0 line items, re-parses from temp files before saving.

    Sample input:
    ```json
    {
      "metadata": { "bid_id": "B2600042", "customer_name": "Lakeview USD" },
      "line_items": [...],
      "customer_name": "Lakeview Unified School District",
      "segment": "K-12",
      "customer_due": "2026-07-15",
      "tempPdfPath": "uploads/temp_1234_rfp.pdf",
      "tempExcelPath": "uploads/temp_1234_items.xlsx"
    }
    ```
    """
    meta = body.get("metadata", {})
    raw_items: list[dict[str, Any]] = body.get("line_items", [])

    # If AI returned 0 items but temp files exist, re-parse using LLM structured output
    if not raw_items:
        raw_items = await _fallback_parse_items(
            body.get("tempPdfPath", ""),
            body.get("tempExcelPath", ""),
            llm,
        )

    # Generate bid ID if not provided
    bid_id: str = (
        body.get("bid_id")
        or meta.get("bid_id")
        or f"BID-{int(time.time() * 1000) % 100000}"
    )

    today = date.today().isoformat()
    new_bid: dict[str, Any] = {
        "id": bid_id,
        "customer": body.get("customer_name") or meta.get("customer_name") or "Unknown Customer",
        "opco": body.get("opco_code") or meta.get("opco_code") or "",
        "opcoName": body.get("opco_name") or meta.get("opco_name") or "",
        "region": body.get("region") or meta.get("region") or "",
        "segment": body.get("segment") or meta.get("segment") or "",
        "status": "Active",
        "intakeDate": today,
        "customerDue": body.get("customer_due") or meta.get("customer_due_date") or "",
        "internalDue": body.get("internal_due") or "",
        "bidRelease": body.get("bid_release") or "",
        "items": len(raw_items),
        "suppliersContacted": 0,
        "responsesReceived": 0,
        "notes": body.get("notes") or "",
        "compliance": body.get("compliance_flags") or meta.get("compliance_flags") or [],
        "itemCategories": list({_s(li.get("category")) for li in raw_items if _s(li.get("category"))}),
        "solicitedSuppliers": [],
        "uploadedFiles": [],
        "_lineItemSource": "pdf",
    }

    await bids_repo.append(new_bid)

    # Save line items
    built_items = [build_line_item(li, bid_id, i) for i, li in enumerate(raw_items)]
    if built_items:
        all_items = await line_items_repo.load()
        # Remove any existing items for this bid first
        all_items = [it for it in all_items if it.get("bidId") != bid_id]
        all_items.extend(built_items)
        await line_items_repo.save(all_items)

        # Update bid item count
        await bids_repo.update_one(
            lambda b: b.get("id") == bid_id,
            lambda b: {**b, "items": len(built_items)},
        )

    log.info("rfp_parser.bid_created", bid_id=bid_id, items=len(built_items))
    return {**new_bid, "lineItems": built_items}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _extract_page_batch(content: bytes, indices: list[int]) -> list[str]:
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            return [
                pdf.pages[i].extract_text() or ""
                for i in indices
                if i < len(pdf.pages)
            ]
    except Exception:
        return [""] * len(indices)


async def _extract_pdf_text(content: bytes) -> str:
    import asyncio
    from concurrent.futures import ThreadPoolExecutor

    try:
        import pdfplumber
    except ImportError:
        # Fallback to pypdf if pdfplumber is not installed
        try:
            import pypdf
            reader = pypdf.PdfReader(io.BytesIO(content))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        except Exception:
            return ""

    try:
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            n_pages = len(pdf.pages)
    except Exception:
        return ""

    if n_pages == 0:
        return ""

    batches = [
        list(range(i, min(i + _PDF_MAX_PAGES_PER_BATCH, n_pages)))
        for i in range(0, n_pages, _PDF_MAX_PAGES_PER_BATCH)
    ]

    loop = asyncio.get_event_loop()
    with ThreadPoolExecutor(max_workers=len(batches)) as executor:
        tasks = [
            loop.run_in_executor(executor, _extract_page_batch, content, batch)
            for batch in batches
        ]
        batch_results = await asyncio.gather(*tasks)

    all_pages = [page for batch in batch_results for page in batch]
    log.info("rfp_parser.pdf_extracted", pages=n_pages, batches=len(batches))
    return "\n".join(all_pages)


def _extract_excel_text(content: bytes) -> tuple[str, int]:
    """Return (TSV-style text, data row count)."""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            return "", 0
        # First non-empty row treated as header
        header_idx = next((i for i, r in enumerate(rows) if any(c is not None for c in r)), 0)
        data_rows = rows[header_idx + 1:]
        non_empty_data = [r for r in data_rows if any(c is not None for c in r)]

        lines: list[str] = []
        header = "\t".join("" if v is None else str(v) for v in rows[header_idx])
        lines.append(header)
        for row in non_empty_data:
            lines.append("\t".join("" if v is None else str(v) for v in row))

        return "\n".join(lines), len(non_empty_data)
    except Exception:
        return "", 0


async def _fallback_parse_items(
    pdf_rel: str,
    excel_rel: str,
    llm: LLMService,
) -> list[dict[str, Any]]:
    """
    Re-parse line items from saved temp files when the main AI call returned 0 items.
    Excel wins over PDF (matching Node.js priority).
    Uses LLM structured output for guaranteed JSON.
    """
    def _resolve(rel: str) -> Path:
        return UPLOADS_DIR / rel.replace("uploads/", "", 1).replace("uploads\\", "", 1)

    text = ""

    if pdf_rel:
        path = _resolve(pdf_rel)
        if path.exists():
            text = await _extract_pdf_text(path.read_bytes())

    if excel_rel:
        path = _resolve(excel_rel)
        if path.exists():
            excel_text, _ = _extract_excel_text(path.read_bytes())
            if excel_text:
                text = excel_text  # Excel overwrites PDF

    if not text:
        return []

    try:
        parsed: BEXResponse = await llm.chat_structured(
            system=BEX_SYSTEM_PROMPT,
            user=f"Extract ALL line items from this content:\n{text[:50000]}",
            schema=BEXResponse,
            max_tokens=8000,
        )
        items = [item.model_dump(mode="json") for item in parsed.line_items]
        log.info("rfp_parser.fallback_parse", items=len(items))
        return items
    except Exception as exc:
        log.warning("rfp_parser.fallback_parse_failed", error=str(exc))
        return []


async def _demo_response(line_items_repo: LineItemsRepository) -> dict[str, Any]:
    """Return demo data when no file is uploaded or AI is unavailable."""
    all_items = await line_items_repo.load()
    demo_items = [it for it in all_items if it.get("bidId") == "B2600042"][:5]
    return {
        "metadata": {
            "bid_id": "DEMO-001",
            "customer_name": "Demo School District",
            "segment": "K-12",
            "opco_code": "016",
            "opco_name": "Sysco Boston",
            "region": "Northeast",
            "customer_due_date": None,
            "compliance_flags": ["Child Nutrition", "Buy American"],
            "total_items": len(demo_items),
            "parsing_confidence": 85,
        },
        "line_items": demo_items,
        "supplier_targeting": {},
        "parsing_warnings": ["Demo mode — upload a real RFP to parse"],
    }
