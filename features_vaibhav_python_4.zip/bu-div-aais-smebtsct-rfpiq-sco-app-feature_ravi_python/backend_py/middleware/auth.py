"""
X-API-Key authentication for internal routes.
Skipped when INTERNAL_API_KEY is empty (development default).
Public routes listed in PUBLIC_PREFIXES bypass this check.
"""
from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

# Routes that do NOT require an API key (supplier-facing public portal + health)
PUBLIC_PREFIXES: tuple[str, ...] = (
    "/api/v1/submit/",
    "/api/v1/health",
    "/api/submit/",   # legacy path compat
    "/api/health",
)


class APIKeyMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, api_key: str) -> None:
        super().__init__(app)
        self._api_key = api_key

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Skip check when key is not configured
        if not self._api_key:
            return await call_next(request)

        path = request.url.path
        if any(path.startswith(p) for p in PUBLIC_PREFIXES):
            return await call_next(request)

        key = request.headers.get("X-API-Key", "")
        if key != self._api_key:
            return JSONResponse(
                status_code=401,
                content={"error": "Missing or invalid X-API-Key header"},
            )

        return await call_next(request)
