from __future__ import annotations

from pydantic import BaseModel, EmailStr, Field


class SupplierCreate(BaseModel):
    name: str = Field(..., min_length=1)
    category: str = "Grocery"
    subcategories: list[str] = []
    region: str = "National"
    contact: str = ""
    contactName: str = ""
    phone: str = ""
    broker: bool = False
    segments: list[str] = []
    tags: list[str] = []
    notes: str = ""


class SupplierResponse(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    name: str
    category: str
    subcategories: list[str] = []
    region: str
    contact: str = ""
    contactName: str = ""
    phone: str = ""
    broker: bool = False
    segments: list[str] = []
    tags: list[str] = []
    notes: str = ""
    bounce: bool = False


class AutoPopulateRequest(BaseModel):
    itemCategories: list[str]
    excludeBounced: bool = True
