from __future__ import annotations

from pydantic import BaseModel


class DocumentResponse(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    fileName: str
    fileType: str = ""
    sizeKb: int = 0
    supplier: str = ""
    supplierId: str | None = None
    bidId: str = ""
    documentType: str = ""
    tags: list[str] = []
    uploadDate: str = ""
    uploadedBy: str = ""
    status: str = "Filed"
    filePath: str = ""
    description: str = ""
