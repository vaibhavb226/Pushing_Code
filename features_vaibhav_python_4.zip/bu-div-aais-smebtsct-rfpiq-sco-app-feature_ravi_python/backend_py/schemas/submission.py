from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class SubmissionLineItem(BaseModel):
    itemNo: str
    description: str = ""
    deliveredPrice: float | None = None
    fobPrice: float | None = None
    allowance: float | None = None
    ptvValue: float | None = None
    unitPrice: float | None = None
    noBid: bool = False
    devType: str | None = None
    notes: str = ""
    customFieldValues: dict[str, Any] = {}


class SubmissionCreate(BaseModel):
    supplierName: str
    supplierEmail: str
    contactName: str = ""
    phone: str = ""
    notes: str = ""
    lineItems: list[dict[str, Any]] = []


class MessageCreate(BaseModel):
    threadId: str
    supplierEmail: str
    body: str
    attachmentPaths: list[str] = []


class SubmissionResponse(BaseModel):
    model_config = {"extra": "allow"}

    confirmationId: str
    threadId: str
    submittedAt: str
    supplierName: str
    supplierEmail: str
    pricedCount: int = 0
    noBidCount: int = 0
    messages: list[dict[str, Any]] = []


class PortalReplyCreate(BaseModel):
    threadId: str
    message: str
    supplierEmail: str
    attachmentPaths: list[str] = []
