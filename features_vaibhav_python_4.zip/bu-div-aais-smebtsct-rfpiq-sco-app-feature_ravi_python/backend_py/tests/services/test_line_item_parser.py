"""Tests for the line item Excel parser (sync path, no AI)."""
from __future__ import annotations

from pathlib import Path

import pytest


def _write_minimal_xlsx(path: Path) -> None:
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Items"
    # Header row
    ws.append(["Item No", "Description", "Brand", "Pack", "Size", "UOM", "Est Qty", "Category", "Buy American", "CN"])
    # Data rows
    ws.append(["1", "Chicken Nuggets 4oz", "Tyson", "6", "10 oz", "CS", 200, "Protein", "Y", "Y"])
    ws.append(["2", "Apple Juice", "Motts", "12", "6 oz", "CS", 150, "Beverage", "", ""])
    wb.save(path)


def test_parse_excel_two_rows(tmp_path: Path) -> None:
    from services.line_item_parser import parse_line_items_from_excel

    xlsx = tmp_path / "items.xlsx"
    _write_minimal_xlsx(xlsx)

    items = parse_line_items_from_excel("BID-PARSE-001", str(xlsx))
    assert len(items) == 2
    assert items[0]["description"] == "Chicken Nuggets 4oz"
    assert items[0]["buyAmerican"] is True
    assert items[0]["childNutrition"] is True
    assert items[1]["brand"] == "Motts"
    assert items[1]["buyAmerican"] is False


def test_parse_excel_sets_source(tmp_path: Path) -> None:
    from services.line_item_parser import parse_line_items_from_excel

    xlsx = tmp_path / "items.xlsx"
    _write_minimal_xlsx(xlsx)
    items = parse_line_items_from_excel("BID-SRC-001", str(xlsx))
    assert all(i["_source"] == "excel" for i in items)


def test_parse_excel_sets_bid_id(tmp_path: Path) -> None:
    from services.line_item_parser import parse_line_items_from_excel

    xlsx = tmp_path / "items.xlsx"
    _write_minimal_xlsx(xlsx)
    items = parse_line_items_from_excel("BID-XY-999", str(xlsx))
    assert all(i["bidId"] == "BID-XY-999" for i in items)


def test_parse_excel_ids_are_unique(tmp_path: Path) -> None:
    from services.line_item_parser import parse_line_items_from_excel

    xlsx = tmp_path / "items.xlsx"
    _write_minimal_xlsx(xlsx)
    items = parse_line_items_from_excel("BID-UNIQ-001", str(xlsx))
    ids = [i["id"] for i in items]
    assert len(ids) == len(set(ids))


def test_parse_excel_empty_file_returns_empty(tmp_path: Path) -> None:
    import openpyxl
    from services.line_item_parser import parse_line_items_from_excel

    xlsx = tmp_path / "empty.xlsx"
    wb = openpyxl.Workbook()
    wb.active.append(["Item No", "Description"])
    wb.save(xlsx)

    items = parse_line_items_from_excel("BID-EMPTY", str(xlsx))
    assert items == []
