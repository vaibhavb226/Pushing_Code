"""Tests for the centralized extract_json() utility."""
from __future__ import annotations

import pytest

from services.llm.json_parser import extract_json


def test_plain_json_object() -> None:
    raw = '{"items": [{"id": 1}], "count": 1}'
    result = extract_json(raw)
    assert isinstance(result, dict)
    assert result["count"] == 1


def test_plain_json_array() -> None:
    raw = '[{"id": "A"}, {"id": "B"}]'
    result = extract_json(raw)
    assert isinstance(result, list)
    assert len(result) == 2


def test_markdown_fenced_json() -> None:
    raw = "Here is the result:\n```json\n{\"ok\": true}\n```\n"
    result = extract_json(raw)
    assert result == {"ok": True}


def test_markdown_fenced_no_lang() -> None:
    raw = "```\n{\"key\": \"value\"}\n```"
    result = extract_json(raw)
    assert result["key"] == "value"


def test_json_embedded_in_prose() -> None:
    raw = 'Some preamble text {"answer": 42} trailing text'
    result = extract_json(raw)
    assert result["answer"] == 42


def test_invalid_json_raises() -> None:
    with pytest.raises(ValueError, match="No valid JSON"):
        extract_json("This is just plain text with no JSON at all.")


def test_empty_string_raises() -> None:
    with pytest.raises(ValueError):
        extract_json("")


def test_nested_objects() -> None:
    raw = '{"metadata": {"bid_id": "B001", "customer": "Test"}, "line_items": []}'
    result = extract_json(raw)
    assert result["metadata"]["bid_id"] == "B001"
    assert result["line_items"] == []
