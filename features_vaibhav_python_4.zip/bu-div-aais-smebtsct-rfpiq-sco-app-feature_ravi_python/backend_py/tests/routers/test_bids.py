"""
Route-level tests for /api/bids/* endpoints.
Uses the shared `client` fixture from conftest.py.
"""
from __future__ import annotations

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_list_bids_returns_seed(client: AsyncClient) -> None:
    resp = await client.get("/api/bids/")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert any(b["id"] == "BID-TEST-001" for b in data)


@pytest.mark.asyncio
async def test_get_bid_found(client: AsyncClient) -> None:
    resp = await client.get("/api/bids/BID-TEST-001")
    assert resp.status_code == 200
    assert resp.json()["customer"] == "Test School District"


@pytest.mark.asyncio
async def test_get_bid_not_found(client: AsyncClient) -> None:
    resp = await client.get("/api/bids/BID-DOES-NOT-EXIST")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_create_bid(client: AsyncClient) -> None:
    resp = await client.post("/api/bids/", json={
        "id": "BID-NEW-001",
        "customer": "New Customer",
        "segment": "Healthcare",
        "customerDue": "2026-08-01",
    })
    assert resp.status_code == 201
    data = resp.json()
    assert data["id"] == "BID-NEW-001"
    assert data["customer"] == "New Customer"

    # Verify it's persisted
    resp2 = await client.get("/api/bids/BID-NEW-001")
    assert resp2.status_code == 200


@pytest.mark.asyncio
async def test_patch_bid(client: AsyncClient) -> None:
    resp = await client.patch("/api/bids/BID-TEST-001", json={"status": "Solicitation"})
    assert resp.status_code == 200
    assert resp.json()["status"] == "Solicitation"


@pytest.mark.asyncio
async def test_patch_bid_not_found(client: AsyncClient) -> None:
    resp = await client.patch("/api/bids/NOPE", json={"status": "Active"})
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_delete_bid_cascades(client: AsyncClient) -> None:
    resp = await client.delete("/api/bids/BID-TEST-001")
    assert resp.status_code == 200
    result = resp.json()
    assert result["success"] is True
    assert result["deleted"] == "BID-TEST-001"
    assert "lineItems" in result["removed"]

    # Bid should be gone
    resp2 = await client.get("/api/bids/BID-TEST-001")
    assert resp2.status_code == 404


@pytest.mark.asyncio
async def test_portal_templates_before_bid_id_route(client: AsyncClient) -> None:
    """Ensure /portal-templates is not mistaken for /{bid_id}."""
    resp = await client.get("/api/bids/portal-templates")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


@pytest.mark.asyncio
async def test_get_line_items(client: AsyncClient) -> None:
    resp = await client.get("/api/bids/BID-TEST-001/line-items")
    assert resp.status_code == 200
    items = resp.json()
    assert len(items) == 1
    assert items[0]["bidItem"] == "0001"


@pytest.mark.asyncio
async def test_get_bid_emails_empty(client: AsyncClient) -> None:
    resp = await client.get("/api/bids/BID-TEST-001/emails")
    assert resp.status_code == 200
    assert resp.json() == []


@pytest.mark.asyncio
async def test_health_endpoint(client: AsyncClient) -> None:
    resp = await client.get("/api/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
