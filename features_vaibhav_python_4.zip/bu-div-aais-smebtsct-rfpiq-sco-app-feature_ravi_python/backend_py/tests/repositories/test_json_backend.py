"""
Tests for JsonRepository — correctness and concurrent write safety.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from repositories.base import JsonRepository


@pytest.fixture
def repo(tmp_path: Path) -> JsonRepository:
    f = tmp_path / "test.json"
    f.write_text(json.dumps([]))
    return JsonRepository(f)


@pytest.mark.asyncio
async def test_load_empty(repo: JsonRepository) -> None:
    data = await repo.load()
    assert data == []


@pytest.mark.asyncio
async def test_append_and_load(repo: JsonRepository) -> None:
    await repo.append({"id": "A", "name": "Alpha"})
    await repo.append({"id": "B", "name": "Beta"})
    data = await repo.load()
    assert len(data) == 2
    assert data[0]["id"] == "A"


@pytest.mark.asyncio
async def test_find_one_match(repo: JsonRepository) -> None:
    await repo.append({"id": "X", "value": 42})
    found = await repo.find_one(lambda r: r.get("id") == "X")
    assert found is not None
    assert found["value"] == 42


@pytest.mark.asyncio
async def test_find_one_no_match(repo: JsonRepository) -> None:
    result = await repo.find_one(lambda r: r.get("id") == "MISSING")
    assert result is None


@pytest.mark.asyncio
async def test_update_one(repo: JsonRepository) -> None:
    await repo.append({"id": "U", "status": "old"})
    updated = await repo.update_one(
        lambda r: r.get("id") == "U",
        lambda r: {**r, "status": "new"},
    )
    assert updated is not None
    assert updated["status"] == "new"

    reloaded = await repo.find_one(lambda r: r.get("id") == "U")
    assert reloaded["status"] == "new"


@pytest.mark.asyncio
async def test_delete_where(repo: JsonRepository) -> None:
    await repo.append({"id": "D1", "keep": False})
    await repo.append({"id": "D2", "keep": True})
    count = await repo.delete_where(lambda r: not r.get("keep"))
    assert count == 1
    data = await repo.load()
    assert len(data) == 1
    assert data[0]["id"] == "D2"


@pytest.mark.asyncio
async def test_concurrent_writes_do_not_corrupt(tmp_path: Path) -> None:
    """Write 50 items concurrently — final count must be exactly 50."""
    f = tmp_path / "concurrent.json"
    f.write_text(json.dumps([]))
    repo = JsonRepository(f)

    async def add_item(i: int) -> None:
        await repo.append({"id": f"ITEM-{i}", "val": i})

    await asyncio.gather(*(add_item(i) for i in range(50)))

    data = await repo.load()
    assert len(data) == 50
    assert len({d["id"] for d in data}) == 50  # all unique
