"""
Abstract email service interface.

Two concrete implementations:
- GmailEmailService   — aiosmtplib SMTP + aioimaplib IMAP (current)
- MsGraphEmailService — MSAL + httpx → Microsoft Graph API (future)

Switch via EMAIL_PROVIDER env var: "gmail" | "msgraph"
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class EmailMessage:
    to: str
    bcc: list[str]
    subject: str
    body: str
    attachment_paths: list[str] = field(default_factory=list)


@dataclass
class InboundEmail:
    uid: str
    from_addr: str
    subject: str
    body: str
    attachment_paths: list[str]
    date: str
    raw_headers: dict[str, str]
    message_id: str = ""


class AbstractEmailService(ABC):

    @abstractmethod
    async def send_email(self, msg: EmailMessage) -> dict[str, str]:
        """Send an outbound email. Returns {"messageId": ...}. Raises on SMTP failure."""

    @abstractmethod
    async def poll_inbox(self) -> list[InboundEmail]:
        """Fetch unseen/unread messages from inbox. Does NOT mark as read — call mark_as_read()."""

    @abstractmethod
    async def verify_config(self) -> bool:
        """Return True if credentials are present and reachable; do not raise."""

    @abstractmethod
    async def mark_as_read(self, uid: str) -> None:
        """Mark a message as seen/read so it is not returned by poll_inbox() again."""
