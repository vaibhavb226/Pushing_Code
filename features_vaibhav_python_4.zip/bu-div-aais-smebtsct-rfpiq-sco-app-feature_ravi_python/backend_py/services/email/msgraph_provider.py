"""
Microsoft Graph API email provider.

Auth: MSAL client credentials flow (Azure AD app registration)
Send: POST /v1.0/users/{userId}/sendMail
Poll: GET  /v1.0/users/{userId}/mailFolders/Inbox/messages?$filter=isRead eq false
Read: PATCH /v1.0/users/{userId}/messages/{msgId}  → {"isRead": true}

Required env vars (all in config.py):
    MS_TENANT_ID, MS_CLIENT_ID, MS_CLIENT_SECRET, MS_MAILBOX_USER_ID
"""
from __future__ import annotations

import base64
import json
from pathlib import Path

import structlog

from .base import AbstractEmailService, EmailMessage, InboundEmail

log = structlog.get_logger()

_GRAPH_BASE = "https://graph.microsoft.com/v1.0"
_SCOPE = "https://graph.microsoft.com/.default"


class MsGraphEmailService(AbstractEmailService):
    def __init__(
        self,
        tenant_id: str,
        client_id: str,
        client_secret: str,
        mailbox_user_id: str,
    ) -> None:
        self._tenant_id = tenant_id
        self._client_id = client_id
        self._client_secret = client_secret
        self._user_id = mailbox_user_id
        self._token_cache: dict[str, str] = {}

    # ──────────────────────────────────────────────────────────────────────────
    # Token acquisition (MSAL client credentials — no user interaction)
    # ──────────────────────────────────────────────────────────────────────────

    async def _get_token(self) -> str:
        import msal  # type: ignore[import]

        authority = f"https://login.microsoftonline.com/{self._tenant_id}"
        app = msal.ConfidentialClientApplication(
            client_id=self._client_id,
            client_credential=self._client_secret,
            authority=authority,
        )
        result = app.acquire_token_for_client(scopes=[_SCOPE])
        if "access_token" not in result:
            raise RuntimeError(
                f"MSAL token acquisition failed: {result.get('error_description', result)}"
            )
        return str(result["access_token"])

    async def _headers(self) -> dict[str, str]:
        token = await self._get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    # ──────────────────────────────────────────────────────────────────────────
    # Outbound
    # ──────────────────────────────────────────────────────────────────────────

    async def send_email(self, msg: EmailMessage) -> dict[str, str]:
        import httpx

        url = f"{_GRAPH_BASE}/users/{self._user_id}/sendMail"

        to_recipients = [{"emailAddress": {"address": msg.to}}] if msg.to else []
        bcc_recipients = [{"emailAddress": {"address": a}} for a in msg.bcc]

        payload: dict = {
            "message": {
                "subject": msg.subject,
                "body": {"contentType": "Text", "content": msg.body},
                "toRecipients": to_recipients,
                "bccRecipients": bcc_recipients,
                "attachments": [],
            },
            "saveToSentItems": "true",
        }

        # Attach files
        for path_str in msg.attachment_paths:
            path = Path(path_str)
            if path.exists():
                encoded = base64.b64encode(path.read_bytes()).decode()
                payload["message"]["attachments"].append({
                    "@odata.type": "#microsoft.graph.fileAttachment",
                    "name": path.name,
                    "contentBytes": encoded,
                })

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, headers=await self._headers(), json=payload)
            if resp.status_code not in (200, 202):
                raise RuntimeError(f"Graph sendMail failed {resp.status_code}: {resp.text[:200]}")

        log.info("email.sent_graph", to=msg.to, subject=msg.subject[:60])
        return {"messageId": ""}  # Graph sendMail doesn't return a message ID

    # ──────────────────────────────────────────────────────────────────────────
    # Inbound polling
    # ──────────────────────────────────────────────────────────────────────────

    async def poll_inbox(self) -> list[InboundEmail]:
        import httpx

        url = (
            f"{_GRAPH_BASE}/users/{self._user_id}/mailFolders/Inbox/messages"
            "?$filter=isRead eq false"
            "&$select=id,from,subject,body,receivedDateTime,hasAttachments"
            "&$top=25"
        )

        messages: list[InboundEmail] = []
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(url, headers=await self._headers())
                if resp.status_code != 200:
                    log.warning("graph.poll_failed", status=resp.status_code)
                    return []

                data = resp.json()
                for item in data.get("value", []):
                    body_content = item.get("body", {}).get("content", "")
                    attachments = await self._download_attachments(client, item["id"])
                    messages.append(InboundEmail(
                        uid=item["id"],
                        from_addr=item.get("from", {}).get("emailAddress", {}).get("address", ""),
                        subject=item.get("subject", ""),
                        body=body_content,
                        attachment_paths=attachments,
                        date=item.get("receivedDateTime", ""),
                        raw_headers={},
                        message_id=item["id"],
                    ))
        except Exception as exc:
            log.warning("graph.poll_exception", error=str(exc))

        return messages

    async def _download_attachments(self, client: "httpx.AsyncClient", msg_id: str) -> list[str]:
        import tempfile

        url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{msg_id}/attachments"
        saved: list[str] = []
        try:
            resp = await client.get(url, headers=await self._headers())
            if resp.status_code != 200:
                return []
            tmp_dir = Path(tempfile.gettempdir()) / "rfpaiq_attachments"
            tmp_dir.mkdir(exist_ok=True)
            for att in resp.json().get("value", []):
                if att.get("@odata.type") == "#microsoft.graph.fileAttachment":
                    content = base64.b64decode(att.get("contentBytes", ""))
                    dest = tmp_dir / att.get("name", "attachment")
                    dest.write_bytes(content)
                    saved.append(str(dest))
        except Exception as exc:
            log.warning("graph.attachment_download_failed", error=str(exc))
        return saved

    async def mark_as_read(self, uid: str) -> None:
        import httpx

        url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{uid}"
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                await client.patch(
                    url,
                    headers=await self._headers(),
                    json={"isRead": True},
                )
        except Exception as exc:
            log.warning("graph.mark_read_failed", uid=uid[:20], error=str(exc))

    # ──────────────────────────────────────────────────────────────────────────
    # Config verification
    # ──────────────────────────────────────────────────────────────────────────

    async def verify_config(self) -> bool:
        if not all([self._tenant_id, self._client_id, self._client_secret, self._user_id]):
            return False
        try:
            await self._get_token()
            return True
        except Exception as exc:
            log.warning("msgraph.verify_failed", error=str(exc))
            return False
