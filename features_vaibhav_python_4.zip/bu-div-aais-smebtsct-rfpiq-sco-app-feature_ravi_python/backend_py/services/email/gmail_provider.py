"""
Gmail email provider.

Outbound: aiosmtplib SMTP (port 587 STARTTLS)
Inbound:  aioimaplib IMAP4_SSL (port 993)
"""
from __future__ import annotations

import email
import email.policy
import mimetypes
import os
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import structlog

from .base import AbstractEmailService, EmailMessage, InboundEmail

log = structlog.get_logger()


class GmailEmailService(AbstractEmailService):
    def __init__(
        self,
        from_addr: str,
        app_password: str,
        smtp_host: str = "smtp.gmail.com",
        smtp_port: int = 587,
        imap_host: str = "imap.gmail.com",
        imap_port: int = 993,
    ) -> None:
        self._from = from_addr
        self._password = app_password.replace(" ", "")  # strip Google App Password spaces
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._imap_host = imap_host
        self._imap_port = imap_port

    # ──────────────────────────────────────────────────────────────────────────
    # Outbound
    # ──────────────────────────────────────────────────────────────────────────

    async def send_email(self, msg: EmailMessage) -> dict[str, str]:
        import aiosmtplib

        mime = self._build_mime(msg)
        try:
            await aiosmtplib.send(
                mime,
                hostname=self._smtp_host,
                port=self._smtp_port,
                username=self._from,
                password=self._password,
                start_tls=True,
            )
        except aiosmtplib.SMTPAuthenticationError as exc:
            raise RuntimeError(
                "Gmail SMTP authentication failed — check EMAIL_APP_PASSWORD. "
                "Use a Google App Password (not your regular Gmail password)."
            ) from exc
        except aiosmtplib.SMTPException as exc:
            raise RuntimeError(f"SMTP error: {exc}") from exc

        log.info("email.sent", to=msg.to, subject=msg.subject[:60])
        return {"messageId": mime["Message-ID"] or ""}

    def _build_mime(self, msg: EmailMessage) -> MIMEMultipart:
        mime = MIMEMultipart("mixed")
        mime["From"] = self._from
        # Gmail requires a To: header even for BCC-only sends — use sender address
        mime["To"] = msg.to or self._from
        if msg.bcc:
            mime["Bcc"] = ", ".join(msg.bcc)
        mime["Subject"] = msg.subject

        mime.attach(MIMEText(msg.body, "plain", "utf-8"))

        for path_str in msg.attachment_paths:
            path = Path(path_str)
            if path.exists():
                ctype, _ = mimetypes.guess_type(str(path))
                maintype, subtype = (ctype or "application/octet-stream").split("/", 1)
                with open(path, "rb") as f:
                    att = MIMEApplication(f.read(), Name=path.name)
                att["Content-Disposition"] = f'attachment; filename="{path.name}"'
                mime.attach(att)

        return mime

    # ──────────────────────────────────────────────────────────────────────────
    # Inbound polling
    # ──────────────────────────────────────────────────────────────────────────

    async def poll_inbox(self) -> list[InboundEmail]:
        try:
            import aioimaplib
        except ImportError:
            log.warning("imap.aioimaplib_not_installed")
            return []

        if not self._password:
            return []

        messages: list[InboundEmail] = []
        client = None
        try:
            client = aioimaplib.IMAP4_SSL(host=self._imap_host, port=self._imap_port)
            await client.wait_hello_from_server()
            await client.login(self._from, self._password)
            await client.select("INBOX")

            _, data = await client.search("UNSEEN")
            if not data or not data[0]:
                return []

            uid_list = data[0].split()
            for uid in uid_list:
                _, msg_data = await client.fetch(uid.decode(), "(RFC822)")
                if not msg_data:
                    continue
                raw = msg_data[1] if len(msg_data) > 1 else msg_data[0]
                if not isinstance(raw, bytes):
                    continue

                parsed = email.message_from_bytes(raw, policy=email.policy.default)
                body = _extract_body(parsed)
                attachments = _save_attachments(parsed)

                messages.append(InboundEmail(
                    uid=uid.decode(),
                    from_addr=str(parsed.get("From", "")),
                    subject=str(parsed.get("Subject", "")),
                    body=body,
                    attachment_paths=attachments,
                    date=str(parsed.get("Date", "")),
                    raw_headers={k: str(v) for k, v in parsed.items()},
                    message_id=str(parsed.get("Message-ID", "")),
                ))

        except Exception as exc:
            log.warning("imap.poll_failed", error=str(exc))
        finally:
            if client:
                try:
                    await client.quit()
                except Exception:
                    pass

        return messages

    async def mark_as_read(self, uid: str) -> None:
        try:
            import aioimaplib
            client = aioimaplib.IMAP4_SSL(host=self._imap_host, port=self._imap_port)
            await client.wait_hello_from_server()
            await client.login(self._from, self._password)
            await client.select("INBOX")
            await client.store(uid, "+FLAGS", "\\Seen")
            await client.quit()
        except Exception as exc:
            log.warning("imap.mark_read_failed", uid=uid, error=str(exc))

    # ──────────────────────────────────────────────────────────────────────────
    # Config verification
    # ──────────────────────────────────────────────────────────────────────────

    async def verify_config(self) -> bool:
        if not self._from or not self._password:
            return False
        try:
            import aiosmtplib
            smtp = aiosmtplib.SMTP(hostname=self._smtp_host, port=self._smtp_port)
            await smtp.connect()  # aiosmtplib 3.x auto-negotiates STARTTLS for port 587
            await smtp.login(self._from, self._password)
            await smtp.quit()
            return True
        except Exception as exc:
            log.warning("smtp.verify_failed", error=str(exc))
            return False


# ── Helpers ────────────────────────────────────────────────────────────────────

def _extract_body(msg: email.message.Message) -> str:
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            if ctype == "text/plain" and not part.get_filename():
                payload = part.get_payload(decode=True)
                if isinstance(payload, bytes):
                    body = payload.decode("utf-8", errors="replace")
                    break
    else:
        payload = msg.get_payload(decode=True)
        if isinstance(payload, bytes):
            body = payload.decode("utf-8", errors="replace")
    return body


def _save_attachments(msg: email.message.Message) -> list[str]:
    """Save MIME attachments to a temp directory and return file paths."""
    from pathlib import Path
    import tempfile

    saved: list[str] = []
    if not msg.is_multipart():
        return saved

    tmp_dir = Path(tempfile.gettempdir()) / "rfpaiq_attachments"
    tmp_dir.mkdir(exist_ok=True)

    for part in msg.walk():
        filename = part.get_filename()
        if not filename:
            continue
        payload = part.get_payload(decode=True)
        if not isinstance(payload, bytes):
            continue
        dest = tmp_dir / filename
        dest.write_bytes(payload)
        saved.append(str(dest))

    return saved
