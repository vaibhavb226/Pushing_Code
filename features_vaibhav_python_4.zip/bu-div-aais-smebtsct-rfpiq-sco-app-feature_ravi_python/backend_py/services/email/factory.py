"""
Build the email service from settings.

EMAIL_PROVIDER=gmail   → GmailEmailService (default)
EMAIL_PROVIDER=msgraph → MsGraphEmailService
"""
from __future__ import annotations

from config import Settings

from .base import AbstractEmailService


def build_email_service(settings: Settings) -> AbstractEmailService:
    provider = (settings.email_provider or "gmail").lower()

    if provider == "msgraph":
        from .msgraph_provider import MsGraphEmailService
        return MsGraphEmailService(
            tenant_id=settings.ms_tenant_id,
            client_id=settings.ms_client_id,
            client_secret=settings.ms_client_secret.get_secret_value(),
            mailbox_user_id=settings.ms_mailbox_user_id,
        )

    # Default: gmail
    from .gmail_provider import GmailEmailService
    return GmailEmailService(
        from_addr=settings.email_from,
        app_password=settings.email_app_password.get_secret_value(),
        smtp_host=settings.email_host,
        smtp_port=settings.email_port,
        imap_host=settings.email_imap_host,
        imap_port=settings.email_imap_port,
    )
