"""
Auto-reminder scheduler job — mirrors runAutoReminders() in backend/server.js.

Called by APScheduler every hour.
Targets: solicited suppliers with status "Awaiting", no portal submission,
no inbound email response. Min 3-day gap between auto-reminder runs per bid.
"""
from __future__ import annotations

from datetime import date, datetime, timezone, timedelta
from typing import Any

import structlog

log = structlog.get_logger()

_MIN_GAP_DAYS = 3  # Minimum days between auto-reminders per bid


async def run_auto_reminders() -> None:
    from dependencies import get_bids_repo, get_email_threads_repo, get_submissions_repo
    from services.email.base import EmailMessage
    from dependencies import get_email_service
    from config import get_settings

    settings = get_settings()
    bids_repo = get_bids_repo()
    threads_repo = get_email_threads_repo()
    email_svc = get_email_service()

    bids = await bids_repo.load()
    all_threads = await threads_repo.load()

    for bid in bids:
        auto_reminder = bid.get("autoReminder", {})
        if not auto_reminder.get("enabled"):
            continue

        bid_id = bid.get("id", "")
        days_after = int(auto_reminder.get("daysAfterSolicitation", 3))
        last_sent = auto_reminder.get("lastReminderSent")

        # Enforce minimum gap
        if last_sent:
            try:
                last_dt = datetime.fromisoformat(last_sent).date()
                if (date.today() - last_dt).days < _MIN_GAP_DAYS:
                    continue
            except ValueError:
                pass

        solicitation_date = bid.get("lastSolicitationDate", "")
        if solicitation_date:
            try:
                sol_dt = date.fromisoformat(solicitation_date)
                if (date.today() - sol_dt).days < days_after:
                    continue
            except ValueError:
                pass

        # Get portal submissions for this bid
        from dependencies import get_submissions_repo
        submissions_repo = get_submissions_repo()
        portal_subs = await submissions_repo.get_for_bid(bid_id)
        portal_emails = {s.get("supplierEmail", "").lower() for s in portal_subs}

        # Get inbound email senders
        bid_threads = [t for t in all_threads if t.get("bidId") == bid_id]
        inbound_emails = {
            t.get("supplierEmail", "").lower()
            for t in bid_threads
            if t.get("direction") == "inbound" and not t.get("isBounce")
        }

        targets = [
            s for s in bid.get("solicitedSuppliers", [])
            if s.get("status") == "Awaiting"
            and s.get("email", "").lower() not in portal_emails
            and s.get("email", "").lower() not in inbound_emails
        ]

        if not targets:
            continue

        portal_url = f"{settings.portal_base_url}/submit/{bid_id}"
        customer = bid.get("customer", "")
        due_date = bid.get("customerDue", "")

        sent_count = 0
        for supplier in targets:
            email_addr = supplier.get("email", "")
            supplier_name = supplier.get("supplierName", "")

            body = (
                f"Dear {supplier_name},\n\n"
                f"This is a friendly reminder that we are awaiting your pricing response "
                f"for the bid: {customer} (Bid ID: {bid_id}).\n\n"
                f"Due date: {due_date}\n\n"
                f"Please submit your pricing via the supplier portal:\n"
                f"→ {portal_url}\n\n"
                "If you have any questions, please reply to this email or use the "
                "messaging feature in the portal.\n\n"
                "Thank you,\nSysco Bid COE"
            )

            try:
                await email_svc.send_email(EmailMessage(
                    to=email_addr,
                    bcc=[],
                    subject=f"Reminder: Pricing Request for {customer} — Response Due {due_date}",
                    body=body,
                ))

                # Log to emailThreads.json
                import uuid
                await threads_repo.append({
                    "id": f"E-AUTOREMIND-{uuid.uuid4().hex[:8].upper()}",
                    "bidId": bid_id,
                    "direction": "outbound",
                    "supplierId": supplier.get("supplierId"),
                    "supplierName": supplier_name,
                    "supplierEmail": email_addr,
                    "from": settings.email_from,
                    "to": email_addr,
                    "bcc": [],
                    "subject": f"Reminder: Pricing Request for {customer} — Response Due {due_date}",
                    "body": body,
                    "date": datetime.now(timezone.utc).isoformat(),
                    "tags": ["reminder", "auto", "portal-url"],
                    "read": True,
                    "isBounce": False,
                })

                # Update supplier status to Follow-up Sent
                def make_updater(email: str) -> Any:
                    def updater(bid: dict[str, Any]) -> dict[str, Any]:
                        for s in bid.get("solicitedSuppliers", []):
                            if s.get("email", "").lower() == email.lower():
                                s["status"] = "Follow-up Sent"
                                s["lastActivity"] = date.today().isoformat()
                        return bid
                    return updater

                await bids_repo.update_one(
                    lambda b: b.get("id") == bid_id,
                    make_updater(email_addr),
                )
                sent_count += 1

            except Exception as exc:
                log.warning("auto_reminder.send_failed", bid_id=bid_id, supplier=supplier_name, error=str(exc))

        if sent_count > 0:
            # Update lastReminderSent on bid
            now_iso = datetime.now(timezone.utc).isoformat()

            def update_reminder(bid: dict[str, Any]) -> dict[str, Any]:
                ar = bid.get("autoReminder", {})
                ar["lastReminderSent"] = now_iso
                return {**bid, "autoReminder": ar}

            await bids_repo.update_one(lambda b: b.get("id") == bid_id, update_reminder)
            log.info("auto_reminder.sent", bid_id=bid_id, count=sent_count)
