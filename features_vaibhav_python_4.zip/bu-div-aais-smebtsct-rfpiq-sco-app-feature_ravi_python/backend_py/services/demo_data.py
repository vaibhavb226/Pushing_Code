"""
Demo data injection — mirrors simulateBounce.js behavior.

ensure_bounce_demo() runs at startup if B2600042 doesn't already have the
General Mills bounce entry. Safe to re-run (idempotent).
"""
from __future__ import annotations

from datetime import date
from typing import Any

import structlog

log = structlog.get_logger()

DEMO_BID_ID = "B2600042"
DEMO_BOUNCE_SUPPLIER = {
    "supplierId": "SM-GM-DEMO",
    "supplierName": "General Mills Foodservice",
    "email": "bids@demo-generalmills.test",
    "status": "Issues Found",
    "solicitedDate": date.today().isoformat(),
    "lastActivity": date.today().isoformat(),
    "awardNotificationSent": False,
    "awardNotificationSentAt": None,
    "bounce": True,
}

DEMO_OUTBOUND_EMAIL = {
    "id": "EMAIL-GM-OUT-001",
    "bidId": DEMO_BID_ID,
    "direction": "outbound",
    "supplierId": "SM-GM-DEMO",
    "supplierName": "General Mills Foodservice",
    "supplierEmail": "bids@demo-generalmills.test",
    "from": "sysco.bid.poc@gmail.com",
    "to": "sysco.bid.poc@gmail.com",
    "bcc": ["bids@demo-generalmills.test"],
    "subject": f"Pricing Request: Lakeview Unified School District — {DEMO_BID_ID} | Due Jul 15",
    "body": (
        "Dear General Mills Foodservice,\n\n"
        "Please find attached the RFP for Lakeview Unified School District.\n\n"
        "Submit pricing via: http://localhost:5173/submit/B2600042\n\n"
        "Sysco Bid COE"
    ),
    "date": f"{date.today().isoformat()}T09:00:00Z",
    "attachments": [],
    "tags": ["Solicitation"],
    "read": True,
    "isBounce": False,
}

DEMO_BOUNCE_EMAIL = {
    "id": "EMAIL-GM-BOUNCE-001",
    "bidId": DEMO_BID_ID,
    "direction": "inbound",
    "supplierId": "SM-GM-DEMO",
    "supplierName": "Mail Delivery Subsystem",
    "supplierEmail": "mailer-daemon@demo-generalmills.test",
    "from": "Mail Delivery Subsystem <mailer-daemon@demo-generalmills.test>",
    "to": "sysco.bid.poc@gmail.com",
    "bcc": [],
    "subject": "Delivery Status Notification (Failure)",
    "body": (
        "Your message to bids@demo-generalmills.test could not be delivered.\n\n"
        "550 5.1.1 User does not exist\n\n"
        "Failed address: <bids@demo-generalmills.test>"
    ),
    "date": f"{date.today().isoformat()}T09:05:00Z",
    "attachments": [],
    "tags": ["bounce"],
    "read": False,
    "isBounce": True,
    "bounceDetails": {
        "errorCode": "550 5.1.1",
        "reason": "User does not exist",
        "failedAddress": "bids@demo-generalmills.test",
    },
}


async def ensure_bounce_demo() -> None:
    """Inject demo bounce data for B2600042 if not already present."""
    from dependencies import get_bids_repo, get_email_threads_repo

    bids_repo = get_bids_repo()
    threads_repo = get_email_threads_repo()

    bid = await bids_repo.find_one(lambda b: b.get("id") == DEMO_BID_ID)
    if not bid:
        return

    # Check if already injected
    existing_solicited = bid.get("solicitedSuppliers", [])
    already_has_gm = any(s.get("supplierId") == "SM-GM-DEMO" for s in existing_solicited)

    if not already_has_gm:
        def add_gm(b: dict[str, Any]) -> dict[str, Any]:
            solicited = b.get("solicitedSuppliers", [])
            solicited.append(DEMO_BOUNCE_SUPPLIER)
            return {**b, "solicitedSuppliers": solicited}
        await bids_repo.update_one(lambda b: b.get("id") == DEMO_BID_ID, add_gm)

    threads = await threads_repo.load()
    existing_ids = {t.get("id") for t in threads}

    new_threads = [
        t for t in [DEMO_OUTBOUND_EMAIL, DEMO_BOUNCE_EMAIL]
        if t["id"] not in existing_ids
    ]
    for t in new_threads:
        await threads_repo.append(t)

    if not already_has_gm or new_threads:
        log.info("demo_data.bounce_injected", bid_id=DEMO_BID_ID)
