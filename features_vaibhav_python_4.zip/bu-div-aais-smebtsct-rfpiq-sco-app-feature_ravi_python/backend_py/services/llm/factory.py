"""
LLM provider factory.

Reads LLM_PROVIDER from settings and returns the correct LLMService.
Supported values:

  anthropic  — Calls Anthropic SDK directly via ChatAnthropic._async_client
               Requires: ANTHROPIC_API_KEY

  openai     — ChatOpenAI (LangChain)
               Requires: OPENAI_API_KEY

  vertexai   — Calls vertexai SDK directly (GenerativeModel.generate_content_async)
               Uses IAM-based authentication — no API key needed:
                 1. GOOGLE_APPLICATION_CREDENTIALS (path to service account JSON)
                 2. gcloud Application Default Credentials (gcloud auth login)
                 3. Workload Identity (GKE, Cloud Run, etc.)
               Requires: GCP_PROJECT, GCP_LOCATION
"""
from __future__ import annotations

from langchain_core.language_models import BaseChatModel

from config import Settings
from services.llm.provider import LLMService


def build_llm_service(settings: Settings) -> LLMService:
    provider = settings.llm_provider.lower()

    if provider == "anthropic":
        from langchain_anthropic import ChatAnthropic

        model: BaseChatModel = ChatAnthropic(  # type: ignore[call-arg]
            model=settings.anthropic_model,
            api_key=settings.anthropic_api_key.get_secret_value(),
        )

    elif provider == "openai":
        from langchain_openai import ChatOpenAI

        model = ChatOpenAI(
            model=settings.openai_model,
            api_key=settings.openai_api_key.get_secret_value(),  # type: ignore[arg-type]
        )

    elif provider == "vertexai":
        # Call vertexai SDK directly — langchain_google_vertexai.ChatVertexAI is
        # deprecated since 3.2.0 (removal at 4.0.0). provider.py's _vertex_direct()
        # uses GenerativeModel.generate_content_async() instead.
        return LLMService(
            model=None,
            vertex_config={
                "model": settings.vertex_model,
                "project": settings.gcp_project,
                "location": settings.gcp_location,
            },
        )

    else:
        raise ValueError(
            f"Unknown LLM_PROVIDER: {provider!r}. Choose: anthropic, openai, vertexai"
        )

    return LLMService(model)
