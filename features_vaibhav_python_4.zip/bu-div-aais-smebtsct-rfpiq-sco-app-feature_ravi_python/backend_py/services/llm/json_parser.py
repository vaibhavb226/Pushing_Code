"""
Central JSON extraction utility.

Replaces the 5 duplicated extractJSON() helper functions spread across
rfpParser.js, pricing.js, analyseResponse.js, bids.js, and lineItemParser.js.

Logic:
1. Look for a markdown code fence block anywhere in the text (```json ... ```)
2. Strip leading/trailing fences if step 1 missed them
3. Try direct json.loads()
4. Extract first {...} object via regex, try parse
5. Extract first [...] array via regex, try parse
6. Raise ValueError with the first 500 chars of the raw response for debugging
"""
from __future__ import annotations

import json
import re

import structlog

log = structlog.get_logger()


def extract_json(raw_text: str) -> dict | list:
    if not raw_text or not isinstance(raw_text, str):
        raise ValueError("Empty AI response")

    text = raw_text.strip()

    # Step 1: Find a code fence block anywhere in the text.
    # Gemini often prefixes with "Here is the JSON:" before the fence,
    # which breaks the start-anchored ^``` approach.
    fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
    if fence_match:
        candidate = fence_match.group(1).strip()
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass

    # Step 2: Strip leading/trailing fences (fallback for unclosed fences)
    text = re.sub(r"^```json\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^```\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text, flags=re.IGNORECASE)
    text = text.strip()

    # Step 3: Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Step 4: Extract first {...} object
    obj_match = re.search(r"\{[\s\S]*\}", text)
    if obj_match:
        try:
            return json.loads(obj_match.group(0))
        except json.JSONDecodeError:
            pass

    # Step 5: Extract first [...] array
    arr_match = re.search(r"\[[\s\S]*\]", text)
    if arr_match:
        try:
            return json.loads(arr_match.group(0))
        except json.JSONDecodeError:
            pass

    preview = text[:500].replace("\n", " ")
    log.error("extract_json.failed", preview=preview)
    raise ValueError(
        f"AI response could not be parsed as JSON. First 500 chars: {preview!r}"
    )
