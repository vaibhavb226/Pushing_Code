"""
IMAP / Graph inbox poller — mirrors backend/services/emailPoller.js.

Polls every POLL_INTERVAL seconds (default 15).
3-tier bid matching strategy (same as JS):
  1. Bid ID pattern in subject (B2600042, BID-106, etc.)
  2. Cleaned subject matches stored solicitation subject (strips Re:/Fwd:)
  3. All significant words (4+ chars) from customer name appear in subject

On match  → saves to emailThreads.json, updates supplier status to Responded.
On no match → saves to unmatchedEmails.json.
"""
from __future__ import annotations

import asyncio
import re
import uuid
from datetime import datetime, timezone
from typing import Any

import structlog

from services.email.base import AbstractEmailService, InboundEmail

log = structlog.get_logger()

POLL_INTERVAL = 1500  # seconds
_POLL_TIMEOUT = 6000  # seconds — hard ceiling per poll cycle to prevent indefinite hangs

_BID_PATTERN = re.compile(r"\b([Bb]\d{7}|[Bb][Ii][Dd]-\d+)\b")
_RE_FWD = re.compile(r"^(re|fwd|fw|ant|aw)\s*:\s*", re.IGNORECASE)


async def start_email_poller(email_service: AbstractEmailService) -> None:
    """Long-running loop — runs as an asyncio.Task in main.py lifespan."""
    while True:
        try:
            await asyncio.wait_for(run_poll(email_service), timeout=_POLL_TIMEOUT)
        except asyncio.TimeoutError:
            log.warning("poller.timeout", timeout_s=_POLL_TIMEOUT)
        except asyncio.CancelledError:
            raise  # propagate — clean shutdown
        except Exception as exc:
            log.warning("poller.iteration_failed", error=str(exc))
        await asyncio.sleep(POLL_INTERVAL)


async def run_poll(email_service: AbstractEmailService) -> dict[str, Any]:
    """Single poll cycle — also exposed to GET /api/email/poll-now."""
    messages = await email_service.poll_inbox()
    matched = 0
    unmatched = 0

    if not messages:
        return {"matched": 0, "unmatched": 0, "total": 0}

    from dependencies import (
        get_bids_repo,
        get_email_threads_repo,
        get_unmatched_repo,
    )

    bids_repo = get_bids_repo()
    threads_repo = get_email_threads_repo()
    unmatched_repo = get_unmatched_repo()

    bids = await bids_repo.load()

    for msg in messages:
        bid = _match_bid(msg, bids)
        if bid:
            await _handle_matched(msg, bid, threads_repo, bids_repo)
            matched += 1
        else:
            await _handle_unmatched(msg, unmatched_repo)
            unmatched += 1

        await email_service.mark_as_read(msg.uid)

    log.info("poller.cycle_done", matched=matched, unmatched=unmatched)
    return {"matched": matched, "unmatched": unmatched, "total": len(messages)}


# ── Matching ────────────────────────────────────────────────────────────────────

def _match_bid(msg: InboundEmail, bids: list[dict[str, Any]]) -> dict[str, Any] | None:
    subject = msg.subject or ""
    subject_lower = subject.lower()

    # Tier 1: Bid ID pattern in subject
    bid_match = _BID_PATTERN.search(subject)
    if bid_match:
        bid_id_raw = bid_match.group(1).upper()
        for bid in bids:
            if bid.get("id", "").upper() == bid_id_raw:
                return bid

    # Tier 2: Cleaned subject matches stored solicitation subject
    cleaned = _RE_FWD.sub("", subject).strip().lower()
    for bid in bids:
        for thread in _get_solicitation_subjects(bid):
            if cleaned == thread.lower():
                return bid

    # Tier 3: All significant words (4+ chars) from customer name appear in subject
    for bid in bids:
        customer = bid.get("customer", "")
        words = [w for w in re.findall(r"\w+", customer) if len(w) >= 4]
        if words and all(w.lower() in subject_lower for w in words):
            return bid

    return None


def _get_solicitation_subjects(bid: dict[str, Any]) -> list[str]:
    """Return distinct solicitation email subjects stored for this bid."""
    subjects: list[str] = []
    for s in bid.get("solicitedSuppliers", []):
        subj = s.get("solicitationSubject", "")
        if subj and subj not in subjects:
            subjects.append(subj)
    return subjects


# ── Handlers ────────────────────────────────────────────────────────────────────

async def _handle_matched(
    msg: InboundEmail,
    bid: dict[str, Any],
    threads_repo: Any,
    bids_repo: Any,
) -> None:
    bid_id = bid.get("id", "")
    is_bounce = _detect_bounce(msg)

    email_record: dict[str, Any] = {
        "id": f"E-INBOUND-{uuid.uuid4().hex[:10].upper()}",
        "bidId": bid_id,
        "direction": "inbound",
        "supplierId": None,
        "supplierName": "",
        "supplierEmail": msg.from_addr,
        "from": msg.from_addr,
        "to": "",
        "bcc": [],
        "subject": msg.subject,
        "body": msg.body[:5000],
        "date": msg.date or datetime.now(timezone.utc).isoformat(),
        "attachments": [{"name": p.split("/")[-1], "path": p} for p in msg.attachment_paths],
        "tags": ["inbound"],
        "read": False,
        "analysisResult": None,
        "isBounce": is_bounce,
        "portalSubmission": False,
    }

    if is_bounce:
        email_record["bounceDetails"] = _parse_bounce(msg)
        email_record["tags"].append("bounce")

    # Try to link to a solicited supplier by email address
    from_clean = _extract_email_addr(msg.from_addr)
    for s in bid.get("solicitedSuppliers", []):
        if s.get("email", "").lower() == from_clean.lower():
            email_record["supplierId"] = s.get("supplierId")
            email_record["supplierName"] = s.get("supplierName", "")
            email_record["supplierEmail"] = s.get("email", "")
            break

    await threads_repo.append(email_record)

    # Update supplier status
    if not is_bounce and email_record["supplierId"]:
        await _update_supplier_status(bid_id, from_clean, "Responded", bids_repo)
    elif is_bounce:
        await _update_supplier_status(bid_id, from_clean, "Issues Found", bids_repo)


async def _handle_unmatched(msg: InboundEmail, repo: Any) -> None:
    all_unmatched = await repo.load()
    all_unmatched.append({
        "id": f"UNMATCHED-{uuid.uuid4().hex[:8].upper()}",
        "from": msg.from_addr,
        "subject": msg.subject,
        "body": msg.body[:2000],
        "date": msg.date or datetime.now(timezone.utc).isoformat(),
        "rawHeaders": msg.raw_headers,
    })
    await repo.save(all_unmatched)
    log.info("poller.unmatched", from_=msg.from_addr, subject=msg.subject[:60])


async def _update_supplier_status(
    bid_id: str, email: str, status: str, bids_repo: Any
) -> None:
    MANUAL_OVERRIDE_STATUSES = {"Awarded", "Under Consideration"}

    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        for s in bid.get("solicitedSuppliers", []):
            if s.get("email", "").lower() == email.lower():
                if s.get("status") not in MANUAL_OVERRIDE_STATUSES:
                    s["status"] = status
                    s["lastActivity"] = datetime.now(timezone.utc).date().isoformat()
        return bid

    await bids_repo.update_one(lambda b: b.get("id") == bid_id, updater)


# ── Bounce detection ────────────────────────────────────────────────────────────

_BOUNCE_SUBJECTS = re.compile(
    r"(delivery\s*(status\s*notification|failure)|undeliverable|mail\s*delivery\s*failed"
    r"|returned\s*mail|bounce|failure\s*notice)",
    re.IGNORECASE,
)

_BOUNCE_FROM = re.compile(r"(mailer-daemon|postmaster|mail\s*delivery)", re.IGNORECASE)


def _detect_bounce(msg: InboundEmail) -> bool:
    return bool(
        _BOUNCE_SUBJECTS.search(msg.subject or "")
        or _BOUNCE_FROM.search(msg.from_addr or "")
    )


def _parse_bounce(msg: InboundEmail) -> dict[str, str]:
    code_match = re.search(r"\b(5\d{2})\s+[\d.]+\b", msg.body)
    reason_match = re.search(r"(user\s*does\s*not\s*exist|mailbox\s*not\s*found|no\s*such\s*user)", msg.body, re.IGNORECASE)

    # Extract the failed address from the body
    addr_match = re.search(r"<([^>]+@[^>]+)>", msg.body)

    return {
        "errorCode": code_match.group(0) if code_match else "550",
        "reason": reason_match.group(0) if reason_match else "Unknown delivery failure",
        "failedAddress": addr_match.group(1) if addr_match else _extract_email_addr(msg.from_addr),
    }


def _extract_email_addr(raw: str) -> str:
    """Extract plain email from 'Display Name <email@domain.com>' format."""
    match = re.search(r"<([^>]+)>", raw)
    return match.group(1).strip() if match else raw.strip()
