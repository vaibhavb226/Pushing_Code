from __future__ import annotations

from pathlib import Path

from repositories.base import JsonRepository


class PortalTemplatesRepository(JsonRepository):
    """Repository for portalTemplates.json — array of portal template objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)
