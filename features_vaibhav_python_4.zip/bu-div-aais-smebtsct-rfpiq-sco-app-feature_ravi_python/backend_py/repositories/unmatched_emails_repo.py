from __future__ import annotations

from pathlib import Path

from repositories.base import JsonRepository


class UnmatchedEmailsRepository(JsonRepository):
    """Repository for unmatchedEmails.json — emails the IMAP poller could not match."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)
