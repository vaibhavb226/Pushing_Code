from __future__ import annotations

from pathlib import Path

from repositories.base import JsonRepository


class DocumentsRepository(JsonRepository):
    """Repository for documents.json — array of document metadata objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)
