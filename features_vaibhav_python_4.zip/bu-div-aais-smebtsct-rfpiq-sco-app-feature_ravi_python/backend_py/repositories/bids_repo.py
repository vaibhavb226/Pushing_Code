from __future__ import annotations

from pathlib import Path

from repositories.base import JsonRepository


class BidsRepository(JsonRepository):
    """Repository for bids.json — array of bid objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)
