"""
Thread-safe async JSON file repository.

One asyncio.Lock per file path is shared across all instances that open the
same path — this prevents concurrent writes from racing.

Usage
-----
class BidsRepository(JsonRepository):
    pass

repo = BidsRepository(Path("data/bids.json"))
bids = await repo.load()
"""
from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from collections.abc import Callable
from pathlib import Path
from typing import Any, TypeVar

import aiofiles

T = TypeVar("T", bound=dict[str, Any])

# Module-level lock registry — shared across all instances
_LOCKS: dict[Path, asyncio.Lock] = {}


def _get_lock(path: Path) -> asyncio.Lock:
    resolved = path.resolve()
    if resolved not in _LOCKS:
        _LOCKS[resolved] = asyncio.Lock()
    return _LOCKS[resolved]


class AbstractRepository(ABC):
    """Minimal interface implemented by both JSON and DB backends."""

    @abstractmethod
    async def load(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def save(self, data: list[dict[str, Any]]) -> None: ...

    @abstractmethod
    async def find_one(
        self, predicate: Callable[[dict[str, Any]], bool]
    ) -> dict[str, Any] | None: ...

    @abstractmethod
    async def update_one(
        self,
        predicate: Callable[[dict[str, Any]], bool],
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any] | None: ...

    @abstractmethod
    async def append(self, item: dict[str, Any]) -> dict[str, Any]: ...

    @abstractmethod
    async def delete_where(
        self, predicate: Callable[[dict[str, Any]], bool]
    ) -> int: ...


class JsonRepository(AbstractRepository):
    """Async, lock-protected flat JSON file store."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = _get_lock(path)

    # ── Helpers ──────────────────────────────────────────────

    async def _read(self) -> list[dict[str, Any]]:
        try:
            async with aiofiles.open(self._path, encoding="utf-8") as f:
                content = await f.read()
            return json.loads(content) if content.strip() else []
        except FileNotFoundError:
            return []

    async def _write(self, data: list[dict[str, Any]]) -> None:
        async with aiofiles.open(self._path, "w", encoding="utf-8") as f:
            await f.write(json.dumps(data, indent=2, ensure_ascii=False))

    # ── Public API ────────────────────────────────────────────

    async def load(self) -> list[dict[str, Any]]:
        async with self._lock:
            return await self._read()

    async def save(self, data: list[dict[str, Any]]) -> None:
        async with self._lock:
            await self._write(data)

    async def find_one(
        self, predicate: Callable[[dict[str, Any]], bool]
    ) -> dict[str, Any] | None:
        data = await self.load()
        return next((item for item in data if predicate(item)), None)

    async def update_one(
        self,
        predicate: Callable[[dict[str, Any]], bool],
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any] | None:
        async with self._lock:
            data = await self._read()
            idx = next((i for i, item in enumerate(data) if predicate(item)), None)
            if idx is None:
                return None
            data[idx] = updater(data[idx])
            await self._write(data)
            return data[idx]

    async def append(self, item: dict[str, Any]) -> dict[str, Any]:
        async with self._lock:
            data = await self._read()
            data.append(item)
            await self._write(data)
        return item

    async def delete_where(
        self, predicate: Callable[[dict[str, Any]], bool]
    ) -> int:
        async with self._lock:
            data = await self._read()
            before = len(data)
            data = [item for item in data if not predicate(item)]
            await self._write(data)
            return before - len(data)
