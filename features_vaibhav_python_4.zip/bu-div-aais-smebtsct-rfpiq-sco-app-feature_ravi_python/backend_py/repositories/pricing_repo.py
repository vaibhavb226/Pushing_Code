from __future__ import annotations

from pathlib import Path

from repositories.base import JsonRepository


class PricingRepository(JsonRepository):
    """Repository for pricingData.json — array of pricing records."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)
