"""
Re-exports JsonRepository for explicit import from the backends package.
"""
from repositories.base import JsonRepository

__all__ = ["JsonRepository"]
