"""
SQLAlchemy async repository backend.

Inactive by default (DB_BACKEND=json). Activated when DB_BACKEND=sqlite or
DB_BACKEND=postgres is set in the environment.

The DbRepository class implements the same AbstractRepository interface as
JsonRepository so routers work unchanged after the switch.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from repositories.base import AbstractRepository


class DbRepository(AbstractRepository):
    """
    Stub implementation — to be completed when DB_BACKEND is activated.

    Each entity-specific repo (BidsDbRepository etc.) will subclass this
    and provide `_model` pointing to the relevant SQLAlchemy ORM model.
    """

    def __init__(self, session: AsyncSession, model: type) -> None:
        self._session = session
        self._model = model

    async def load(self) -> list[dict[str, Any]]:
        from sqlalchemy import select
        result = await self._session.execute(select(self._model))
        rows = result.scalars().all()
        return [self._to_dict(row) for row in rows]

    async def save(self, data: list[dict[str, Any]]) -> None:
        raise NotImplementedError("Use update_one / append for individual records")

    async def find_one(
        self, predicate: Callable[[dict[str, Any]], bool]
    ) -> dict[str, Any] | None:
        rows = await self.load()
        return next((r for r in rows if predicate(r)), None)

    async def update_one(
        self,
        predicate: Callable[[dict[str, Any]], bool],
        updater: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> dict[str, Any] | None:
        rows = await self.load()
        target = next((r for r in rows if predicate(r)), None)
        if target is None:
            return None
        updated = updater(target)
        # Flush back — subclasses must implement _apply_update
        await self._apply_update(updated)
        return updated

    async def append(self, item: dict[str, Any]) -> dict[str, Any]:
        instance = self._model(**item)
        self._session.add(instance)
        await self._session.flush()
        return item

    async def delete_where(
        self, predicate: Callable[[dict[str, Any]], bool]
    ) -> int:
        rows = await self.load()
        targets = [r for r in rows if predicate(r)]
        for t in targets:
            await self._apply_delete(t)
        return len(targets)

    def _to_dict(self, row: Any) -> dict[str, Any]:
        return {c.name: getattr(row, c.name) for c in row.__table__.columns}

    async def _apply_update(self, updated: dict[str, Any]) -> None:
        raise NotImplementedError

    async def _apply_delete(self, record: dict[str, Any]) -> None:
        raise NotImplementedError
