from __future__ import annotations

from pathlib import Path
from typing import Any

from repositories.base import JsonRepository


class LineItemsRepository(JsonRepository):
    """Repository for lineItems.json — array of line item objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)

    async def get_for_bid(self, bid_id: str) -> list[dict[str, Any]]:
        data = await self.load()
        return [item for item in data if item.get("bidId") == bid_id]

    async def smart_merge_pricing(
        self, line_id: str, new_pricing: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """
        Merge supplierPricing array without duplicating entries.
        Deduplication key: (supplierName + supplierItemNo) OR (supplierName + emailId).
        Mirrors the smart-merge logic in bids.js PATCH line-items.
        """
        def updater(item: dict[str, Any]) -> dict[str, Any]:
            existing: list[dict[str, Any]] = item.get("supplierPricing", [])
            for new_entry in new_pricing:
                new_name = new_entry.get("supplierName", "")
                new_item_no = new_entry.get("supplierItemNo", "")
                new_email_id = new_entry.get("emailId", "")

                # Find duplicate by supplierName + supplierItemNo
                dup_idx = next(
                    (
                        i for i, e in enumerate(existing)
                        if e.get("supplierName") == new_name
                        and (
                            (new_item_no and e.get("supplierItemNo") == new_item_no)
                            or (new_email_id and e.get("emailId") == new_email_id)
                        )
                    ),
                    None,
                )
                if dup_idx is not None:
                    existing[dup_idx] = {**existing[dup_idx], **new_entry}
                else:
                    existing.append(new_entry)
            item["supplierPricing"] = existing
            return item

        return await self.update_one(lambda x: x.get("id") == line_id, updater)
