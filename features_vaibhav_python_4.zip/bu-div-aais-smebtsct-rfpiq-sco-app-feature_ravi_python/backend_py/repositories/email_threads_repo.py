from __future__ import annotations

from pathlib import Path
from typing import Any

from repositories.base import JsonRepository


class EmailThreadsRepository(JsonRepository):
    """Repository for emailThreads.json — array of email objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)

    async def get_for_bid(self, bid_id: str) -> list[dict[str, Any]]:
        data = await self.load()
        return [e for e in data if e.get("bidId") == bid_id]
