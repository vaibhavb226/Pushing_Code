"""
Alembic env.py — async SQLAlchemy migrations.

Run:
    alembic revision --autogenerate -m "initial"
    alembic upgrade head
"""
import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy.ext.asyncio import create_async_engine

# Import all models so Alembic can detect schema
from repositories.models import Base  # noqa: F401
from repositories.models.bid import Bid  # noqa: F401
from repositories.models.supplier import Supplier  # noqa: F401
from repositories.models.line_item import LineItem  # noqa: F401
from repositories.models.email_thread import EmailThread  # noqa: F401
from repositories.models.document import Document  # noqa: F401
from repositories.models.submission import Submission  # noqa: F401

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(url=url, target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection):
    context.configure(connection=connection, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    url = config.get_main_option("sqlalchemy.url")
    engine = create_async_engine(url)
    async with engine.connect() as conn:
        await conn.run_sync(do_run_migrations)
    await engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
