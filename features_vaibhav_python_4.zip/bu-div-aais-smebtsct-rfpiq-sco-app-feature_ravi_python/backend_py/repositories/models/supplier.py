from __future__ import annotations

from sqlalchemy import JSON, Boolean, String
from sqlalchemy.orm import Mapped, mapped_column

from repositories.models.base import Base


class Supplier(Base):
    __tablename__ = "suppliers"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    category: Mapped[str] = mapped_column(String, default="Grocery")
    subcategories: Mapped[list] = mapped_column(JSON, default=list)
    region: Mapped[str] = mapped_column(String, default="National")
    contact: Mapped[str] = mapped_column(String, default="")
    contact_name: Mapped[str] = mapped_column(String, default="")
    phone: Mapped[str] = mapped_column(String, default="")
    broker: Mapped[bool] = mapped_column(Boolean, default=False)
    segments: Mapped[list] = mapped_column(JSON, default=list)
    tags: Mapped[list] = mapped_column(JSON, default=list)
    notes: Mapped[str] = mapped_column(String, default="")
    bounce: Mapped[bool] = mapped_column(Boolean, default=False)
