from __future__ import annotations

from sqlalchemy import JSON, Boolean, String
from sqlalchemy.orm import Mapped, mapped_column

from repositories.models.base import Base


class EmailThread(Base):
    __tablename__ = "email_threads"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    bid_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    direction: Mapped[str] = mapped_column(String, default="outbound")
    supplier_id: Mapped[str | None] = mapped_column(String)
    supplier_name: Mapped[str | None] = mapped_column(String)
    supplier_email: Mapped[str | None] = mapped_column(String)
    from_: Mapped[str | None] = mapped_column("from_address", String)
    to: Mapped[str | None] = mapped_column(String)
    bcc: Mapped[list] = mapped_column(JSON, default=list)
    subject: Mapped[str] = mapped_column(String, default="")
    body: Mapped[str] = mapped_column(String, default="")
    date: Mapped[str] = mapped_column(String)
    attachments: Mapped[list] = mapped_column(JSON, default=list)
    tags: Mapped[list] = mapped_column(JSON, default=list)
    read: Mapped[bool] = mapped_column(Boolean, default=False)
    analysis_result: Mapped[dict | None] = mapped_column(JSON)
    is_bounce: Mapped[bool] = mapped_column(Boolean, default=False)
    original_recipient: Mapped[str | None] = mapped_column(String)
    bounce_code: Mapped[str | None] = mapped_column(String)
    bounce_reason: Mapped[str | None] = mapped_column(String)
    portal_submission: Mapped[bool] = mapped_column(Boolean, default=False)
    thread_id: Mapped[str | None] = mapped_column(String)
    confirmation_id: Mapped[str | None] = mapped_column(String)
