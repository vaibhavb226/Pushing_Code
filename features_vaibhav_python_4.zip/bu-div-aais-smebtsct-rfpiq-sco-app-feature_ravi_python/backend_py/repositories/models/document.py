from __future__ import annotations

from sqlalchemy import JSON, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from repositories.models.base import Base


class Document(Base):
    __tablename__ = "documents"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    file_name: Mapped[str] = mapped_column(String, nullable=False)
    file_type: Mapped[str] = mapped_column(String, default="")
    size_kb: Mapped[int] = mapped_column(Integer, default=0)
    supplier: Mapped[str] = mapped_column(String, default="")
    supplier_id: Mapped[str | None] = mapped_column(String)
    bid_id: Mapped[str] = mapped_column(String, default="")
    document_type: Mapped[str] = mapped_column(String, default="")
    tags: Mapped[list] = mapped_column(JSON, default=list)
    upload_date: Mapped[str] = mapped_column(String, default="")
    uploaded_by: Mapped[str] = mapped_column(String, default="")
    status: Mapped[str] = mapped_column(String, default="Filed")
    file_path: Mapped[str] = mapped_column(String, default="")
    description: Mapped[str] = mapped_column(String, default="")
    extraction_confidence: Mapped[int | None] = mapped_column(Integer)
