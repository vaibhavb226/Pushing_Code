from __future__ import annotations

from sqlalchemy import JSON, Boolean, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from repositories.models.base import Base


class LineItem(Base):
    __tablename__ = "line_items"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    bid_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    bid_item: Mapped[str] = mapped_column(String, default="")
    mpc_code: Mapped[str] = mapped_column(String, default="")
    brand: Mapped[str] = mapped_column(String, default="")
    description: Mapped[str] = mapped_column(String, default="")
    pack: Mapped[str] = mapped_column(String, default="")
    size: Mapped[str] = mapped_column(String, default="")
    unit: Mapped[str] = mapped_column(String, default="")
    category: Mapped[str] = mapped_column(String, default="")
    qty: Mapped[int] = mapped_column(Integer, default=0)
    storage: Mapped[str] = mapped_column(String, default="")
    cw: Mapped[str] = mapped_column(String, default="N")
    stk_type: Mapped[str] = mapped_column(String, default="A")
    buy_american: Mapped[bool] = mapped_column(Boolean, default=False)
    child_nutrition: Mapped[bool] = mapped_column(Boolean, default=False)
    pfs_required: Mapped[bool] = mapped_column(Boolean, default=False)
    exact_spec: Mapped[bool] = mapped_column(Boolean, default=False)
    rfp_populated: Mapped[bool] = mapped_column(Boolean, default=True)
    true_vendor: Mapped[str | None] = mapped_column(String)
    supplied_price: Mapped[float | None] = mapped_column(Float)
    allw: Mapped[float | None] = mapped_column(Float)
    dl: Mapped[float | None] = mapped_column(Float)
    price_case: Mapped[float | None] = mapped_column(Float)
    dev_type: Mapped[str | None] = mapped_column(String)
    open_review: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String, default="No Response")
    confidence: Mapped[float | None] = mapped_column(Float)
    supplier_pricing: Mapped[list] = mapped_column(JSON, default=list)
