from __future__ import annotations

from sqlalchemy import JSON, Boolean, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from repositories.models.base import Base


class Bid(Base):
    __tablename__ = "bids"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    customer: Mapped[str] = mapped_column(String, nullable=False)
    opco: Mapped[str | None] = mapped_column(String)
    opco_name: Mapped[str | None] = mapped_column(String)
    region: Mapped[str | None] = mapped_column(String)
    segment: Mapped[str | None] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="Active")
    intake_date: Mapped[str | None] = mapped_column(String)
    customer_due: Mapped[str | None] = mapped_column(String)
    internal_due: Mapped[str | None] = mapped_column(String)
    bid_release: Mapped[str | None] = mapped_column(String)
    items: Mapped[int] = mapped_column(Integer, default=0)
    suppliers_contacted: Mapped[int] = mapped_column(Integer, default=0)
    responses_received: Mapped[int] = mapped_column(Integer, default=0)
    notes: Mapped[str | None] = mapped_column(String)
    compliance: Mapped[list] = mapped_column(JSON, default=list)
    item_categories: Mapped[list] = mapped_column(JSON, default=list)
    solicited_suppliers: Mapped[list] = mapped_column(JSON, default=list)
    uploaded_files: Mapped[list] = mapped_column(JSON, default=list)
    auto_reminder: Mapped[dict | None] = mapped_column(JSON)
    portal_config: Mapped[dict | None] = mapped_column(JSON)
    working_file_config: Mapped[dict | None] = mapped_column(JSON)
