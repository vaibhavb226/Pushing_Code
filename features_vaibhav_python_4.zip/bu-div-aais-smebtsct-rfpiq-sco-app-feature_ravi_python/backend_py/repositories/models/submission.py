from __future__ import annotations

from sqlalchemy import JSON, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from repositories.models.base import Base


class Submission(Base):
    __tablename__ = "submissions"

    confirmation_id: Mapped[str] = mapped_column(String, primary_key=True)
    thread_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    bid_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    submitted_at: Mapped[str] = mapped_column(String)
    supplier_name: Mapped[str] = mapped_column(String)
    supplier_email: Mapped[str] = mapped_column(String)
    contact_name: Mapped[str] = mapped_column(String, default="")
    phone: Mapped[str] = mapped_column(String, default="")
    notes: Mapped[str] = mapped_column(String, default="")
    line_items: Mapped[list] = mapped_column(JSON, default=list)
    pricing_file: Mapped[str | None] = mapped_column(String)
    priced_count: Mapped[int] = mapped_column(Integer, default=0)
    no_bid_count: Mapped[int] = mapped_column(Integer, default=0)
    messages: Mapped[list] = mapped_column(JSON, default=list)
