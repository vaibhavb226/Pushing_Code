from repositories.models.base import Base  # noqa: F401 — ensure Base is importable

__all__ = ["Base"]
