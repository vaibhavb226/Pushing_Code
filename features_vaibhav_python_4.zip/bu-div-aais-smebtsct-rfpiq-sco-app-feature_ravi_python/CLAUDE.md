# CLAUDE.md — Sysco BID/RFP POC Project Memory

> **Last updated:** June 14, 2026 | **Status:** Active Development
> This file is the persistent memory context for all Claude Code sessions on this project.
>
> ⚠️ **PORTAL FEATURE ACTIVE** — Portal code is live. Search `PORTAL-TEMPLATE` (Cmd+Shift+F) to find all portal template blocks.
> Portal routes: `/submit/:bidId` and `/submit/:bidId/thread/:threadId`

---

## 1. PROJECT OVERVIEW

Sysco RFP AIQ — AI-powered procurement tool for Sysco's Bid COE team (Tricia Johnson).
Replaces manual Excel + Outlook workflow.
Built by EXL Service — May 2026.

- **Client:** Sysco Corporation — Merchandising BID Assortment Team (Bid COE)
- **Primary Contact:** Tricia Johnson — Manager, Merchandising BID Assortment, Contract Customers
- **Built by:** EXL Service — Tauseef Ahmad, Manish Gupta, Arvind Mehta, Ravi, Vaibhav
- **Tricia's top quote:** *"Anything that's manual, you can't push. Anything AI, you can push."*

---

## 2. TECH STACK

**Frontend:** React 18 + Tailwind CSS + Vite
- Runs on http://localhost:5173
- Entry: `frontend/src/App.jsx`

**Backend:** Node.js + Express
- Runs on http://localhost:3001
- Entry: `backend/server.js`
- Uses dotenv — `.env` file must be in `/backend` (not project root)

**AI:** Anthropic `claude-sonnet-4-20250514`
- API key: `ANTHROPIC_API_KEY` in `backend/.env`
- dotenv must use `{ override: true }` — shell env may have empty string that blocks loading

**Email:** Nodemailer (outbound SMTP) + ImapFlow (inbound poller)
- Outbound: Gmail SMTP via `backend/services/emailService.js`
- Inbound: IMAP poller via `backend/services/emailPoller.js` — runs every 15 s

**Brand Colors:**
- EXL Orange: `#E05A2B` — titles, accents, active tab underline
- EXL Navy: `#1F3864` — headers, segment icons

---

## 3. DATA FILES

Both `backend/data/` and `frontend/src/data/` hold identical copies of:

| File | Contents |
|------|----------|
| `bids.json` | Active bids (currently 11 after POC testing) |
| `suppliers.json` | 20 suppliers with categories, segments, compliance tags, bounce flags |
| `lineItems.json` | Line items per bid, linked by `bidId` |
| `emailThreads.json` | Email threads per bid, direction inbound/outbound, tags, attachments |
| `pricingData.json` | Supplier pricing responses linked to bids |
| `documents.json` | Document vault files with category, type, tags, status |
| `unmatchedEmails.json` | Inbound emails the IMAP poller could not match to a bid |

**IMPORTANT — keep in sync:** Backend `data/` is the source of truth. After any manual data change, run:
```bash
cp backend/data/bids.json frontend/src/data/bids.json
```

**lineItems.json field names** (post-migration):
`id, bidId, bidItem, mpcCode, brand, description, pack, size, unit (UOM), category, qty (Volume), storage, cw, stkType, buyAmerican, childNutrition, pfsRequired, exactSpec, rfpPopulated, _source, trueVendor, suppliedPrice, allw, dl, priceCase, devType, openReview, status, confidence`

Note: `supc` field intentionally omitted from extraction — appears in Working File as blank column only.

**`_source` field:** `'excel'` | `'pdf'` — set by `lineItemParser.js` to track where items came from. Also stored on `bid._lineItemSource`. Displayed in WorkingFileTab header as "Imported from Excel" or "Extracted from RFP PDF by AI".

### Line Item Auto-Parser — `backend/services/lineItemParser.js`

Line items auto-parsed from Excel (structured column mapping) or RFP PDF (AI extraction) on upload. **Excel takes priority over PDF** — if both are uploaded for the same bid, Excel overwrites PDF result.

| Export | Description |
|--------|-------------|
| `parseLineItemsFromExcel(bidId, filePath)` | Reads XLSX, maps columns via flexible keyword matching, saves to lineItems.json |
| `parseLineItemsFromPDF(bidId, filePath)` | Extracts PDF text via pdf-parse, sends to Anthropic AI, saves to lineItems.json |
| `autoParseLineItems(bidId, file, filePath)` | Detects file type (mime + extension) and calls correct parser |
| `saveLineItemsToDB(bidId, items, source)` | Shared: replaces bid's items in lineItems.json, updates bid metadata |

**Integration points:**
- `bids.js POST /api/bids/:bidId/files` — calls `autoParseLineItems` in background (`setImmediate`) for docType "Item List" or "RFP" uploads
- `rfpParser.js POST /api/parse-rfp/create` — if BEX AI returns 0 items, falls back to PDF then Excel parsing from tempPdfPath/tempExcelPath
- `server.js startup` — `backfillLineItemsFromFiles()` runs on boot; for bids with uploaded files but 0 line items, parses from best available file

---

## 4. PAGES & ROUTES

| URL | Component | Description |
|-----|-----------|-------------|
| `/` or `/bids` | `BidQueue` | Homepage — bid dashboard grouped by segment |
| `/bex` | `BexAI` | Upload RFP — BEX AI parser |
| `/vault` | `DocumentVault` | Document vault — categorised file browser |
| `/bids/:bidId` | `BidDetail` | 4-tab bid detail view |

---

## 5. BID DETAIL TABS

Tabs appear in this order (Overview is the default):

| Order | Tab ID | Label | Icon |
|-------|--------|-------|------|
| 1 | `overview` | Overview | LayoutDashboard |
| 2 | `emailrepo` | Email Repo | Mail |
| 3 | `workingfile` | Working File | FileSpreadsheet |
| 4 | `suppliers` | Supplier List | Users |

**Tab routing:**
- Default tab: `overview`
- URL param `?tab=workingfile` switches tab on load (used by "Create Working File" flow)
- URL param `?edit=1` auto-opens edit form on Overview tab, then cleans itself from URL

**Tab badges (live — fetched from API, not from raw JSON fields):**
- Email Repo: fetches actual count from `GET /api/bids/:id/emails` on mount; refreshes after `onResponseLogged`
- Supplier List: uses `getSuppliersContacted(bid)` = `bid.solicitedSuppliers?.length ?? bid.suppliersContacted ?? 0`

---

## 6. WORKING FILE COLUMN STRUCTURE

**LEFT SIDE (white background — from Customer RFP):**

| Column | Field | Notes |
|--------|-------|-------|
| Item # | `bidItem` | 4-digit padded string |
| SUPC | `supc` | Blank — filled later from Sysco item master |
| MPC Code | `mpcCode` | Manufacturer product code |
| UOM | `unit` | Unit of measure (CS, EA, etc.) |
| Volume | `qty` | Estimated annual quantity |
| Pack | `pack` | e.g. "6" |
| Size | `size` | e.g. "10 oz" |
| Brand | `brand` | |
| Description | `description` | |
| Category | `category` | Abbreviation via CA_MAP |
| CW | `cw` | Catchweight Y/N |
| STK Type | `stkType` | A = Active |
| Compliance | flags | CN / Buy Am. / PFS / ES pills |

**RIGHT SIDE (blue `#EBF3FB` background — from Supplier Responses):**

| Column | Field | Notes |
|--------|-------|-------|
| True Vendor | `trueVendor` | Replaces old "Supplier" label |
| Dev Type | `devType` | ALLW or DL or blank |
| Supplied Price | `suppliedPrice` | |
| ALLW $ | `allw` | Allowance off-invoice |
| DL $ | `dl` | Delivered cost override |
| Net $/Case | `priceCase` | |
| Open Review | `openReview` | Y/N flag |
| Confidence | `confidence` | % with colour coding |

**Right-side column styling:** Uses inline `style={{ backgroundColor: '#EBF3FB' }}` on individual `<td>` elements — NOT row-level TR backgrounds — so blue persists through hover states.

**Section header row:** `colSpan={13}` "Customer RFP" + `colSpan={8}` "Supplier Responses"

**SUPC note:** SUPC is Sysco's internal product code. It is **NOT** extracted from the RFP by BEX AI. It appears in the Working File as a blank column (shows "TBD" in italic grey). SUPC must **NOT** appear in the BEX AI parse results table.

---

## 7. BEX AI — RFP PARSER

**Route:** `/bex` → Component: `frontend/src/components/BexAI/index.jsx`

**Backend endpoint:** `POST /api/parse-rfp`
- Accepts PDF + Excel via multer (`memoryStorage()`)
- Extracts PDF text with `pdf-parse`
- Extracts Excel rows with `xlsx` → `XLSX.read(buffer, { type: 'buffer' })`
- Sends combined content to Anthropic API with BEX system prompt
- Returns: `{ metadata, line_items, supplier_targeting, parsing_warnings }`
- `max_tokens: 8000` — required for large 28+ item RFPs

**Extracted fields per line item** (no SUPC):
`line_number | mpc_code | uom | volume | pack | size | brand | description | category | buy_american | child_nutrition | pfs_required | exact_spec`

**BEX AI system prompt critical rules:**
- Do NOT extract or include SUPC
- Return only valid JSON — no markdown, no preamble
- Start response with `{` end with `}` (prevents truncation issues)
- `volume` = estimated annual quantity (replaces old `est_qty`)
- `mpc_code` = manufacturer product code (replaces old `mfg_code`)

**Flow after parse → Step 2 (Confirm Bid Details form):**
Fields: `customer_name | bid_id | segment | opco | opco_name | region | bid_release | customer_due | internal_due | compliance_flags | item_categories | notes`

Save → `POST /api/bids` → creates bid in `bids.json` + saves line items to `lineItems.json` → navigates to `/bids/:newBidId`

**`buildLineItem()` helper** (exported from `backend/routes/rfpParser.js`, used by both rfpParser and bids.js):
```js
export function buildLineItem(li, bidId, idx) {
  return {
    id:          `LI-${bidId}-${String(idx + 1).padStart(3, '0')}`,
    bidId,
    bidItem:     String(li.line_number || (idx + 1)).padStart(4, '0'),
    mpcCode:     li.mpc_code    || li.mfg_code || '',
    brand:       li.brand       || '',
    description: li.description || '',
    pack:        li.pack        || '',
    size:        li.size        || '',
    unit:        li.uom         || '',
    category:    li.category    || '',
    qty:         Number(li.volume ?? li.est_qty) || 0,
    storage:     li.storage     || '',
    cw:          'N',
    stkType:     'A',
    buyAmerican:    Boolean(li.buy_american),
    childNutrition: Boolean(li.child_nutrition),
    pfsRequired:    Boolean(li.pfs_required),
    exactSpec:      Boolean(li.exact_spec),
    rfpPopulated:   true,
    trueVendor:     null,
    suppliedPrice:  null,
    allw:       null,
    dl:         null,
    priceCase:  null,
    devType:    null,
    openReview: false,
    status:     'No Response',
    confidence: null,
  }
}
```

---

## 8. API ENDPOINTS

```
GET    /api/health
GET    /api/bids
POST   /api/bids
GET    /api/bids/:id
PATCH  /api/bids/:id
DELETE /api/bids/:id              # Cascading delete — see Section 16
GET    /api/bids/:id/line-items
PATCH  /api/bids/:id/line-items/:lineId
GET    /api/bids/:id/emails/by-supplier   # Grouped view for Email Repo tab
GET    /api/bids/:id/emails
POST   /api/bids/:id/emails
GET    /api/suppliers
POST   /api/suppliers/auto-populate
GET    /api/documents
POST   /api/documents/upload
POST   /api/parse-rfp
POST   /api/analyse-response
POST   /api/extract-pricing
GET    /api/email/poll-now        # Manual IMAP poll trigger (dev/testing)
POST   /api/ai/chat               # RFP AIQ — conversational intelligence
GET    /api/submit/:bidId                           # Public portal — bid info + line items
POST   /api/submit/:bidId                           # Public portal — supplier pricing submission
GET    /api/submit/:bidId/submissions               # Portal submission summaries for SuppliersTab
GET    /api/submit/:bidId/thread/:threadId          # Thread view (email-verified); returns messageCount + lastUpdated
POST   /api/submit/:bidId/message                   # Supplier follow-up message on existing thread
GET    /api/submit/:bidId/status/:confirmationId    # Check submission receipt
POST   /api/bids/:bidId/portal-reply                # COE reply → appends outbound msg + sends Nodemailer email
```

**PATCH /api/bids/:id** — accepts any subset of bid fields including `status`. Used by Edit Bid Details form.

---

## 9. AT RISK LOGIC

A bid is "At Risk" if **any** of these are true:
- `status === "At Risk"` in bids.json
- Internal due date has already passed (overdue)
- Days until internal due date is 7 or fewer

**`isAtRisk(bid)` predicate** (exported from `frontend/src/utils/bidUtils.js`):
```js
export const isAtRisk = (bid) =>
  bid.status === 'At Risk' || getDaysUntilDue(bid.internalDue) <= 7
```

Used in both `computeStats()` (AT RISK stat card) and `BidCard` (red left border).

**Bid card days remaining display (DueBadge):**
| Days | Display | Style |
|------|---------|-------|
| > 7 | `Xd left` | Grey |
| 1–7 | `Xd left` | Amber |
| 0 | `Due Today` | Red |
| Past due | `Xd overdue` | Dark red |

---

## 10. EDIT BID DETAILS

**Trigger points:**
1. Overview tab → "Edit Bid Details" button (pencil icon)
2. Bid Queue → three-dot menu on BidCard → "Edit Bid Details" → navigates to `?tab=overview&edit=1`

**Auto-open via URL:** `BidDetail/index.jsx` reads `searchParams.get('edit') === '1'` → passes `autoEdit` prop to `OverviewTab` → `useEffect([autoEdit])` calls `setEditing(true)` then `window.history.replaceState` to remove `?edit=1` from URL.

**Edit form fields:**
- Customer Name (required)
- Bid ID (read-only)
- Segment (dropdown — 7 segments)
- Status (dropdown — Active | Solicitation | Working File | Review | At Risk | Awarded | Cancelled)
- OpCo Code
- OpCo Name
- Region (dropdown)
- Bid Release Date
- Customer Due Date (required)
- Internal Due Date (auto: Customer Due − 5 days)
- Compliance Flags (toggle pills)
- Notes (optional)

**Save:** `PATCH /api/bids/:id` → `onBidUpdate(updatedBid)` propagates to `BidDetail` state (header, tabs, and queue all reflect changes).

---

## 11. STATUS CONFIG

```js
// ALL_STATUSES (bidUtils.js)
['Active', 'Solicitation', 'Working File', 'Review', 'At Risk', 'Awarded', 'Cancelled']

// STATUS_CONFIG
'Active':       bg-green-100  / text-green-800  / dot bg-green-500
'Solicitation': bg-blue-100   / text-blue-800   / dot bg-blue-500
'Working File': bg-amber-100  / text-amber-800  / dot bg-amber-500
'Review':       bg-purple-100 / text-purple-800 / dot bg-purple-500
'At Risk':      bg-red-100    / text-red-800    / dot bg-red-500
'Awarded':      bg-gray-100   / text-gray-600   / dot bg-gray-400
'Cancelled':    bg-gray-100   / text-gray-500   / dot bg-gray-300
```

---

## 12. KEY BUSINESS RULES

- Bid ID cannot be changed after creation (read-only in edit form)
- SUPC populated later from item master — not extracted from RFP
- All suppliers BCC'd on solicitation emails (no To: field used)
- Bounced suppliers (`bounce: true`) auto-excluded from solicitation list
- Confidence colour coding: `≥90%` → green (auto-accepted), `75–89%` → amber (requires Approve), `<75%` → red (Review Needed)
- Dev Type: `ALLW` = allowance off-invoice, `DL` = delivered cost override
- Internal due date defaults to 5 days before customer due date
- `True Vendor` = the supplier who submitted pricing (renamed from old "Supplier" field)
- Response rate is calculated from `solicitedSuppliers` array, not raw `suppliersContacted` / `responsesReceived` fields

---

## 13. EMAIL SYSTEM

### Outbound — Nodemailer Gmail SMTP

**Service:** `backend/services/emailService.js`
- `sendEmail({ to, bcc, subject, body, attachmentNames })` — sends via STARTTLS port 587
- App Password spaces are stripped (`.replace(/\s/g, '')`) before auth
- Translates SMTP errors to user-friendly messages (EAUTH → App Password note)
- Gmail requires a `To:` even for BCC-only sends — uses sender address as To
- `verifyEmailConfig()` called at server startup → logs ✅ or ⚠️

**Config in `backend/.env`:**
```
ANTHROPIC_API_KEY=sk-ant-...
EMAIL_FROM=sysco.bid.poc@gmail.com
EMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx   # Google App Password (spaces OK)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_IMAP_HOST=imap.gmail.com
EMAIL_IMAP_PORT=993
```

**POST /api/bids/:bidId/emails:**
- `direction: 'outbound'` → calls `sendEmail()` first; returns 502 if SMTP fails (never silently saves on failure)
- `direction: 'inbound'` → saves directly (manual log, no send)
- Both save to `backend/data/emailThreads.json` with `supplierId`, `supplierName`, `supplierEmail` fields

### Inbound — IMAP Poller

**Service:** `backend/services/emailPoller.js`
- Polls Gmail inbox via IMAP (ImapFlow library) every **15 seconds** in dev
- Started automatically at server boot via `startEmailPoller()` in `server.js`
- Manual trigger: `GET /api/email/poll-now`

**Matching strategy (3 tiers, in order):**
1. Bid ID pattern in subject (`B2600042`, `BID-106`, `BID-B2500019`)
2. Cleaned subject matches a stored solicitation subject (strips Re:/Fwd: prefixes)
3. All significant words (4+ chars) from customer name appear in subject

**On match:**
- Saves email to `emailThreads.json` with `direction: 'inbound'`
- Calls `updateSupplierStatus()` — sets the matching supplier's `solicitedSuppliers` entry to `"Responded"` if their email matches the sender
- Marks IMAP message as Seen

**On no match:** Saves to `unmatchedEmails.json` for manual review

**Email Repository tab supplier fields** (required in emailThreads.json):
- `supplierId` — links email to supplier row in grouped view (null for solicitation)
- `supplierName` — display name
- `supplierEmail` — supplier's email address
- `analysisResult` — AI analysis output (null until file is analysed)

---

## 14. SUPPLIER LIST TAB

**Component:** `frontend/src/components/BidDetail/SuppliersTab.jsx`

### Status — READ-ONLY (as of June 2026)
- Status badges are **static** — no dropdown, no manual override
- Status is driven entirely by the Email Repo tab (set from `solicitedSuppliers` in `bids.json`)
- Changing status happens in Email Repo only (Mark Awarded, Mark Under Consideration, etc.)

**Status values:**

| Status | Colour | Meaning |
|--------|--------|---------|
| Awaiting | Grey | Email sent, no reply yet |
| Contacted | Grey | Initial contact made |
| Responded | Emerald | Reply received |
| Issues Found | Amber | Bounce or response problem |
| Follow-up Sent | Blue | Re-solicitation sent |
| Under Consideration | Orange | Flagged by COE |
| Awarded | Teal | Supplier awarded this bid |

### Channel column
- `Email` (grey, Mail icon) — default
- `Portal` (emerald, Globe icon) — supplier has submitted pricing via portal (`submittedAt` OR `pricedCount > 0`)
- `Both` (blue, Mail+Globe) — supplier used both channels
- `threadId` alone does NOT trigger Portal (COE-initiated threads don't count)

### Configure Portal Form banner
- Appears at top of tab **before and after** solicitation
- **Blue banner** (unconfigured): "Configure the supplier portal form…" + "Configure Now" button
- **Green banner** (configured): shows template name + custom field count + "Edit" button
- Slide-in panel from right: template selector, standard field list, custom fields, "Apply to Bid" footer
- Backend: `GET /api/portal-templates`, `PATCH /api/bids/:bidId/portal-config`

### Send Award Notifications button
- Appears when `awardedSuppliers.length > 0`
- Label: `"Send Award Notifications (X)"`
- Opens bulk award email flow for all awarded suppliers

### Solicited Suppliers section (shown after first solicitation send)
- Displays all entries from `bid.solicitedSuppliers` array
- Subtitle: `"Solicitation sent to X supplier(s) on [date]"` (pluralises correctly)
- Summary badges show counts: Responded / Issues Found / Awaiting
- Re-solicit Awaiting button — composes targeted follow-up to non-responders only

### Add Supplier section (above solicited list)
- **Typeahead search** — type supplier name to search `suppliers.json`; shows matching results as dropdown
- **Add new supplier** — if no match, shows "Add [name] as new supplier" option → opens inline form
- New supplier form fields: name, category, contact email, region, segments
- Saves to `backend/data/suppliers.json` via POST `/api/suppliers`

---

## 15. EMAIL REPO TAB

**Component:** `frontend/src/components/BidDetail/EmailRepoTab.jsx`

**Layout:** Two-panel view
- **Left panel:** Supplier list — one row per supplier/thread, status badge, last activity date, issue count
- **Right panel:** Conversation thread for selected supplier — chronological emails with direction, tags, attachments

**Filter pills:** All | ✓ Responded | ⚠ Issues | ⏳ Awaiting | 🏆 Awarded | 🚩 Under Consideration

**Data:** Fetched from `GET /api/bids/:id/emails/by-supplier` which groups `emailThreads.json` by `supplierId`. Manual status overrides ("Issues Found", "Awarded", etc.) from `bid.solicitedSuppliers` take precedence via `MANUAL_OVERRIDE_STATUSES` list.

**Auto-capture:** IMAP poller automatically adds inbound replies; Email Repo badge refreshes after every `onResponseLogged` event.

**AI analysis:** Each inbound email with attachments can trigger `POST /api/analyse-response` → result stored in `email.analysisResult`

### Bounce email display
- Bounce emails: `isBounce: true` in `emailThreads.json`
- Direction badge shows **red "Delivery Failed"** instead of green "Inbound"
- Red ⚠ Delivery Failure banner above body shows: Error Code, Reason, Failed Address
- "Update Email Address" button → inline form → "Update & Re-solicit" button
- On submit: PATCHes `solicitedSuppliers` entry with new email, sends re-solicitation outbound email, sets status to `"Follow-up Sent"`, shows toast

### Award workflow from Email Repo
- "Mark Awarded" button in supplier thread header (shown when status ≠ Awaiting)
- Toggling Awarded → triggers two-step award email modal: **Confirm → Edit → Send**
- Step 1 (Confirm): shows To + Subject preview, "Preview & Edit Email" + "Skip" buttons
- Step 2 (Edit): editable To/Subject/Body, optional attachments (PDF/Excel/Word/CSV), "Send Award Notification" button
- On cancel: reverts Awarded status (X button or back)
- After send: green toast + `awardNotifiedMap` shows "Award notified Jun 12" under supplier row
- Shared template: `frontend/src/utils/awardEmailTemplate.js` + `backend/utils/awardEmailTemplate.js`

---

## 16. OVERVIEW TAB — DOCUMENT VIEWER

**Component:** `BidDocuments` section inside `frontend/src/components/BidDetail/OverviewTab.jsx`

**Displayed files:** `bid.uploadedFiles[]` array — populated at server startup by `backfillUploadedFiles()` from `bid.uploadedRfpPath` / `bid.uploadedItemListPath` fields

**File card actions:**
- **View** — opens file in browser tab via `GET /api/bids/:id/files/:filename` (`Content-Disposition: inline`)
- **Download** — triggers browser download (`Content-Disposition: attachment`)

**Upload drawer:** Slide-in panel from the right
- Drag-and-drop zone + file picker
- Doc type selector (RFP, Item List, Pricing, Spec Sheet, Compliance, Other)
- Notes textarea
- On upload: saves file to `backend/uploads/`, adds entry to `bid.uploadedFiles[]`, also adds to `documents.json` vault

---

## 17. DELETE BID — CASCADING DELETE

**Endpoint:** `DELETE /api/bids/:id`

Removes ALL data associated with the bid in a single call:

| Data store | Action |
|-----------|--------|
| `bids.json` | Remove bid record |
| `lineItems.json` | Remove all items where `bidId === deletedId` |
| `emailThreads.json` | Remove all emails where `bidId === deletedId` |
| `pricingData.json` | Remove all pricing where `bidId === deletedId` |
| `documents.json` | Remove all docs where `bidId === deletedId` |
| `backend/uploads/` | Delete files starting with `{bidId}_` or `{bidId}-` |

**Response body:**
```json
{
  "success": true,
  "deleted": "BID-XXX",
  "removed": { "lineItems": 33, "emails": 1, "pricing": 0, "documents": 4, "files": 2 }
}
```

**Frontend toast:** Shows detail after delete — e.g. `"Bid B2600042 deleted — 33 line items, 1 email, 4 documents removed"`. Empty bids show `"Bid BID-XXX deleted"` with no detail suffix.

**Toast paths:**
- Queue card (three-dot → Delete): `onDeleted(bidId, removed)` → `handleBidDeleted` sets `deleteToast` state
- BidDetail header (Delete button): `navigate('/', { state: { deleted: { bidId, removed } } })` → BidQueue reads `location.state` on mount and shows toast

---

## 18. RESPONSE RATE CALCULATION

All response rate display uses **dynamic helpers** from `frontend/src/utils/bidUtils.js`, not raw JSON fields:

```js
const RESPONDED_STATUSES = ['Responded', 'Issues Found', 'Follow-up Sent', 'Complete']

export const getSuppliersContacted = (bid) =>
  bid.solicitedSuppliers?.length ?? bid.suppliersContacted ?? 0

export const getResponsesReceived = (bid) =>
  bid.solicitedSuppliers
    ? bid.solicitedSuppliers.filter(s => RESPONDED_STATUSES.includes(s.status)).length
    : bid.responsesReceived ?? 0

export const getResponseRate = (bid) => {
  const contacted = getSuppliersContacted(bid)
  if (contacted === 0) return 0
  return Math.round((getResponsesReceived(bid) / contacted) * 100)
}
```

**Stat card — Supplier Response Rate:** Scoped to bids in `"Solicitation"` status only (excludes Active, Working File, etc.)

---

## 19. SUPPLIER SUBMISSION PORTAL

**Purpose:** Public-facing portal where suppliers submit pricing directly — no email required. Features full two-way messaging (GitHub Issues-style thread) between supplier and Sysco Bid COE.

### Access URLs
| URL | Description |
|-----|-------------|
| `http://localhost:5173/submit/:bidId` | Pricing submission form |
| `http://localhost:5173/submit/:bidId/thread/:threadId` | Conversation thread (email-gated) |

Sent to suppliers in the solicitation email body. Portal URL also shown as a copyable link in the Supplier List tab after solicitation.

### Frontend — SupplierPortal.jsx

**Three views in one component:**

**A) SubmissionForm** (`/submit/:bidId`) — pricing submission
- Bid info header, supplier details form, line items table with Unit/Case Price + No Bid checkbox
- File upload (drag-and-drop, PDF/XLSX), Notes textarea, Submit button
- On success: confirmation screen → "View & Continue Conversation" button → navigates to thread
- `lineItemPrices` serialized as JSON with `parseFloat()` prices so backend counts correctly

**B) ThreadView** (`/submit/:bidId/thread/:threadId`) — GitHub Issues-style conversation
- **Email gate first:** Lock icon card, "Verify your identity", email input → `GET /api/submit/:bidId/thread/:threadId?email=X`
- **Issue header:** "Pricing Submission — [supplierName]", `#confirmationId`, opened date, Responded badge, message count
- **Timeline:** linear thread of cards — submission event first, then messages
  - `SubmissionEventCard` — orange left border, expandable pricing details table (Item / Description / Unit $ / Case $ / Status)
  - `MessageCard` — white card for supplier (orange avatar), navy card header for COE; unread COE messages have blue-tinted background
  - `Avatar` — colored circle with initials (orange = supplier, navy = COE)
  - Timestamps: relative ("2h ago") with full date on hover via `title` attribute
  - Attachments: clickable download links with paperclip icon
- **Reply composer** — pinned at bottom, Enter to send, Shift+Enter for newline, file attach button
- **15-second polling** for new COE messages — compares `messageCount`; shows "New message" banner if scrolled up
- **New message banner** — navy bar at bottom, click to scroll down and dismiss

**C) SubmissionSuccess** — inline inside SubmissionForm on success

### Backend — submissions.js
Mounted at `/api/submit` (uses existing `/api` Vite proxy).

| Endpoint | Auth | Description |
|----------|------|-------------|
| `GET /api/submit/:bidId` | Public | Bid details + line items for form |
| `POST /api/submit/:bidId` | Public | Multipart form submission → saves to submissions.json + emailThreads.json + updates supplier status |
| `GET /api/submit/:bidId/submissions` | Public | Per-supplier summary for SuppliersTab portal status |
| `GET /api/submit/:bidId/thread/:threadId?email=X` | Email-verified | Returns `{ messages, messageCount, lastUpdated, lineItems, … }` — marks COE outbound msgs as `readBySupplier: true` |
| `POST /api/submit/:bidId/message` | Public (email-verified client-side) | Supplier follow-up message → appends to submissions.json + mirrors to emailThreads.json |
| `GET /api/submit/:bidId/status/:confirmationId` | Public | Submission receipt check |

**COE reply route** (in bids.js):
| Endpoint | Auth | Description |
|----------|------|-------------|
| `POST /api/bids/:bidId/portal-reply` | Internal | Appends outbound message to thread + mirrors to emailThreads.json + sends Nodemailer email to supplier |

**Nodemailer email to supplier (portal-reply):**
- Subject: `Re: Your pricing submission for [customerName]`
- Body: greeting + COE message + thread link
- Non-fatal: message is saved even if email send fails

**Pricing count fix:** `pricedCount = items.filter(li => !li.noBid && (parseFloat(li.unitPrice) > 0 || parseFloat(li.casePrice) > 0)).length`

### Data file — submissions.json
```json
{
  "B2600042": [{
    "confirmationId": "SUB-B2600042-XXXXXXXX",
    "threadId": "THREAD-B2600042-1780xxxxxx",
    "submittedAt": "2026-06-05T...",
    "supplierName": "Schwan's Food Service",
    "supplierEmail": "bids@schwans.com",
    "contactName": "Jane Smith",
    "lineItems": [{ "itemNo": "0001", "description": "...", "unitPrice": 5.25, "casePrice": 0, "noBid": false }],
    "pricingFile": "B2600042_Portal_1780xxxxxx.xlsx",
    "pricedCount": 10,
    "noBidCount": 2,
    "messages": [
      { "id": "uuid", "direction": "inbound", "from": "bids@schwans.com", "fromName": "Jane Smith", "body": "...", "attachments": [], "timestamp": "...", "readByBidCOE": false },
      { "id": "MSG-...", "direction": "outbound", "from": "COE.BIDS@sysco.com", "fromName": "Sysco Bid COE", "body": "...", "attachments": [], "timestamp": "...", "readBySupplier": false }
    ]
  }]
}
```

### EmailRepoTab.jsx — "Reply via Supplier Portal"
- Button label: "Reply via Portal" (shown for portal threads only)
- Modal title: "Reply via Supplier Portal"
- Notice: "🌐 This reply will appear in the supplier's portal thread AND be sent to their email"
- Calls `POST /api/bids/:bidId/portal-reply`

### SuppliersTab.jsx — portal indicators per supplier row
- `PortalUrlChip` — copyable portal URL shown above the solicited suppliers table
- Per-row portal status (fetched from `GET /api/submit/:bidId/submissions`):
  - If accessed: `🌐 X messages · Last active: [date]` (emerald)
  - If not accessed: `🌐 Portal not yet accessed` (grey)

---

## 20. COMMUNICATION MODEL — PORTAL FIRST

**Core principle:** Portal = primary two-way channel. Email = outbound notifications only.

| Channel | Use |
|---------|-----|
| 🌐 **Supplier Portal** | Primary: pricing submission, two-way thread messaging, status tracking |
| ✉ **Email (outbound)** | Solicitation, reminders, re-solicitation — all include portal URL as primary CTA |
| ✉ **Email (inbound)** | IMAP poller captures replies; but suppliers are directed to use portal |

### Solicitation email template (EmailComposer.jsx `buildBody`)
- Subject: `Pricing Request: [customer] — [bidId] | Due [date]`
- Body prominently features portal URL with `━━━` border around it
- Lists portal benefits (line-item entry, file upload, direct messaging, status tracking)
- No "reply to this email" as a submission method

### Email Repo tab — portal suppliers
- Portal suppliers: action bar shows **only "🌐 Reply via Portal"** (orange) + "View Portal Thread" link
- Email-only suppliers: keep original "Reply" + "Log Response" controls
- Inline reply button hidden for portal suppliers

### Supplier List tab — channel column + actions
- New **Channel** column: 🌐 Portal (emerald) or ✉ Email (grey)
- Portal suppliers: [View Thread] external link + [Mail icon → Email Repo]
- Email-only suppliers: [📪 Remind] opens pre-filled reminder modal + [Send → Resolicit] for No Bid/Awaiting

### Reminder modal (SuppliersTab.jsx `ReminderModal`)
- Opens for email-only suppliers
- Pre-filled subject: `Reminder: Pricing Request for [customer] — Response Due [date]`
- Body includes portal URL as `→ http://localhost:5173/submit/[bidId]`
- On send: tags `['reminder', 'portal-url']`, updates status to `Follow-up Sent`

### Resolicit modal (SuppliersTab.jsx `ResolicitModal`)
- Opens for suppliers with status No Bid / Awaiting / Bounced
- Tags `['resolicitation', 'portal-url']`

### Auto-reminder (OverviewTab + server.js scheduler)
Config stored on `bid.autoReminder`:
```json
{ "enabled": true, "daysAfterSolicitation": 3, "lastReminderSent": null }
```
- Toggled from Overview tab Status card
- `setInterval` in `server.js` runs `runAutoReminders()` every 60 minutes
- Targets: solicited suppliers with status `Awaiting`, no portal submission, no inbound email response
- Sends portal-URL reminder email via Nodemailer, logs to `emailThreads.json` tagged `['reminder','auto','portal-url']`
- Updates `lastReminderSent` and sets supplier status to `Follow-up Sent`
- Min gap: 3 days between auto-reminder runs per bid

### Overview tab — channel breakdown
`Supplier Response` card shows:
- Response rate %
- Contacted / Responded counts
- **By channel** breakdown: 🌐 X via Portal | ✉ X via Email
- Portal count fetched from `GET /api/submit/:bidId/submissions`

### New API endpoint
`PATCH /api/bids/:bidId/auto-reminder` — saves `{ enabled, daysAfterSolicitation }` to `bids.json`

---

## 20b. KNOWN FIXES & IMPORTANT IMPLEMENTATION NOTES

| Issue | Fix |
|-------|-----|
| AI response JSON parse failures | All three AI routes (`rfpParser.js`, `analyseResponse.js`, `pricing.js`) use `extractJSON(rawText)` — tries direct parse first, strips markdown fences on failure |
| AI response truncation on large RFPs | `max_tokens: 8000` on rfpParser and analyseResponse; `max_tokens: 8192` on pricing |
| AI returns trailing text after JSON | System prompt ends with `"CRITICAL: Start your response with { and end with }."` |
| Response rate inflated by raw fields | Calculated from `solicitedSuppliers` array (see Section 18) |
| Backfill adding wrong suppliers | `backfillSolicitedSuppliers()` only adds suppliers whose email appeared in actual BCC; auto-populate fallback was removed |
| Frontend showing stale bid data | Frontend uses `staticBids.find()` first — always `cp backend/data/bids.json frontend/src/data/bids.json` after data changes |
| IMAP poller race condition | Stop backend before bulk data edits to prevent 15s poller overwriting manual changes |
| Solicitation subtitle grammar | `{count} supplier{count !== 1 ? 's' : ''}` |

---

## 20. HOW TO START THE APP

**Terminal 1 — Backend:**
```bash
cd sysco-bid-poc/backend
npm start
# Should show:
# Anthropic API: ✅ Configured
# Email SMTP:    ✅ Ready (sysco.bid.poc@gmail.com)
# IMAP Poller:   ✅ Started (polling every 15s)
```

**Terminal 2 — Frontend:**
```bash
cd sysco-bid-poc/frontend
npm run dev
# Opens on http://localhost:5173
```

**If port 3001 is already in use:**
```bash
kill $(lsof -ti :3001) && npm start
```

**Manual IMAP poll (dev testing):**
```bash
curl http://localhost:3001/api/email/poll-now
```

**Sync frontend data after backend changes:**
```bash
cp backend/data/bids.json frontend/src/data/bids.json
```

**Important — dotenv fix:** Shell environment may have `ANTHROPIC_API_KEY=""` (empty string). `server.js` uses `dotenvConfig({ override: true })` to force-load from `backend/.env`. The `.env` file must be in the `backend/` directory, not the project root.

---

## 21. WHAT IS NOT BUILT YET (Phase 2)

- Outlook / Microsoft Graph connector (currently Gmail SMTP + IMAP)
- Salesforce import integration
- SUPC matching to Sysco item master
- RevMan / SMT handoff workflow
- Post-award supplier notification
- SOX supplier acknowledgement flow
- Bounce-back detection on outbound emails
- User authentication / login
- PostgreSQL database (currently JSON flat files)

---

## 22. PROJECT FOLDER STRUCTURE

```
sysco-bid-poc/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── BidQueue/          # Homepage — bid dashboard
│   │   │   │   ├── index.jsx      # BidQueue page + DeleteToast
│   │   │   │   └── BidCard.jsx    # Individual bid card + three-dot menu
│   │   │   ├── BidDetail/         # 4-tab bid detail view
│   │   │   │   ├── index.jsx      # BidDetail shell + tab router + delete
│   │   │   │   ├── OverviewTab.jsx       # Bid info + BidDocuments section
│   │   │   │   ├── EmailRepoTab.jsx      # Supplier-grouped email threads
│   │   │   │   ├── WorkingFileTab.jsx    # Two-side RFP + pricing grid
│   │   │   │   ├── SuppliersTab.jsx      # Solicited list + add supplier
│   │   │   │   └── EmailComposer.jsx     # BCC email draft + send
│   │   │   ├── BexAI/             # RFP parser (OP2)
│   │   │   │   └── index.jsx
│   │   │   ├── DocumentVault/     # Document vault (OP6) + Ask RFP AIQ button
│   │   │   └── RfpAiq/            # RFP AIQ conversational intelligence
│   │   │       ├── RfpAiqDrawer.jsx         # Slide-in chat drawer
│   │   │       └── RfpAiqMessageBubble.jsx  # User/assistant bubbles + action pills
│   │   ├── pages/
│   │   │   └── SupplierPortal.jsx # Public supplier pricing portal (/submit/:bidId)
│   │   ├── data/                  # Mirror of backend/data/ — keep in sync
│   │   ├── utils/
│   │   │   └── bidUtils.js        # Shared helpers + config + response rate
│   │   └── App.jsx
├── backend/
│   ├── routes/
│   │   ├── bids.js                # Bids CRUD + cascading delete + file serve
│   │   ├── submissions.js         # Public supplier portal API (/api/submit/*)
│   │   ├── suppliers.js           # Supplier list + auto-populate + add new
│   │   ├── rfpParser.js           # BEX AI endpoint + buildLineItem()
│   │   ├── pricing.js             # AI pricing extraction
│   │   ├── emails.js              # Email CRUD + analyse-response
│   │   └── ai.js                  # RFP AIQ — POST /api/ai/chat
│   ├── services/
│   │   ├── emailService.js        # Nodemailer Gmail SMTP sender
│   │   └── emailPoller.js         # IMAP inbox poller (ImapFlow, 15s interval)
│   ├── data/                      # Source of truth JSON files
│   ├── uploads/                   # Uploaded RFP and supplier files
│   ├── .env                       # All secrets (Anthropic + Gmail SMTP + IMAP)
│   └── server.js                  # Express app + backfill + poller startup
├── CLAUDE.md                      # ← This file
└── README.md
```

---

## 23. RFP AIQ — CONVERSATIONAL INTELLIGENCE

**Product name:** RFP AIQ (use this name everywhere — button labels, drawer header, avatar, toasts, comments)

**Entry point:** Document Vault page → "Ask RFP AIQ" button (top-right, EXL orange, BrainCircuit icon)

### Frontend components
| Component | Path | Purpose |
|-----------|------|---------|
| `RfpAiqDrawer` | `frontend/src/components/RfpAiq/RfpAiqDrawer.jsx` | 420px slide-in drawer, full chat UI |
| `RfpAiqMessageBubble` | `frontend/src/components/RfpAiq/RfpAiqMessageBubble.jsx` | User/assistant bubbles + action pills |

**State in DocumentVault:** `aiqOpen`, `aiqMessages`, `setAiqMessages` — passed as props to `RfpAiqDrawer`. Chat history resets each time drawer is opened.

**Drawer features:**
- Navy header with BrainCircuit icon (orange) + X close
- Scrollable chat area with auto-scroll to bottom
- 4 starter prompt chips (2×2 grid) shown when chat is empty; disappear after first send
- Typing indicator: animated navy 3-dot bounce while awaiting response
- Input textarea (auto-grows to 120px) + orange Send button
- Keyboard: Enter to send, Shift+Enter for newline

**Message bubbles:**
- User: right-aligned, EXL orange background, white text, `rounded-2xl rounded-tr-sm`
- RFP AIQ: left-aligned, white card `border border-gray-200 rounded-2xl rounded-tl-sm`, navy "AIQ" avatar circle (orange text)

**Action pills:** Lines starting with `"Suggested action:"` are stripped from assistant response body and rendered as orange-outlined pill buttons. Clicking copies text to clipboard and shows 2s tooltip.

### Backend route
**File:** `backend/routes/ai.js`  
**Endpoint:** `POST /api/ai/chat`  
**Request:** `{ messages: [{ role: 'user'|'assistant', content: string }] }`  
**Response:** `{ role: 'assistant', content: string }`

**Context assembled from `backend/data/` on every request:**
1. `bids.json` — all bids with status, dates, compliance, solicitedSuppliers (name/email/status)
2. `lineItems.json` — item categories and count per bid
3. `emailThreads.json` — last 3 emails per bid (direction, subject, 300-char snippet, tags)
4. `documents.json` + `bid.uploadedFiles` — document list per bid
5. `backend/uploads/` — list of files on disk (non-temp)

**System prompt identity:** `"You are RFP AIQ, the Sysco Bid Intelligence Assistant built by EXL Service for the Sysco Bid COE team led by Tricia Johnson."`

**AI config:** `claude-sonnet-4-20250514`, `max_tokens: 1024`

---

---

## 24. RECENT CHANGES — June 12–14, 2026

### AWARD WORKFLOW
- Mark Awarded in Email Repo → two-step modal (Confirm → Edit → Send award notification email)
- Award status syncs to `lineItems.supplierPricing` — shows in Working File BID COE INTERNAL section automatically
- Bulk award notifications from Supplier List tab: **"Send Award Notifications (X)"** button (appears when `awardedSuppliers.length > 0`)
- Shared email template:
  - `frontend/src/utils/awardEmailTemplate.js`
  - `backend/utils/awardEmailTemplate.js`

### PORTAL TEMPLATE FEATURE
- Search `PORTAL-TEMPLATE` to find all code blocks
- Template config panel slides in from right in Supplier List tab
- 4 predefined templates: `k12-standard`, `healthcare`, `government`, `quick-quote`
- Templates stored in: `backend/data/portalTemplates.json`
- Bid config saved as `bid.portalConfig: { templateId, appliedAt, customFields[] }`
- Custom fields render in: Supplier Portal form (below standard fields) + Working File (extra blue columns)
- Custom field types: `text`, `number`, `yes_no`
- Demo: B2600042 has `k12-standard` applied with 4 fields: Halal, WG Compliant, CN Label#, Country of Origin
- Backend routes (wrapped in PORTAL-TEMPLATE markers): `GET /api/portal-templates`, `PATCH /api/bids/:bidId/portal-config`

### SUPPLIER PORTAL REDESIGN
- Matches RFP AIQ platform design language
- Dark mode toggle in portal header (saved as `portal_theme` in localStorage)
- Step indicator: Details → Pricing → Submit
- Pricing fields per line item: FOB, Delivered★, Allowance, PTV, Dev Type, No Bid, Notes + custom fields from `bid.portalConfig`
- Sticky submit bar at bottom; success screen with confirmation ID

### BOUNCE EMAIL DEMO (B2600042)
- General Mills Foodservice added as demo bounce supplier
- Email: `bids@demo-generalmills.test` | Status: `Issues Found` | Bounce: `550 5.1.1 User does not exist`
- Emails in `emailThreads.json`:
  - `EMAIL-GM-OUT-001` — outbound solicitation
  - `EMAIL-GM-BOUNCE-001` — inbound bounce from mailer-daemon (`isBounce: true`)
- Shows in Email Repo → ⚠ Issues filter
- Red banner in thread + "Update Email Address" inline form + "Update & Re-solicit" flow

### EMAIL CLEANUP
- All real supplier emails replaced with `@demo-*.test` addresses (RFC 2606 — non-deliverable)
- Script: `backend/scripts/cleanupSupplierEmails.js`
- Protected emails (never replaced):
  `tauseefahmad12@gmail.com`, `tricia.johnson@sysco.com`, `manish.gupta@sysco.com`,
  `Jeanette.Rangel@sysco.com`, `Anthony.Spencer@sysco.com`, `tauseef.ahmad@exlservice.com`,
  `bids@freshmeadowsproduce.com`, `COE.BIDS@sysco.com`, `sysco.bid.poc@gmail.com`

### DESIGN SYSTEM (3 passes)
- **Pass 1:** Color tokens + `Button` component (`frontend/src/components/UI/Button.jsx`) + `Badge` component (`frontend/src/components/UI/Badge.jsx`)
- **Pass 2:** Empty states with CTAs (`frontend/src/components/UI/EmptyState.jsx`)
- **Pass 3:** Sticky headers, frozen columns, row hover states, stat card borders
- **Dark mode:** Class-based Tailwind, toggle in top navbar (Sun/Moon icon)
  - `ThemeContext`: `frontend/src/context/ThemeContext.jsx`
  - Persists in `localStorage` as `'theme'`

### TAB TRANSITIONS
- **Light tabs** (Overview, Email Repo): `tabFadeIn` — opacity + `translateY(4px)`
- **Heavy tabs** (Working File, Supplier List): `tabFadeOnly` — opacity only (no Y movement); prevents layout reflow on large tables

### WORKING FILE — 3 SECTIONS
- **CUSTOMER RFP** (white) — fixed, read-only
- **SUPPLIER RESPONSES** (blue `#EBF3FB`) — inline editable, populated from Extract Pricing
- **BID COE INTERNAL** (yellow `#FEFCE8`) — Tricia's team columns: Award Decision, Internal Notes, Pricing Score, Follow-up Required
- Custom columns from `portalConfig` appear after standard supplier columns (filtered by `showInWorkingFile: true`)
- **Customize Columns** panel (⚙ button)
- All supplier fields blank by default — only populate from Extract Pricing

### UPLOAD RFP PAGE
- Fixed 160px upload zone height — no layout shift on file upload
- Exit warning using `useBlocker` (React Router)
- Requires `createBrowserRouter` in `main.jsx` (migrated from `BrowserRouter` for `useBlocker`)

### LOGIN
- **Component:** `frontend/src/pages/Login.jsx`
- EXL logo at bottom of card: `/public/exl_logo.png`
- Credentials:
  - `tricia.johnson@sysco.com` / `SyscoBidCOE2026`
  - `jeanette.rangel@sysco.com` / `SyscoBidCOE2026`
  - `devin.dick@sysco.com` / `SyscoBidCOE2026`

### SIDEBAR
- EXL logo: `/public/exl_logo_sidebar.png` (navy background version)
- Collapsible with ChevronLeft/Right toggle
- State persists in `localStorage` as `'sidebar_collapsed'`
- Collapsed: 64px (icons only) | Expanded: 220px

### LAKEVIEW USD (B2600042) KEY DATES
- Response Due: July 15, 2026 | Bid Start: August 1, 2026 | Bid End: July 31, 2027

### AT-RISK DEMO BIDS (as of June 14, 2026)
| Bid | Customer | internalDue | Status |
|-----|----------|-------------|--------|
| BID-601 | Darden Restaurants — Olive Garden | 2026-06-05 | 9 days overdue |
| BID-402 | University of Colorado — Dining Services | 2026-06-10 | 4 days overdue |
| BID-701 | Marriott Mountain Resorts | 2026-06-18 | 4 days left |
| B2600042 | Lakeview Unified School District | 2026-06-15 | 1 day left |

### KEY FILES ADDED/CHANGED
**New:**
- `frontend/src/utils/awardEmailTemplate.js`
- `frontend/src/context/ThemeContext.jsx`
- `frontend/src/components/UI/Button.jsx`
- `frontend/src/components/UI/Badge.jsx`
- `frontend/src/components/UI/EmptyState.jsx`
- `backend/utils/awardEmailTemplate.js`
- `backend/data/portalTemplates.json`
- `backend/scripts/cleanupSupplierEmails.js`
- `backend/scripts/simulateBounce.js`

**Modified:**
- `frontend/src/main.jsx` — `createBrowserRouter` migration
- `frontend/src/App.jsx` — `ProtectedRoute`, `ThemeProvider`
- `frontend/src/pages/Login.jsx`
- `frontend/src/pages/SupplierPortal.jsx` — full redesign + custom fields
- `frontend/src/components/Layout/Sidebar.jsx` — collapsible + EXL logo
- `frontend/src/components/BidDetail/EmailRepoTab.jsx` — bounce UI, award modal
- `frontend/src/components/BidDetail/WorkingFileTab.jsx` — 3-section layout, custom columns
- `frontend/src/components/BidDetail/SuppliersTab.jsx` — read-only status, portal template panel
- `frontend/src/components/BidDetail/OverviewTab.jsx`
- `frontend/src/components/BidDetail/PricingExtractModal.jsx`
- `backend/routes/bids.js` — portal template routes, award email route, Issues Found override
- `backend/data/bids.json` — B2600042 portalConfig, General Mills bounce entry, at-risk dates
- `backend/data/suppliers.json` — demo email addresses
- `backend/data/emailThreads.json` — bounce emails, demo email cleanup

---

*Document maintained by EXL Service | Sysco BID/RFP POC Team | June 2026 | Confidential*
