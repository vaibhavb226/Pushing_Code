# Sysco BID/RFP Platform — POC

> **EXL Service | Sysco Corporation | May 2026 | CONFIDENTIAL**
> AI-powered procurement platform for Sysco's Merchandising BID Assortment team (Bid COE).

---

## Quick Start

### Prerequisites
- Node.js 18+
- npm 9+
- Anthropic API key (get one at [console.anthropic.com](https://console.anthropic.com))

### 1 — Clone & configure

```bash
git clone https://github.com/exlservice/sysco-bid-poc.git
cd sysco-bid-poc
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

### 2 — Install dependencies

```bash
# Backend
cd backend && npm install

# Frontend (in a new terminal)
cd frontend && npm install
```

### 3 — Run

```bash
# Terminal 1 — Backend (port 3001)
cd backend && npm run dev

# Terminal 2 — Frontend (port 5173)
cd frontend && npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## Project Structure

```
sysco-bid-poc/
├── frontend/                    # React 18 + Tailwind CSS + Vite
│   ├── src/
│   │   ├── components/
│   │   │   ├── BidQueue/        # Session 2 — Dashboard + segment filter
│   │   │   ├── BidDetail/       # Session 2 — 4-tab bid detail view
│   │   │   ├── SupplierList/    # Session 3 — OP3A + OP3B auto-populate
│   │   │   ├── WorkingFile/     # Session 4 — OP7 + OP8 two-step import
│   │   │   ├── EmailRepo/       # Session 5 — OP5 email thread
│   │   │   ├── DocumentVault/   # Session 5 — OP6 document repository
│   │   │   └── BexAI/           # Session 3 — OP2 RFP parser
│   │   ├── data/                # Dummy JSON files (see below)
│   │   ├── hooks/               # Custom React hooks
│   │   ├── utils/               # Helpers (CSV export, formatting, etc.)
│   │   ├── App.jsx              # Routing + sidebar layout
│   │   ├── main.jsx
│   │   └── index.css            # Tailwind + custom classes
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── package.json
│
├── backend/                     # Node.js + Express
│   ├── routes/
│   │   ├── bids.js              # GET /api/bids, GET /api/bids/:id
│   │   ├── suppliers.js         # GET /api/suppliers, POST /api/suppliers/auto-populate
│   │   ├── rfpParser.js         # POST /api/parse-rfp (BEX AI — OP2)
│   │   ├── pricing.js           # POST /api/extract-pricing (OP7)
│   │   ├── emails.js            # GET /api/emails, POST /api/emails/log
│   │   └── documents.js         # GET /api/documents
│   ├── data/                    # Same 6 JSON files as frontend/src/data/
│   ├── uploads/                 # Temp upload dir (gitignored)
│   ├── server.js
│   └── package.json
│
├── .env.example                 # Environment variable template
├── .gitignore
└── README.md
```

---

## Dummy Data Files

All data is fictional and based on the real structure of Sysco's CPS BID B2500019 (Cincinnati Public Schools SY 2026-27). **No real client data is stored.**

| File | Records | Description |
|------|---------|-------------|
| `bids.json` | 15 bids | K-12, DoD, University, Healthcare, Restaurant, Lodging, Government. Primary demo: **BID-106** (Arapahoe Charter School) |
| `suppliers.json` | 20 suppliers | Acxion, Mars Ben's, Super Bakery, General Mills, Dole, J&J Snack, Pepsico, Campbell, NFG, Midamar, Michael Foods, Kikkoman, Affinity Sales, Lake & Cincinnati, DDReckner, CORE, Tyson, Heartland (bounced), Land O Lakes, SW Paper |
| `lineItems.json` | 28 items | CPS SY 2025-26 Assorted Foods list — Fluid Milk, Fruit, Grain, Snack, M/MA, M/MA+Grain. All compliance flags included. |
| `emailThreads.json` | 6 emails | E1 solicitation outbound → E2 Acxion/Mars Ben's response → E3 Super Bakery response → E4 General Mills → E5 Midamar re-solicit → E6 Midamar confirmation |
| `pricingData.json` | 12 records | Acxion Quote #27037, Super Bakery #OH-2026-06991, plus Dole, Midamar, General Mills, NFG, J&J pricing with ALLW/DL deviations and confidence scores |
| `documents.json` | 10 docs | RFPs, supplier quotes, compliance certs, spec sheets. Organised by supplier category. |

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check — confirms Anthropic key is set |
| GET | `/api/bids` | All bids (filter: `?segment=K-12&status=Solicitation`) |
| GET | `/api/bids/:id` | Single bid by ID |
| GET | `/api/suppliers` | All suppliers (filter: `?category=Protein&segment=K-12`) |
| POST | `/api/suppliers/auto-populate` | OP3A — Match suppliers to bid item categories |
| POST | `/api/parse-rfp` | OP2 — BEX AI: parse uploaded RFP (or `?demo=true`) |
| POST | `/api/extract-pricing` | OP7 — AI pricing extraction (or `?demo=true`) |
| GET | `/api/emails` | All emails (filter: `?bidId=BID-106`) |
| POST | `/api/emails/log` | Log a sent solicitation email |
| GET | `/api/documents` | All documents (filter: `?bidId=&supplier=&category=`) |

---

## Email Setup (Gmail SMTP)

Solicitation emails are sent via Gmail SMTP using Nodemailer. Follow these steps to configure a sending address:

### 1 — Create a dedicated Gmail account

Create a Gmail account specifically for the POC (e.g. `sysco.bid.poc@gmail.com`). Do **not** use a personal or corporate Gmail account.

### 2 — Enable 2-Step Verification

1. Sign in to the Gmail account
2. Go to **Google Account → Security**
3. Under "How you sign in to Google", enable **2-Step Verification**

### 3 — Generate an App Password

1. Go to **Google Account → Security → 2-Step Verification**
2. Scroll to the bottom → click **App passwords**
3. Select app: **Mail** | Select device: **Other (custom name)** → type `Sysco BID POC`
4. Click **Generate** — copy the 16-character password (shown once)

### 4 — Add to `backend/.env`

```env
EMAIL_FROM=sysco.bid.poc@gmail.com
EMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx   # 16-char App Password (spaces OK)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
```

### 5 — Verify at startup

When the backend starts, you should see:
```
📧 Email SMTP: ✅ Connected — sysco.bid.poc@gmail.com
```

If you see `⚠️ Not configured`, double-check the App Password — it must be a Google App Password, **not** your regular Gmail password.

### Notes
- Gmail SMTP uses **STARTTLS** on port 587 (not SSL on 465)
- All supplier emails go to **BCC** — recipients cannot see each other
- The `To:` field is set to the sender address (Gmail requires a To)
- In the POC, attachment filenames are listed in the email body; real file attachments are Phase 2
- Gmail free accounts allow ~500 emails/day; upgrade to Google Workspace for production use

---

## Anthropic System Prompts

### BEX AI — RFP Parser (OP2)
Extracts bid metadata + all line items from uploaded RFP documents. Returns structured JSON with compliance flags, supplier targeting recommendations, and parsing confidence score.

### AI Pricing Extraction (OP7 + OP8)
Matches supplier pricing documents to RFP line items using SUPC exact match + description fuzzy match + attribute matching. Returns confidence scores (≥90% green, 75-89% amber, <75% red + manual review).

### Q&A Response Drafter
Drafts professional responses to supplier questions about bid requirements (Buy American Act Section 4.2, CN labels, PFS documentation).

---

## Development Sessions

| Session | Status | Focus |
|---------|--------|-------|
| **Session 1** | ✅ Complete | Project setup + all 6 dummy data files |
| **Session 2** | 🔜 Next | Bid Queue dashboard + segment filter + BidDetail tabs |
| **Session 3** | Pending | Supplier List auto-populate + BEX AI tab |
| **Session 4** | Pending | Working File two-step import + pricing extraction |
| **Session 5** | Pending | Email Repo + Document Vault + deploy to Vercel |

---

## Brand Colors

| Color | Hex | Usage |
|-------|-----|-------|
| EXL Orange | `#E05A2B` | Primary buttons, titles, accents |
| EXL Navy | `#1F3864` | Sidebar, headers |

---

## Key Terminology

| Term | Definition |
|------|-----------|
| ALLW | Allowance — off-invoice discount from manufacturer |
| DL | Delivered Cost — manufacturer guarantees delivered price |
| BEX | Bid Extraction System — replaced by this AI tool |
| Bid COE | Center of Excellence — Tricia Johnson's team |
| CN | Child Nutrition — USDA cert required for K-12 |
| PFS | Product Formulation Statement — proves CN compliance |
| SOX | Sarbanes-Oxley — drives supplier acknowledgement requirement |
| OpCo | Operating Company — Sysco regional distribution center |
| SUPC | Sysco Universal Product Code |

---

*Document prepared by EXL Service | Sysco BID/RFP POC Team | May 2026 | CONFIDENTIAL*
