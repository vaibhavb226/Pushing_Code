// ============================================================
// ai.js — RFP AIQ: conversational intelligence route
// POST /api/ai/chat
// Assembles full platform context and calls Anthropic API
// ============================================================

import express from 'express'
import Anthropic from '@anthropic-ai/sdk'
import { readFileSync, existsSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import pdfParse from 'pdf-parse'
import * as XLSX from 'xlsx'

const __dirname  = dirname(fileURLToPath(import.meta.url))
const router     = express.Router()
const DATA       = join(__dirname, '../data')
const UPLOADS_DIR = join(__dirname, '../uploads')

// ── Extract text from uploaded PDF or Excel ───────────────
async function extractDocumentText(filename) {
  const filePath = join(UPLOADS_DIR, filename)
  if (!existsSync(filePath)) return null
  try {
    if (/\.pdf$/i.test(filename)) {
      const buffer = readFileSync(filePath)
      const data = await pdfParse(buffer)
      return data.text.substring(0, 3000)
    }
    if (/\.xlsx?$/i.test(filename)) {
      const wb = (XLSX.default ?? XLSX).readFile(filePath)
      const sheet = wb.Sheets[wb.SheetNames[0]]
      const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' })
      return rows
        .filter(r => r.some(c => c !== ''))
        .map(r => r.join('\t'))
        .join('\n')
        .substring(0, 3000)
    }
  } catch (err) {
    console.error('[AIQ] Doc read error:', filename, err.message)
  }
  return null
}

// ── Safe JSON loader ──────────────────────────────────────
const loadJ = (file) => {
  try { return JSON.parse(readFileSync(join(DATA, file), 'utf8')) }
  catch { return [] }
}

// ── Context assembly ──────────────────────────────────────
async function buildSystemPrompt() {
  const bids      = loadJ('bids.json')
  const emails    = loadJ('emailThreads.json')
  const lineItems = loadJ('lineItems.json')
  const docs      = loadJ('documents.json')

  // ── BIDS SUMMARY ──
  let bidsSummary = ''
  bids.forEach(bid => {
    const bidLineItems = lineItems.filter(li => li.bidId === bid.id)
    const itemCount    = bidLineItems.length || bid.items || 0
    const categories   = [...new Set(bidLineItems.map(li => li.category).filter(Boolean))].join(', ')
                         || bid.itemCategories?.join(', ') || 'N/A'
    const compliance   = bid.compliance?.join(', ') || 'None'

    bidsSummary +=
      `Bid ${bid.id} — ${bid.customer}\n` +
      `  Segment: ${bid.segment} | OpCo: ${bid.opco} ${bid.opcoName} | Region: ${bid.region}\n` +
      `  Status: ${bid.status} | Items: ${itemCount} | Compliance: ${compliance}\n` +
      `  Customer Due: ${bid.customerDue || 'N/A'} | Internal Due: ${bid.internalDue || 'N/A'}\n` +
      `  Categories: ${categories}\n`
    if (bid.notes) bidsSummary += `  Notes: ${bid.notes}\n`
    bidsSummary += '\n'
  })

  // ── SUPPLIER ACTIVITY ──
  let supplierActivity = ''
  bids.forEach(bid => {
    const solicited  = bid.solicitedSuppliers ?? []
    const solCount   = solicited.length || bid.suppliersContacted || 0
    const RESPONDED  = ['Responded', 'Issues Found', 'Follow-up Sent', 'Complete']
    const respCount  = solicited.filter(s => RESPONDED.includes(s.status)).length
                       || bid.responsesReceived || 0

    if (solicited.length > 0) {
      supplierActivity += `Bid ${bid.id} (${bid.customer}): ${solCount} solicited, ${respCount} responded\n`
      solicited.forEach(s => {
        supplierActivity +=
          `  • ${s.supplierName} <${s.email}> — ${s.status || 'Awaiting'}` +
          `, last activity: ${s.lastActivity || 'N/A'}\n`
      })
    } else {
      supplierActivity += `Bid ${bid.id} (${bid.customer}): Not yet solicited\n`
    }
    supplierActivity += '\n'
  })

  // ── DOCUMENT VAULT ──
  let docVault = ''
  bids.forEach(bid => {
    const vaultDocs    = docs.filter(d => d.bidId === bid.id)
    const uploadedFiles = bid.uploadedFiles || []

    const allDocNames = [
      ...vaultDocs.map(d => `${d.fileName} (${d.documentType})`),
      ...uploadedFiles.map(f => `${f.originalName || f.name || f.filename || 'file'} (${f.docType || f.type || 'Document'})`),
    ]

    docVault += allDocNames.length > 0
      ? `Bid ${bid.id} (${bid.customer}): ${allDocNames.join(', ')}\n`
      : `Bid ${bid.id} (${bid.customer}): No documents uploaded\n`
  })

  // Shared docs (bidId === 'ALL')
  const sharedDocs = docs.filter(d => d.bidId === 'ALL')
  if (sharedDocs.length > 0) {
    docVault += `\nShared/Global documents: ${sharedDocs.map(d => d.fileName).join(', ')}\n`
  }

  // Uploaded files on disk (non-temp)
  if (existsSync(UPLOADS_DIR)) {
    const diskFiles = readdirSync(UPLOADS_DIR).filter(f => !f.startsWith('temp_'))
    if (diskFiles.length > 0) {
      docVault += `\nFiles in uploads/: ${diskFiles.join(', ')}\n`
    }
  }

  // ── RECENT EMAIL ACTIVITY ──
  let emailActivity = ''
  bids.forEach(bid => {
    const bidEmails = emails
      .filter(e => e.bidId === bid.id)
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, 3)

    if (bidEmails.length > 0) {
      emailActivity += `Bid ${bid.id} (${bid.customer}):\n`
      bidEmails.forEach(e => {
        const snippet = (e.body || '').slice(0, 300).replace(/\n+/g, ' ')
        const senderLabel = e.direction === 'inbound'
          ? (e.supplierName || e.from || 'Supplier')
          : 'COE.BIDS'
        emailActivity +=
          `  [${e.direction.toUpperCase()}] ${(e.date || '').slice(0, 10)} — ` +
          `"${e.subject}" | ${senderLabel} | Tags: ${(e.tags || []).join(', ')}\n`
        if (snippet) emailActivity += `  "${snippet}"\n`
      })
      emailActivity += '\n'
    }
  })

  // ── DOCUMENT VAULT CONTENTS ──
  let docContentsSection = ''
  if (existsSync(UPLOADS_DIR)) {
    const uploadedFiles = readdirSync(UPLOADS_DIR)
      .filter(f => !f.startsWith('temp_') && /\.(pdf|xlsx?)$/i.test(f))
      .slice(0, 10)

    const docContents = []
    for (const filename of uploadedFiles) {
      const text = await extractDocumentText(filename)
      if (text) {
        const bidDoc = bids.find(b =>
          b.uploadedFiles?.some(f => f.filename === filename || f.savedName === filename)
        )
        const bidRef = bidDoc ? `${bidDoc.id} — ${bidDoc.customer}` : 'General'
        docContents.push(`[DOCUMENT: ${filename} | Bid: ${bidRef}]\n${text}`)
      }
    }

    if (docContents.length > 0) {
      docContentsSection = `[DOCUMENT VAULT CONTENTS]
The following documents have been uploaded and their content is available for analysis:

${docContents.join('\n\n---\n\n')}

When asked about documents, pricing files, RFPs, or specific item prices, reference the actual document content above.`
    }
  }

  let systemPrompt = `You are RFP AIQ, the Sysco Bid Intelligence Assistant built by EXL Service for the Sysco Bid COE team led by Tricia Johnson. You have deep knowledge of all active bids, supplier activity, documents, and email history in the Sysco RFP AIQ platform.

[BIDS SUMMARY]
${bidsSummary.trim() || 'No bids available.'}

[SUPPLIER ACTIVITY]
${supplierActivity.trim() || 'No supplier activity recorded.'}

[DOCUMENT VAULT]
${docVault.trim() || 'No documents in vault.'}

[RECENT EMAIL ACTIVITY]
${emailActivity.trim() || 'No email activity recorded.'}

${docContentsSection}

Answer questions accurately based only on the above data. Be concise and professional. If information is not available in the data, say so clearly — do not guess.

When relevant, end your response with 1-2 specific suggested actions the user can take in the platform, prefixed exactly with 'Suggested action:' on their own lines.`

  // ── Lakeview historical bid context ──────────────────────
  try {
    const candidate = join(DATA, 'Lakeview_USD_MultiYear_B2600042_2022-2026.xlsx')
    if (existsSync(candidate)) {
      const wb         = XLSX.read(readFileSync(candidate), { type: 'buffer' })
      const itemSheets = wb.SheetNames.filter(n => n.startsWith('Item List'))

      let historicalContext = '\n\n=== LAKEVIEW USD HISTORICAL BID DATA (2022–2026) ===\n'
      historicalContext += 'Source: Document Vault — Lakeview_USD_MultiYear_B2600042_2022-2026.xlsx\n\n'

      const allYears = []

      for (const sheetName of itemSheets) {
        const bidIdMatch = sheetName.match(/B(\d{2})/)
        const year       = bidIdMatch ? 2000 + parseInt(bidIdMatch[1]) : '?'
        const bidId      = sheetName.replace('Item List ', '')

        const ws      = wb.Sheets[sheetName]
        const rows    = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' })
        // Row 0-1: title rows, row 2: blank, row 3: headers, row 4+: data
        const dataRows = rows.slice(4).filter(r => r[0] && String(r[0]).trim() !== '')

        const items = dataRows.map(r => ({
          lineNo:      r[0],
          category:    r[1],
          description: r[3],
          brand:       r[4],
          packSize:    r[8],
          unit:        r[9],
          estQty:      Number(r[10]) || 0,
          compliance:  r[12],
        }))

        allYears.push({ year, bidId, items })

        // Group by category for compact output
        const byCategory = {}
        for (const item of items) {
          const cat = item.category || 'Other'
          if (!byCategory[cat]) byCategory[cat] = []
          byCategory[cat].push(`${item.description} [${item.estQty} ${item.unit}]`)
        }

        historicalContext += `--- ${year} Bid (${bidId}) — ${items.length} items ---\n`
        for (const [cat, descs] of Object.entries(byCategory)) {
          historicalContext += `${cat}: ${descs.join(', ')}\n`
        }
        historicalContext += '\n'
      }

      // Year-over-year diff (first vs last year)
      if (allYears.length >= 2) {
        const first      = allYears[0]
        const last       = allYears[allYears.length - 1]
        const firstDescs = new Set(first.items.map(i => i.description.toLowerCase().trim()))
        const lastDescs  = new Set(last.items.map(i => i.description.toLowerCase().trim()))

        const added   = last.items.filter(i => !firstDescs.has(i.description.toLowerCase().trim()))
        const dropped = first.items.filter(i => !lastDescs.has(i.description.toLowerCase().trim()))

        historicalContext += `--- Changes from ${first.year} to ${last.year} ---\n`
        if (added.length)   historicalContext += `Items ADDED: ${added.map(i => i.description).join('; ')}\n`
        if (dropped.length) historicalContext += `Items REMOVED: ${dropped.map(i => i.description).join('; ')}\n`
        if (!added.length && !dropped.length) historicalContext += 'No items were added or removed.\n'
        historicalContext += '\n'
      }

      historicalContext += '=== END HISTORICAL BID DATA ===\n'
      systemPrompt += historicalContext
      console.log(`[RFP AIQ] Loaded historical Lakeview data: ${allYears.length} year(s)`)
    }
  } catch (e) {
    console.warn('[RFP AIQ] Historical bid context skipped:', e.message)
  }

  return systemPrompt
}

// ── POST /api/ai/chat ─────────────────────────────────────
router.post('/chat', async (req, res) => {
  try {
    const { messages } = req.body
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages array is required' })
    }

    const systemPrompt = await buildSystemPrompt()
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

    const response = await client.messages.create({
      model:      process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
      system:     systemPrompt,
      messages:   messages.map(m => ({ role: m.role, content: String(m.content) })),
      max_tokens: 1024,
    })

    const content = response.content[0]?.text ?? ''
    console.log(`[RFP AIQ] Responded to: "${messages[messages.length - 1]?.content?.slice(0, 60)}…"`)
    res.json({ role: 'assistant', content })
  } catch (err) {
    console.error('[RFP AIQ] Chat error:', err.message)
    res.status(500).json({ error: err.message })
  }
})

export default router
