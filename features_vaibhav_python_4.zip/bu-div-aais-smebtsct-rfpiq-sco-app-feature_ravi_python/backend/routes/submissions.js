import express from 'express'
import multer  from 'multer'
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join, extname } from 'path'
import { randomUUID } from 'crypto'

const __dirname = dirname(fileURLToPath(import.meta.url))
const router    = express.Router()

// ── File upload ───────────────────────────────────────────
const UPLOADS_DIR = join(__dirname, '../uploads')
if (!existsSync(UPLOADS_DIR)) mkdirSync(UPLOADS_DIR, { recursive: true })

// Works for both initial submission AND follow-up message attachments
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOADS_DIR,
    filename: (req, file, cb) => {
      const ts  = Date.now()
      const ext = extname(file.originalname).toLowerCase() || '.xlsx'
      cb(null, `${req.params.bidId}_Portal_${ts}${ext}`)
    },
  }),
  limits: { fileSize: 25 * 1024 * 1024 },
})

// ── Data loaders ──────────────────────────────────────────
const BIDS_PATH        = join(__dirname, '../data/bids.json')
const LINE_ITEMS_PATH  = join(__dirname, '../data/lineItems.json')
const EMAILS_PATH      = join(__dirname, '../data/emailThreads.json')
const SUPPLIERS_PATH   = join(__dirname, '../data/suppliers.json')
const SUBMISSIONS_PATH = join(__dirname, '../data/submissions.json')

const loadBids        = () => JSON.parse(readFileSync(BIDS_PATH,        'utf8'))
const saveBids        = (d) => writeFileSync(BIDS_PATH,        JSON.stringify(d, null, 2))
const loadLineItems   = () => JSON.parse(readFileSync(LINE_ITEMS_PATH,  'utf8'))
const loadSuppliers   = () => { try { return JSON.parse(readFileSync(SUPPLIERS_PATH, 'utf8')) } catch { return [] } }
const loadEmails      = () => JSON.parse(readFileSync(EMAILS_PATH,      'utf8'))
const saveEmails      = (d) => writeFileSync(EMAILS_PATH,      JSON.stringify(d, null, 2))
const loadSubmissions = () => {
  try { return JSON.parse(readFileSync(SUBMISSIONS_PATH, 'utf8')) } catch { return {} }
}
const saveSubmissions = (d) => writeFileSync(SUBMISSIONS_PATH, JSON.stringify(d, null, 2))

const PORTAL_BASE = process.env.PORTAL_BASE_URL || 'http://rfp-aiq.supplier.exlservice.com:5173'

// ── Compliance label map ──────────────────────────────────
const COMPLIANCE_LABELS = {
  'Child Nutrition': { label: 'Child Nutrition',  color: 'bg-green-100 text-green-800' },
  'Buy American':    { label: 'Buy American',     color: 'bg-red-100 text-red-700'     },
  'PFS':             { label: 'PFS Required',     color: 'bg-purple-100 text-purple-700'},
  'Halal':           { label: 'Halal',            color: 'bg-teal-100 text-teal-800'   },
  'Kosher':          { label: 'Kosher',           color: 'bg-indigo-100 text-indigo-800'},
}

// ── Helper: find supplierID by email ─────────────────────
function findSupplierId(email) {
  const suppliers = loadSuppliers()
  const match = suppliers.find(s => s.contact?.toLowerCase() === email.toLowerCase())
  return match?.id || null
}

// ── GET /api/submit/:bidId ────────────────────────────────
router.get('/:bidId', (req, res) => {
  const { bidId } = req.params
  const bids = loadBids()
  const bid  = bids.find(b => b.id === bidId)
  if (!bid) return res.status(404).json({ error: `Bid "${bidId}" not found` })

  const lineItems = loadLineItems().filter(li => li.bidId === bidId)

  res.json({
    bidId:                  bid.id,
    customerName:           bid.customer,
    segment:                bid.segment,
    dueDate:                bid.customerDue || '',
    complianceRequirements: (bid.compliance || [])
      .map(c => COMPLIANCE_LABELS[c] || { label: c, color: 'bg-gray-100 text-gray-700' }),
    lineItems: lineItems.map(li => ({
      id:             li.id,
      bidItem:        li.bidItem,
      mpcCode:        li.mpcCode     || '',
      description:    li.description,
      category:       li.category   || '',
      pack:           li.pack       || '',
      size:           li.size       || '',
      unit:           li.unit       || '',
      qty:            li.qty        || 0,
      buyAmerican:    li.buyAmerican    || false,
      childNutrition: li.childNutrition || false,
      pfsRequired:    li.pfsRequired    || false,
      exactSpec:      li.exactSpec      || false,
    })),
  })
})

// ── GET /api/submit/:bidId/submissions ────────────────────
// Portal stats per supplier — used by SuppliersTab
router.get('/:bidId/submissions', (req, res) => {
  const { bidId } = req.params
  const submissions = loadSubmissions()
  const list = submissions[bidId] || []
  // Return per-email summary: { supplierEmail, messageCount, lastActive, confirmationId, threadId }
  const summary = list.map(sub => ({
    supplierEmail:  sub.supplierEmail,
    supplierName:   sub.supplierName,
    confirmationId: sub.confirmationId,
    threadId:       sub.threadId,
    submittedAt:    sub.submittedAt,
    messageCount:   (sub.messages || []).length,
    lastActive:     sub.messages?.length
      ? sub.messages[sub.messages.length - 1].timestamp
      : sub.submittedAt,
  }))
  res.json(summary)
})

// ── POST /api/submit/:bidId ───────────────────────────────
router.post('/:bidId', upload.single('pricingFile'), (req, res) => {
  try {
    const { bidId } = req.params
    const bids = loadBids()
    const bid  = bids.find(b => b.id === bidId)
    if (!bid) return res.status(404).json({ error: `Bid "${bidId}" not found` })

    const { supplierName, supplierEmail, contactName, phone, notes, lineItemPrices } = req.body

    if (!supplierName?.trim())  return res.status(400).json({ error: 'Company name is required' })
    if (!contactName?.trim())   return res.status(400).json({ error: 'Contact name is required' })
    if (!supplierEmail?.trim()) return res.status(400).json({ error: 'Email address is required' })

    let lineItems = []
    if (lineItemPrices) { try { lineItems = JSON.parse(lineItemPrices) } catch {} }

    const confirmationId  = `SUB-${bidId}-${randomUUID().slice(0, 8).toUpperCase()}`
    const threadId        = `THREAD-${bidId}-${Date.now()}`
    const submittedAt     = new Date().toISOString()
    const pricingFileName = req.file ? req.file.filename : null

    // Count priced / no-bid items using new fields (delivered, fob, allowance) with fallback to legacy
    const pricedCount     = lineItems.filter(li => !li.noBid && (
      parseFloat(li.deliveredPrice) > 0 || parseFloat(li.fobPrice) > 0 ||
      parseFloat(li.unitPrice) > 0      || parseFloat(li.casePrice) > 0
    )).length
    const noBidCount      = lineItems.filter(li => li.noBid).length
    const dlCount         = lineItems.filter(li => !li.noBid && li.devType === 'DL').length
    const allwCount       = lineItems.filter(li => !li.noBid && li.devType === 'ALLW').length
    const otherPricedCount = pricedCount - dlCount - allwCount

    // Auto-summary body for initial message
    const pricingLines = []
    if (dlCount   > 0) pricingLines.push(`  ${dlCount} items with Delivered pricing (DL)`)
    if (allwCount > 0) pricingLines.push(`  ${allwCount} items with Allowance pricing (ALLW)`)
    if (otherPricedCount > 0) pricingLines.push(`  ${otherPricedCount} items priced (other)`)
    if (noBidCount > 0) pricingLines.push(`  ${noBidCount} items No Bid`)

    const initialMsgBody = [
      `${supplierName.trim()} submitted pricing via the Sysco Supplier Portal.`,
      `Submitted pricing for ${pricedCount} item${pricedCount !== 1 ? 's' : ''}:`,
      ...pricingLines,
      ...(notes?.trim() ? [``, `Notes: ${notes.trim()}`] : []),
    ].join('\n')

    // ── Save to submissions.json ──────────────────────────
    const submissions = loadSubmissions()
    if (!submissions[bidId]) submissions[bidId] = []
    submissions[bidId].push({
      confirmationId,
      threadId,
      submittedAt,
      supplierName:  supplierName.trim(),
      supplierEmail: supplierEmail.trim().toLowerCase(),
      contactName:   contactName.trim(),
      phone:         phone || '',
      notes:         notes || '',
      lineItems,
      pricingFile:   pricingFileName,
      pricedCount,
      noBidCount,
      dlCount,
      allwCount,
      otherPricedCount,
      messages: [{
        id:            randomUUID(),
        direction:     'inbound',
        from:          supplierEmail.trim().toLowerCase(),
        fromName:      contactName.trim(),
        body:          initialMsgBody,
        attachments:   pricingFileName ? [pricingFileName] : [],
        timestamp:     submittedAt,
        readByBidCOE:  false,
      }],
    })
    saveSubmissions(submissions)

    // ── Mirror to emailThreads.json ───────────────────────
    const supplierId = findSupplierId(supplierEmail.trim())
    const emails = loadEmails()
    const bodyLines = [
      `${supplierName.trim()} submitted pricing via the Sysco Supplier Portal.`,
      ``,
      `Contact: ${contactName} <${supplierEmail}>${phone ? ` | ${phone}` : ''}`,
      `Confirmation ID: ${confirmationId}`,
      `Thread ID: ${threadId}`,
      ``,
      `Submitted pricing for ${pricedCount} item${pricedCount !== 1 ? 's' : ''}:`,
      ...pricingLines,
      ...(notes?.trim() ? [``, `Notes: ${notes.trim()}`] : []),
      ``,
      `View conversation: ${PORTAL_BASE}/submit/${bidId}/thread/${threadId}`,
    ]

    emails.push({
      id:            `E-${Date.now()}`,
      bidId,
      direction:     'inbound',
      supplierId,
      supplierName:  supplierName.trim(),
      supplierEmail: supplierEmail.trim().toLowerCase(),
      from:          `${contactName.trim()} <${supplierEmail.trim()}>`,
      to:            'COE.BIDS@sysco.com',
      bcc:           [],
      subject:       `Pricing Submission (Portal): ${bidId} — ${bid.customer} — ${supplierName.trim()}`,
      body:          bodyLines.join('\n'),
      date:          submittedAt,
      attachments:   pricingFileName ? [pricingFileName] : [],
      pricingFilePath: pricingFileName ? `uploads/${pricingFileName}` : null,
      tags:          ['Response', 'Pricing', 'portal-submission'],
      read:          false,
      analysisResult: null,
      portalSubmission: true,
      confirmationId,
      threadId,
    })
    saveEmails(emails)

    // ── Update solicitedSuppliers status → Responded ──────
    try {
      const bidIdx = bids.findIndex(b => b.id === bidId)
      if (bidIdx !== -1) {
        const ss   = bids[bidIdx].solicitedSuppliers || []
        const sIdx = ss.findIndex(s => s.email.toLowerCase() === supplierEmail.trim().toLowerCase())
        if (sIdx !== -1) {
          if (ss[sIdx].status === 'Awaiting') {
            ss[sIdx].status     = 'Responded'
            ss[sIdx].lastActivity = submittedAt.split('T')[0]
          }
          // Update channel: Email→Both, unset→Portal
          const prev = ss[sIdx].channel
          ss[sIdx].channel = (prev === 'Email' || prev === 'Both') ? 'Both' : 'Portal'
          bids[bidIdx].solicitedSuppliers = ss
          saveBids(bids)
        }
      }
    } catch { /* best-effort */ }

    console.log(`[Submissions] ${bidId}: ${supplierName} submitted — ${confirmationId} / ${threadId}`)

    res.status(201).json({
      success:          true,
      confirmationId,
      threadId,
      supplierName:     supplierName.trim(),
      customerName:     bid.customer,
      supplierEmail:    supplierEmail.trim().toLowerCase(),
      submittedAt,
      pricedCount,
      noBidCount,
      dlCount,
      allwCount,
      otherPricedCount,
    })
  } catch (err) {
    console.error('[Submissions] POST error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ── POST /api/submit/:bidId/message ──────────────────────
// Supplier sends a follow-up message on an existing thread
router.post('/:bidId/message', upload.single('file'), (req, res) => {
  try {
    const { bidId } = req.params
    const { threadId, supplierEmail, message } = req.body

    if (!threadId)      return res.status(400).json({ error: 'threadId is required' })
    if (!supplierEmail) return res.status(400).json({ error: 'supplierEmail is required' })
    if (!message?.trim()) return res.status(400).json({ error: 'message is required' })

    const submissions = loadSubmissions()
    const list = submissions[bidId] || []
    const subIdx = list.findIndex(
      s => s.threadId === threadId &&
           s.supplierEmail.toLowerCase() === supplierEmail.toLowerCase()
    )
    if (subIdx === -1) return res.status(404).json({ error: 'Thread not found or email mismatch' })

    const sub       = list[subIdx]
    const now       = new Date().toISOString()
    const filename  = req.file ? req.file.filename : null
    const messageId = randomUUID()

    // Append to messages array
    sub.messages = sub.messages || []
    sub.messages.push({
      id:           messageId,
      direction:    'inbound',
      from:         sub.supplierEmail,
      fromName:     sub.contactName || sub.supplierName,
      body:         message.trim(),
      attachments:  filename ? [filename] : [],
      timestamp:    now,
      readByBidCOE: false,
    })
    submissions[bidId][subIdx] = sub
    saveSubmissions(submissions)

    // Mirror to emailThreads.json
    const bid = loadBids().find(b => b.id === bidId) || {}
    const supplierId = findSupplierId(sub.supplierEmail)
    const emails = loadEmails()
    emails.push({
      id:            `E-${Date.now()}`,
      bidId,
      direction:     'inbound',
      supplierId,
      supplierName:  sub.supplierName,
      supplierEmail: sub.supplierEmail,
      from:          `${sub.contactName || sub.supplierName} <${sub.supplierEmail}>`,
      to:            'COE.BIDS@sysco.com',
      bcc:           [],
      subject:       `Re: ${sub.supplierName} — ${bid.customer || bidId} (Portal)`,
      body:          message.trim(),
      date:          now,
      attachments:   filename ? [filename] : [],
      pricingFilePath: filename ? `uploads/${filename}` : null,
      tags:          ['Response', 'Q&A', 'portal-message'],
      read:          false,
      analysisResult: null,
      portalSubmission: true,
      threadId,
      confirmationId: sub.confirmationId,
    })
    saveEmails(emails)

    console.log(`[Submissions] ${bidId}: new message from ${sub.supplierEmail} on ${threadId}`)
    res.json({ success: true, messageId })
  } catch (err) {
    console.error('[Submissions] POST /message error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ── GET /api/submit/:bidId/thread/:threadId ───────────────
// Supplier views their thread — requires email verification
router.get('/:bidId/thread/:threadId', (req, res) => {
  const { bidId, threadId } = req.params
  const email = (req.query.email || '').toLowerCase().trim()

  const submissions = loadSubmissions()
  const list = submissions[bidId] || []
  const sub  = list.find(s => s.threadId === threadId)

  if (!sub) return res.status(404).json({ error: 'Thread not found' })

  // Email verification gate
  if (!email) return res.status(401).json({ error: 'Email verification required', needsEmail: true })
  if (sub.supplierEmail.toLowerCase() !== email) {
    return res.status(403).json({ error: 'Email does not match this submission', needsEmail: true })
  }

  // Mark COE outbound messages as readBySupplier
  let changed = false
  ;(sub.messages || []).forEach(m => {
    if (m.direction === 'outbound' && !m.readBySupplier) {
      m.readBySupplier = true
      changed = true
    }
  })
  if (changed) saveSubmissions(submissions)

  const bid = loadBids().find(b => b.id === bidId) || {}

  // Sort all messages by timestamp ascending — ensures correct order even if appended out of order
  const messages = [...(sub.messages || [])].sort(
    (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
  )
  const lastUpdated = messages.length
    ? messages[messages.length - 1].timestamp
    : sub.submittedAt

  console.log(`[Thread GET] ${bidId}/${threadId} — ${messages.length} message(s) (${messages.filter(m=>m.direction==='outbound').length} outbound)`)

  res.json({
    threadId,
    confirmationId: sub.confirmationId,
    submittedAt:    sub.submittedAt,
    supplierName:   sub.supplierName,
    supplierEmail:  sub.supplierEmail,
    contactName:    sub.contactName,
    pricedCount:    sub.pricedCount,
    noBidCount:     sub.noBidCount,
    pricingFile:    sub.pricingFile,
    lineItems:      sub.lineItems || [],
    customerName:   bid.customer || '',
    bidId,
    messages,
    messageCount:   messages.length,
    lastUpdated,
  })
})

// ── GET /api/submit/:bidId/status/:confirmationId ─────────
router.get('/:bidId/status/:confirmationId', (req, res) => {
  const { bidId, confirmationId } = req.params
  const list = (loadSubmissions()[bidId] || [])
  const sub  = list.find(s => s.confirmationId === confirmationId)
  if (!sub) return res.status(404).json({ error: 'Submission not found' })
  res.json({
    found: true, confirmationId: sub.confirmationId,
    supplierName: sub.supplierName, submittedAt: sub.submittedAt,
    pricedCount: sub.pricedCount, noBidCount: sub.noBidCount,
    threadId: sub.threadId,
  })
})

export default router
