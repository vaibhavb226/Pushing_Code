import express from 'express'
import { readFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const router = express.Router()

const loadEmails = () => JSON.parse(readFileSync(join(__dirname, '../data/emailThreads.json'), 'utf8'))

// GET /api/emails?bidId=BID-106
router.get('/', (req, res) => {
  const emails = loadEmails()
  const { bidId } = req.query
  const filtered = bidId ? emails.filter(e => e.bidId === bidId) : emails
  res.json(filtered)
})

// GET /api/emails/:id
router.get('/:id', (req, res) => {
  const emails = loadEmails()
  const email = emails.find(e => e.id === req.params.id)
  if (!email) return res.status(404).json({ error: 'Email not found' })
  res.json(email)
})

// POST /api/emails/log — Log a sent solicitation email
router.post('/log', (req, res) => {
  const { bidId, subject, body, recipients, attachments, tags } = req.body
  const newEmail = {
    id: `E-${Date.now()}`,
    bidId,
    direction: 'outbound',
    from: 'COE.BIDS@sysco.com',
    to: 'Multiple Recipients',
    bcc: recipients || [],
    subject: subject || '',
    body: body || '',
    date: new Date().toISOString(),
    attachments: attachments || [],
    tags: tags || ['Solicitation'],
    read: true,
  }
  // In POC, just return the logged email (no persistence)
  res.json({ success: true, email: newEmail })
})

export default router
