// ============================================================
// emailService.js — Nodemailer Gmail SMTP sender
// ============================================================

import nodemailer from 'nodemailer'
import { existsSync } from 'fs'

// ── Build transporter (lazy — only created when first needed) ─
let _transporter = null

function getTransporter() {
  if (_transporter) return _transporter

  const user = process.env.EMAIL_FROM
  // Strip spaces — Google App Passwords are displayed with spaces but sent without
  const pass = (process.env.EMAIL_APP_PASSWORD || '').replace(/\s/g, '')

  if (!user || !pass) {
    throw new Error(
      'Email not configured — set EMAIL_FROM and EMAIL_APP_PASSWORD in backend/.env'
    )
  }

  _transporter = nodemailer.createTransport({
    host:   process.env.EMAIL_HOST || 'smtp.gmail.com',
    port:   Number(process.env.EMAIL_PORT) || 587,
    secure: false,       // STARTTLS on port 587
    auth:   { user, pass },
  })

  return _transporter
}

// ── Verify SMTP connection (call once at startup) ─────────
export async function verifyEmailConfig() {
  try {
    const t = getTransporter()
    await t.verify()
    console.log('📧 Email SMTP: ✅ Connected —', process.env.EMAIL_FROM)
    return true
  } catch (err) {
    console.warn('📧 Email SMTP: ⚠️  Not configured —', err.message)
    return false
  }
}

// ── Plain text → HTML (preserve line breaks + blank lines) ─
function textToHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .split('\n')
    .map(line => line.trim() === '' ? '<br>' : `<p style="margin:0 0 4px 0">${line}</p>`)
    .join('\n')
}

// ── sendEmail ─────────────────────────────────────────────
/**
 * Send an email via Gmail SMTP.
 *
 * @param {Object}   opts
 * @param {string}   opts.to               - "To" address (can be empty for BCC-only)
 * @param {string[]} opts.bcc              - Array of BCC email addresses
 * @param {string}   opts.subject          - Email subject
 * @param {string}   opts.body             - Plain text body (auto-converted to HTML)
 * @param {string[]} [opts.attachmentNames]  - Display-only names shown in body note
 * @param {Array}    [opts.attachmentPaths]  - Real file attachments:
 *                                            [{ filename: 'RFP.pdf', path: '/abs/path' }]
 *                                            Missing files are skipped gracefully.
 *
 * @returns {{ messageId, timestamp, recipientCount, attachedCount }}
 * @throws  Error with descriptive message on SMTP failure
 */
export async function sendEmail({
  to,
  bcc = [],
  subject,
  body,
  attachmentNames  = [],
  attachmentPaths  = [],
}) {
  if (!subject?.trim()) throw new Error('Email subject is required')
  if (bcc.length === 0) throw new Error('At least one BCC recipient is required')

  const transporter = getTransporter()
  const from        = process.env.EMAIL_FROM

  // Filter out empty / invalid-looking entries from bcc list
  const cleanBcc = bcc.map(e => String(e).trim()).filter(e => e.includes('@'))
  if (cleanBcc.length === 0) {
    throw new Error('No valid email addresses in the BCC list')
  }

  // ── Resolve real attachments — skip missing files, never throw ──
  const validAttachments = []
  const missingCount     = { value: 0 }

  for (const a of attachmentPaths) {
    try {
      if (a?.path && existsSync(a.path)) {
        validAttachments.push({ filename: a.filename, path: a.path })
      } else {
        missingCount.value++
        console.warn('[Email] Attachment file not found (skipped):', a?.path)
      }
    } catch (e) {
      missingCount.value++
      console.warn('[Email] Could not check attachment:', e.message)
    }
  }

  // If requested files are missing, append a polite note to the body
  let finalBody = body || ''
  if (attachmentPaths.length > 0 && missingCount.value > 0 && validAttachments.length === 0) {
    finalBody +=
      '\n\nNote: The item list attachment could not be included automatically. ' +
      'Please contact COE.BIDS@sysco.com to request the item list.'
    console.warn(`[Email] All ${missingCount.value} attachment(s) missing — note added to body`)
  } else if (missingCount.value > 0) {
    console.warn(`[Email] ${missingCount.value} attachment(s) skipped — files not found`)
  }

  const htmlBody = textToHtml(finalBody)

  // Legacy display-only note (only shown when NO real files were attached)
  const attachNote = (validAttachments.length === 0 && attachmentNames.length > 0)
    ? `\n<hr style="margin:16px 0;border:none;border-top:1px solid #eee">
       <p style="color:#888;font-size:12px;margin:0">
         <strong>Attachments referenced:</strong> ${attachmentNames.join(', ')}<br>
         <em>(Files will be attached in the production system.)</em>
       </p>`
    : ''

  const mailOptions = {
    from:        `"Sysco Bid COE" <${from}>`,
    to:          to || from,          // Gmail requires a To — use self if BCC-only
    bcc:         cleanBcc.join(', '),
    subject,
    html:        htmlBody + attachNote,
    text:        finalBody,
    attachments: validAttachments,    // empty array = no attachments (nodemailer is fine with this)
  }

  try {
    const info = await transporter.sendMail(mailOptions)
    const attachLog = validAttachments.length > 0
      ? ` + ${validAttachments.length} attachment(s): ${validAttachments.map(a => a.filename).join(', ')}`
      : ' (no attachments)'
    console.log(`[Email] Sent "${subject}" to ${cleanBcc.length} BCC recipients${attachLog} — msgId: ${info.messageId}`)
    return {
      messageId:      info.messageId,
      timestamp:      new Date().toISOString(),
      recipientCount: cleanBcc.length,
      attachedCount:  validAttachments.length,
    }
  } catch (err) {
    console.error('[Email] Send failed:', err.message)

    // Translate common SMTP errors to user-friendly messages
    if (err.code === 'EAUTH' || err.responseCode === 535) {
      throw new Error(
        'Gmail authentication failed — check EMAIL_APP_PASSWORD in .env. ' +
        'Make sure you\'re using an App Password, not your regular Gmail password.'
      )
    }
    if (err.code === 'ECONNREFUSED' || err.code === 'ETIMEDOUT') {
      throw new Error(
        'Cannot connect to Gmail SMTP — check EMAIL_HOST and EMAIL_PORT in .env, ' +
        'and ensure port 587 is not blocked by a firewall.'
      )
    }
    if (err.responseCode === 550 || err.responseCode === 553) {
      throw new Error(`Recipient address rejected by Gmail: ${err.response}`)
    }

    throw new Error(`Email send failed: ${err.message}`)
  }
}
