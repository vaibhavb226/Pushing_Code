// ── Demo data guard ───────────────────────────────────────
// Re-injects GM bounce demo emails ONLY when General Mills
// (SUP-004) is already present in B2600042's solicitedSuppliers.
// This prevents bleed onto fresh bids that haven't been solicited.

import { readFileSync, writeFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join }  from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const DATA      = join(__dirname, '../data')

const GM_EMAILS = [
  {
    id: 'EMAIL-GM-OUT-001', isDemo: true,
    bidId: 'B2600042', supplierId: 'SUP-004',
    supplierName: 'General Mills Foodservice',
    supplierEmail: 'bids@demo-generalmills.com.test',
    direction: 'outbound', type: 'solicitation', isBounce: false,
    from: 'COE.BIDS@sysco.com', to: 'bids@demo-generalmills.com.test', bcc: [],
    subject: 'Pricing Request: Lakeview Unified School District — B2600042 | Due Jul 15, 2026',
    body: 'Good morning,\n\nAs we move forward in the bid process for Lakeview Unified School District, Sysco requests that you provide pricing for the attached item list no later than July 15, 2026.\n\nPlease return all pricing to: COE.BIDS@sysco.com\n\nSysco Bid COE\nCOE.BIDS@sysco.com',
    date: '2026-06-10T10:58:00.000Z', tags: ['Solicitation'],
    attachments: [], read: true, analysisResult: null,
  },
  {
    id: 'EMAIL-GM-BOUNCE-001', isDemo: true,
    bidId: 'B2600042', supplierId: 'SUP-004',
    supplierName: 'General Mills Foodservice',
    supplierEmail: 'bids@demo-generalmills.com.test',
    direction: 'inbound', type: 'bounce', isBounce: true, isIssue: true,
    from: 'mailer-daemon@mail.generalmills.com',
    to: 'sysco.bid.poc@gmail.com', bcc: [],
    originalRecipient: 'bids@demo-generalmills.com.test',
    subject: 'Mail Delivery Failure: Pricing Request: Lakeview Unified School District — B2600042 | Due Jul 15, 2026',
    body: 'This is an automated message from the mail delivery system.\n\nDELIVERY FAILURE REPORT\n─────────────────────────────────────────\nOriginal Recipient: bids@demo-generalmills.com.test\nStatus:             550 5.1.1 — User does not exist\nTime:               June 10, 2026 at 11:02 AM EST\nMail Server:        mail.generalmills.com\n─────────────────────────────────────────\n\nThe email address bids@demo-generalmills.com.test does not exist or has been disabled. Please verify the recipient email address and try again.\n\nThis is an automated notification. Please do not reply to this message.',
    date: '2026-06-10T11:02:00.000Z',
    tags: ['bounce', 'delivery-failure'],
    attachments: [], bounceCode: '550 5.1.1', bounceReason: 'User does not exist',
    read: true, analysisResult: null,
  },
]

export function ensureBounceDemo() {
  try {
    const bidsPath = join(DATA, 'bids.json')
    const bids     = JSON.parse(readFileSync(bidsPath, 'utf8'))
    const bid      = bids.find(b => b.id === 'B2600042')
    if (!bid) return

    const ss    = bid.solicitedSuppliers || []
    const gmIdx = ss.findIndex(s => s.supplierId === 'SUP-004')

    // Only restore demo data if GM has already been solicited on this bid.
    // If solicitedSuppliers is empty (fresh bid), do nothing.
    if (gmIdx === -1) return

    // ── Restore GM bounce status in bids.json if cleared ──
    let bidsChanged = false
    if (ss[gmIdx].status !== 'Issues Found') {
      ss[gmIdx] = {
        ...ss[gmIdx],
        status: 'Issues Found', hasIssues: true, issueType: 'bounce',
        bounceCode: '550 5.1.1', bounceReason: 'User does not exist',
        bouncedAt: '2026-06-10T11:02:00.000Z', lastActivity: '2026-06-10',
      }
      bid.solicitedSuppliers = ss
      bidsChanged = true
    }
    if (bidsChanged) {
      writeFileSync(bidsPath, JSON.stringify(bids, null, 2))
      console.log('[Demo] GM supplier bounce status restored ✅')
    }

    // ── Restore GM emails in emailThreads.json if cleared ──
    const threadsPath = join(DATA, 'emailThreads.json')
    const threads     = JSON.parse(readFileSync(threadsPath, 'utf8'))
    const ids         = new Set(threads.map(e => e.id))
    let   threadsChanged = false

    for (const email of GM_EMAILS) {
      if (!ids.has(email.id)) {
        threads.push(email)
        threadsChanged = true
        console.log(`[Demo] Re-injected ${email.id}`)
      }
    }

    if (threadsChanged) {
      writeFileSync(threadsPath, JSON.stringify(threads, null, 2))
      console.log('[Demo] Bounce demo emails restored ✅')
    }
  } catch (err) {
    console.warn('[Demo] ensureBounceDemo failed:', err.message)
  }
}
