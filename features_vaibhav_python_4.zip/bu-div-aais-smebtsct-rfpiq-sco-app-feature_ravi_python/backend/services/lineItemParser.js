// ============================================================
// lineItemParser.js — Auto-parse line items from Excel or PDF
//
// Excel path: direct XLSX column-mapping (structured, reliable)
// PDF path:   pdf-parse text extraction → Anthropic AI
//
// Priority: Excel beats PDF — if both uploaded for the same
// bid, Excel result overwrites PDF result.
// ============================================================

import { readFileSync, writeFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import { createRequire } from 'module'
import * as XLSX  from 'xlsx'
import Anthropic  from '@anthropic-ai/sdk'

const __dirname = dirname(fileURLToPath(import.meta.url))
const DATA_DIR  = join(__dirname, '../data')

const loadBids       = () => JSON.parse(readFileSync(join(DATA_DIR, 'bids.json'),      'utf8'))
const saveBids       = (d) => writeFileSync(join(DATA_DIR, 'bids.json'),      JSON.stringify(d, null, 2))
const loadLineItems  = () => JSON.parse(readFileSync(join(DATA_DIR, 'lineItems.json'), 'utf8'))
const saveLineItemsJ = (d) => writeFileSync(join(DATA_DIR, 'lineItems.json'), JSON.stringify(d, null, 2))

// ── JSON extraction helper ────────────────────────────────
function extractJSON(raw) {
  let text = (raw || '').trim()
    .replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim()
  try { return JSON.parse(text) } catch {}
  const obj = text.match(/\{[\s\S]*\}/)
  if (obj) { try { return JSON.parse(obj[0]) } catch {} }
  throw new Error('Could not parse AI response as JSON')
}

// ── Shared: persist items to lineItems.json + update bid ──
export async function saveLineItemsToDB(bidId, items, source) {
  const existing = loadLineItems()
  const filtered = existing.filter(li => li.bidId !== bidId)

  const newItems = items.map((item, i) => ({
    id:             `LI-${bidId}-${String(i + 1).padStart(3, '0')}`,
    bidId,
    bidItem:        String(item.itemNo || (i + 1)).padStart(4, '0'),
    mpcCode:        item.mfgCode   || item.mpcCode  || '',
    brand:          item.brand     || '',
    description:    item.description || '',
    pack:           item.packSize  || item.pack    || '',
    size:           item.size      || '',
    unit:           item.unit      || 'CS',
    category:       item.category  || 'Grocery',
    qty:            Number(item.estQty || item.qty) || 0,
    storage:        item.storage   || '',
    cw:             'N',
    stkType:        'A',
    buyAmerican:    (item.compliance || []).includes('Buy American') || Boolean(item.buyAmerican),
    childNutrition: (item.compliance || []).includes('CN') || Boolean(item.childNutrition),
    pfsRequired:    (item.compliance || []).includes('PFS') || Boolean(item.pfsRequired),
    exactSpec:      Boolean(item.exactSpec),
    rfpPopulated:   true,
    _source:        source,   // 'excel' | 'pdf'
    // Right side — filled from supplier responses
    trueVendor:     null,
    suppliedPrice:  null,
    allw:           null,
    dl:             null,
    priceCase:      null,
    devType:        null,
    openReview:     false,
    status:         'No Response',
    confidence:     null,
  }))

  filtered.push(...newItems)
  saveLineItemsJ(filtered)

  // Update bid metadata
  const bids   = loadBids()
  const bidIdx = bids.findIndex(b => b.id === bidId)
  if (bidIdx !== -1) {
    bids[bidIdx].items            = newItems.length
    bids[bidIdx]._lineItemSource  = source
    bids[bidIdx].itemCategories   = [...new Set(newItems.map(li => li.category).filter(Boolean))]
    saveBids(bids)
  }

  return newItems
}

// ── Excel → line items (direct column mapping) ───────────
export async function parseLineItemsFromExcel(bidId, filePath) {
  try {
    const buffer   = readFileSync(filePath)
    const workbook = XLSX.read(buffer, { type: 'buffer' })
    const sheet    = workbook.Sheets[workbook.SheetNames[0]]
    const rows     = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' })

    if (!rows.length) { console.log('[LineItemParser] Excel: empty file'); return [] }

    // Find first non-empty row as header
    const headerRow  = rows.find(r => r.some(c => String(c).trim())) || rows[0]
    const headerIdx  = rows.indexOf(headerRow)
    const headers    = headerRow.map(c => String(c).trim().toLowerCase())
    const dataRows   = rows.slice(headerIdx + 1).filter(r => r.some(c => String(c).trim()))

    if (!dataRows.length) { console.log('[LineItemParser] Excel: no data rows'); return [] }

    // Flexible column index resolver — matches first header containing any of the keywords
    const col = (...names) => {
      for (const n of names) {
        const idx = headers.findIndex(h => h.includes(n.toLowerCase()))
        if (idx !== -1) return idx
      }
      return -1
    }

    const iDesc    = col('description', 'item desc', 'product desc', 'prod desc')
    const iItemNo  = col('item no', 'item #', 'bid item', 'line no', 'item number', 'line number')
    const iMpc     = col('mpc', 'mfg code', 'manufacturer code', 'product code', 'mfg#')
    const iBrand   = col('brand')
    const iPack    = col('pack size', 'pack')
    const iSize    = col('size')
    const iUnit    = col('uom', 'unit of measure', 'unit')
    const iQty     = col('est qty', 'qty', 'quantity', 'volume', 'annual qty', 'est. qty')
    const iCat     = col('category', 'cat.')
    const iStorage = col('storage', 'temp', 'temp zone')
    const iCN      = col('cn', 'child nutrition', 'child nutr')
    const iBA      = col('buy american', 'buy am', 'ba')
    const iPFS     = col('pfs')

    const get = (row, idx) => idx >= 0 ? String(row[idx] ?? '').trim() : ''
    const flag = (row, idx) => {
      if (idx < 0) return false
      const v = get(row, idx).toLowerCase()
      return v === 'yes' || v === 'y' || v === 'x' || v === '1' || v === 'true'
    }

    const items = dataRows.map((row, i) => {
      const desc = get(row, iDesc) || get(row, 0)
      if (!desc) return null

      const compliance = []
      if (flag(row, iCN))  compliance.push('CN')
      if (flag(row, iBA))  compliance.push('Buy American')
      if (flag(row, iPFS)) compliance.push('PFS')

      return {
        itemNo:      get(row, iItemNo) || String(i + 1).padStart(4, '0'),
        description: desc,
        mfgCode:     get(row, iMpc),
        brand:       get(row, iBrand),
        packSize:    get(row, iPack),
        size:        get(row, iSize),
        unit:        get(row, iUnit) || 'CS',
        estQty:      parseFloat(get(row, iQty)) || 0,
        category:    get(row, iCat) || 'Grocery',
        storage:     get(row, iStorage),
        compliance,
      }
    }).filter(Boolean)

    if (!items.length) { console.log('[LineItemParser] Excel: no items from rows'); return [] }

    const saved = await saveLineItemsToDB(bidId, items, 'excel')
    console.log(`[LineItemParser] Excel: ${saved.length} items saved for bid ${bidId}`)
    return saved
  } catch (err) {
    console.error('[LineItemParser] Excel error:', err.message)
    return []
  }
}

// ── PDF → line items via Anthropic AI ────────────────────
export async function parseLineItemsFromPDF(bidId, filePath) {
  try {
    if (!process.env.ANTHROPIC_API_KEY) {
      console.log('[LineItemParser] PDF: no ANTHROPIC_API_KEY — skipping')
      return []
    }

    // Use createRequire so pdf-parse CJS module loads correctly in ESM context
    const _require = createRequire(import.meta.url)
    const pdfParse = _require('pdf-parse')

    const dataBuffer = readFileSync(filePath)
    const pdfData    = await pdfParse(dataBuffer)
    const pdfText    = (pdfData.text || '').trim()

    console.log('[LineItemParser] PDF text length:', pdfText.length)
    if (!pdfText) { console.log('[LineItemParser] PDF: no text extracted'); return [] }

    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

    const response = await client.messages.create({
      model:      process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
      max_tokens: 4000,
      messages: [{
        role: 'user',
        content:
`Extract all product line items from this RFP/bid document. Return ONLY valid JSON. No markdown fences, no explanation. Start with { and end with }.

DOCUMENT TEXT:
${pdfText.substring(0, 15000)}

Return this exact structure:
{
  "items": [
    {
      "itemNo": "0001",
      "category": "Protein",
      "description": "full product description",
      "brand": "brand name or empty string",
      "mfgCode": "product code or empty string",
      "packSize": "e.g. 6/10 or empty string",
      "size": "e.g. 4 OZ or empty string",
      "unit": "CS or EA or LB etc",
      "estQty": 0,
      "storage": "Freezer or Cooler or Dry or empty string",
      "compliance": ["CN", "Buy American", "PFS"]
    }
  ],
  "confidence": "high|medium|low",
  "totalFound": 0
}

Rules:
- Extract ALL items — do not skip any
- Use existing item numbers if present, otherwise number sequentially from 0001
- Categories: Protein, Dairy, Bakery, Produce, Grocery, Beverage, Paper
- Compliance: include CN, Buy American, PFS, Halal, Kosher, Whole Grain when indicated
- Use empty string for absent fields; estQty defaults to 0
- Return empty items array [] if no product line items found`,
      }],
    })

    const rawText = response.content[0]?.text || ''
    const parsed  = extractJSON(rawText)
    const items   = parsed.items || []

    if (!items.length) { console.log('[LineItemParser] PDF: no items found by AI'); return [] }

    const saved = await saveLineItemsToDB(bidId, items, 'pdf')
    console.log(`[LineItemParser] PDF: ${saved.length} items saved for bid ${bidId} (AI confidence: ${parsed.confidence})`)
    return saved
  } catch (err) {
    console.error('[LineItemParser] PDF error:', err.message)
    return []
  }
}

// ── Auto-detect file type and call correct parser ────────
export async function autoParseLineItems(bidId, file, filePath) {
  const name = (file.originalname || file.filename || filePath || '').toLowerCase()
  const mime = (file.mimetype || '').toLowerCase()

  if (mime.includes('spreadsheet') || mime.includes('excel') || /\.xlsx?$/i.test(name)) {
    console.log(`[AutoParse] ${bidId}: Excel detected → structured parser`)
    return await parseLineItemsFromExcel(bidId, filePath)
  }
  if (mime.includes('pdf') || /\.pdf$/i.test(name)) {
    console.log(`[AutoParse] ${bidId}: PDF detected → AI parser`)
    return await parseLineItemsFromPDF(bidId, filePath)
  }

  console.log(`[AutoParse] ${bidId}: unrecognised type (mime="${mime}" name="${name}") — skipping`)
  return []
}
