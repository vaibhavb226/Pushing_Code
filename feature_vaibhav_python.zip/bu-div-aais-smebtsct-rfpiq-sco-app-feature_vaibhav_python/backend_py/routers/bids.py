"""
All /api/bids/* endpoints — 23 routes.

IMPORTANT: /portal-templates is declared BEFORE /{bid_id} to prevent
FastAPI matching the literal string "portal-templates" as bid_id.
"""
from __future__ import annotations

import io
import json
import re
import time
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import aiofiles
import structlog
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    Form,
    HTTPException,
    Query,
    UploadFile,
)
from fastapi.responses import FileResponse

from dependencies import (
    UPLOADS_DIR,
    get_bids_repo,
    get_documents_repo,
    get_email_threads_repo,
    get_line_items_repo,
    get_llm_service,
    get_portal_templates_repo,
    get_pricing_repo,
    get_submissions_repo,
)
from repositories.bids_repo import BidsRepository
from repositories.documents_repo import DocumentsRepository
from repositories.email_threads_repo import EmailThreadsRepository
from repositories.line_items_repo import LineItemsRepository
from repositories.portal_templates_repo import PortalTemplatesRepository
from repositories.pricing_repo import PricingRepository
from repositories.submissions_repo import SubmissionsRepository
from routers.prompts import PRICING_EXTRACTION_SYSTEM
from schemas.bid import BidCreate, BidResponse, BidUpdate, DeleteResult
from schemas.line_item import LineItemUpdate
from services.llm.json_parser import extract_json
from services.llm.provider import LLMService
from utils.award_email_template import build_award_email_body, build_award_email_subject
from utils.file_utils import format_file_size, safe_filename

log = structlog.get_logger()
router = APIRouter(tags=["bids"])


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PORTAL TEMPLATES — declared BEFORE /{bid_id}
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/portal-templates", response_model=list[dict[str, Any]])
async def get_portal_templates(
    repo: PortalTemplatesRepository = Depends(get_portal_templates_repo),
) -> list[dict[str, Any]]:
    return await repo.load()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BIDS CRUD
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/", response_model=list[dict[str, Any]])
async def list_bids(
    segment: str | None = None,
    status: str | None = None,
    repo: BidsRepository = Depends(get_bids_repo),
) -> list[dict[str, Any]]:
    bids = await repo.load()
    if segment:
        bids = [b for b in bids if b.get("segment") == segment]
    if status:
        bids = [b for b in bids if b.get("status") == status]
    return bids


@router.post("/", response_model=dict[str, Any], status_code=201)
async def create_bid(
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    bid_id = body.get("id") or f"BID-{int(time.time() * 1000) % 100000}"
    today = date.today().isoformat()

    new_bid: dict[str, Any] = {
        "id": bid_id,
        "customer": body.get("customer", ""),
        "opco": body.get("opco", ""),
        "opcoName": body.get("opcoName", ""),
        "region": body.get("region", ""),
        "segment": body.get("segment", ""),
        "status": body.get("status", "Active"),
        "intakeDate": today,
        "customerDue": body.get("customerDue", ""),
        "internalDue": body.get("internalDue", ""),
        "bidRelease": body.get("bidRelease", ""),
        "items": 0,
        "suppliersContacted": 0,
        "responsesReceived": 0,
        "notes": body.get("notes", ""),
        "compliance": body.get("compliance", []),
        "itemCategories": body.get("itemCategories", []),
        "solicitedSuppliers": [],
        "uploadedFiles": [],
    }

    # Save line items if provided (from BEX AI parse flow)
    raw_items: list[dict[str, Any]] = body.get("lineItems", [])
    if raw_items:
        all_items = await line_items_repo.load()
        all_items = [it for it in all_items if it.get("bidId") != bid_id]
        all_items.extend(raw_items)
        await line_items_repo.save(all_items)
        new_bid["items"] = len(raw_items)

    await bids_repo.append(new_bid)
    log.info("bid.created", bid_id=bid_id, customer=new_bid["customer"])
    return new_bid


@router.get("/{bid_id}", response_model=dict[str, Any])
async def get_bid(
    bid_id: str,
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    bid = await repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return bid


@router.patch("/{bid_id}", response_model=dict[str, Any])
async def update_bid(
    bid_id: str,
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        return {**bid, **{k: v for k, v in body.items() if k != "id"}}

    updated = await bids_repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    # Sync award status to line items if awardedSupplier changes
    if "solicitedSuppliers" in body:
        await _sync_award_to_line_items(bid_id, body["solicitedSuppliers"], line_items_repo)

    log.info("bid.updated", bid_id=bid_id)
    return updated


@router.delete("/{bid_id}", response_model=DeleteResult)
async def delete_bid(
    bid_id: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    pricing_repo: PricingRepository = Depends(get_pricing_repo),
    documents_repo: DocumentsRepository = Depends(get_documents_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> DeleteResult:
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    # Cascading deletes
    li_count = await line_items_repo.delete_where(lambda x: x.get("bidId") == bid_id)
    em_count = await email_threads_repo.delete_where(lambda x: x.get("bidId") == bid_id)
    pr_count = await pricing_repo.delete_where(lambda x: x.get("bidId") == bid_id)
    doc_count = await documents_repo.delete_where(lambda x: x.get("bidId") == bid_id)
    sub_count = await submissions_repo.delete_for_bid(bid_id)

    # Delete uploaded files
    file_count = 0
    if UPLOADS_DIR.exists():
        for fp in UPLOADS_DIR.iterdir():
            if fp.name.startswith(f"{bid_id}_") or fp.name.startswith(f"{bid_id}-"):
                try:
                    fp.unlink()
                    file_count += 1
                except OSError:
                    pass

    # Remove bid record
    await bids_repo.delete_where(lambda b: b.get("id") == bid_id)

    removed = {
        "lineItems": li_count,
        "emails": em_count,
        "pricing": pr_count,
        "documents": doc_count,
        "submissions": sub_count,
        "files": file_count,
    }
    log.info("bid.deleted", bid_id=bid_id, removed=removed)
    return DeleteResult(success=True, deleted=bid_id, removed=removed)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FILE UPLOAD / SERVE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/files", response_model=list[dict[str, Any]])
async def get_bid_files(
    bid_id: str,
    repo: BidsRepository = Depends(get_bids_repo),
) -> list[dict[str, Any]]:
    bid = await repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return bid.get("uploadedFiles", [])


@router.post("/{bid_id}/files", response_model=dict[str, Any], status_code=201)
async def upload_bid_file(
    bid_id: str,
    background_tasks: BackgroundTasks,
    file: UploadFile,
    doc_type: str = Form("Other", alias="docType"),
    notes: str = Form(""),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    documents_repo: DocumentsRepository = Depends(get_documents_repo),
) -> dict[str, Any]:
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    content = await file.read()
    fname = safe_filename(file.filename or "upload")
    timestamp = int(time.time() * 1000)
    saved_name = f"{bid_id}_{doc_type.replace(' ', '_')}_{timestamp}_{fname}"
    dest = UPLOADS_DIR / saved_name

    async with aiofiles.open(dest, "wb") as f:
        await f.write(content)

    file_record: dict[str, Any] = {
        "id": f"FILE-{bid_id}-{timestamp}",
        "name": fname,
        "type": doc_type,
        "mimetype": file.content_type or "application/octet-stream",
        "size": format_file_size(len(content)),
        "uploadedAt": date.today().isoformat(),
        "path": f"uploads/{saved_name}",
        "notes": notes,
    }

    def add_file(bid: dict[str, Any]) -> dict[str, Any]:
        files = bid.get("uploadedFiles", [])
        files.append(file_record)
        return {**bid, "uploadedFiles": files}

    await bids_repo.update_one(lambda b: b.get("id") == bid_id, add_file)

    # Also add to document vault
    doc_record: dict[str, Any] = {
        "id": f"DOC-{uuid.uuid4().hex[:8].upper()}",
        "fileName": fname,
        "fileType": Path(fname).suffix.lstrip("."),
        "sizeKb": len(content) // 1024,
        "supplier": "",
        "bidId": bid_id,
        "documentType": doc_type,
        "tags": [],
        "uploadDate": date.today().isoformat(),
        "uploadedBy": "System",
        "status": "Filed",
        "filePath": f"uploads/{saved_name}",
        "description": notes,
    }
    await documents_repo.append(doc_record)

    # Auto-parse line items in background for relevant doc types
    if doc_type in {"Item List", "RFP", "RFP Document"}:
        from services.line_item_parser import auto_parse_line_items
        background_tasks.add_task(auto_parse_line_items, bid_id, fname, str(dest))

    log.info("bid.file_uploaded", bid_id=bid_id, file=fname, doc_type=doc_type)
    return file_record


@router.get("/{bid_id}/files/{filename}/view")
async def view_bid_file(bid_id: str, filename: str) -> FileResponse:
    safe_name = safe_filename(filename)
    path = UPLOADS_DIR / safe_name
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(str(path), headers={"Content-Disposition": "inline"})


@router.get("/{bid_id}/files/{filename}/download")
async def download_bid_file(bid_id: str, filename: str) -> FileResponse:
    safe_name = safe_filename(filename)
    path = UPLOADS_DIR / safe_name
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(
        str(path),
        headers={"Content-Disposition": f'attachment; filename="{safe_name}"'},
    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LINE ITEMS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/line-items", response_model=list[dict[str, Any]])
async def get_line_items(
    bid_id: str,
    repo: LineItemsRepository = Depends(get_line_items_repo),
) -> list[dict[str, Any]]:
    return await repo.get_for_bid(bid_id)


@router.patch("/{bid_id}/line-items/{line_id}", response_model=dict[str, Any])
async def update_line_item(
    bid_id: str,
    line_id: str,
    body: dict[str, Any],
    repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    new_pricing: list[dict[str, Any]] = body.pop("supplierPricing", None) or []

    def updater(item: dict[str, Any]) -> dict[str, Any]:
        return {**item, **{k: v for k, v in body.items() if k not in ("id", "bidId")}}

    updated = await repo.update_one(lambda x: x.get("id") == line_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Line item {line_id!r} not found")

    # Smart-merge pricing array if provided
    if new_pricing:
        updated = await repo.smart_merge_pricing(line_id, new_pricing) or updated

    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EMAILS (bid-scoped)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/emails/by-supplier", response_model=list[dict[str, Any]])
async def get_emails_by_supplier(
    bid_id: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> list[dict[str, Any]]:
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    emails = await email_threads_repo.get_for_bid(bid_id)
    solicited = bid.get("solicitedSuppliers", [])

    # Group emails by supplierId
    groups: dict[str, dict[str, Any]] = {}

    for email in sorted(emails, key=lambda e: e.get("date", "")):
        sid = email.get("supplierId") or "unsolicited"
        if sid not in groups:
            groups[sid] = {
                "supplierId": sid,
                "supplierName": email.get("supplierName", ""),
                "supplierEmail": email.get("supplierEmail", ""),
                "emails": [],
                "status": "Awaiting",
                "lastActivity": None,
            }
        groups[sid]["emails"].append(email)
        groups[sid]["lastActivity"] = email.get("date")

    # Merge status from solicitedSuppliers
    for s in solicited:
        sid = s.get("supplierId") or s.get("email", "")
        if sid in groups:
            groups[sid]["status"] = s.get("status", "Awaiting")
        else:
            groups[sid] = {
                "supplierId": sid,
                "supplierName": s.get("supplierName", ""),
                "supplierEmail": s.get("email", ""),
                "emails": [],
                "status": s.get("status", "Awaiting"),
                "lastActivity": s.get("lastActivity"),
            }

    return list(groups.values())


@router.get("/{bid_id}/emails", response_model=list[dict[str, Any]])
async def get_bid_emails(
    bid_id: str,
    repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> list[dict[str, Any]]:
    return await repo.get_for_bid(bid_id)


@router.post("/{bid_id}/emails", response_model=dict[str, Any], status_code=201)
async def create_bid_email(
    bid_id: str,
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    direction = body.get("direction", "outbound")

    # Outbound emails — send via SMTP (non-fatal)
    if direction == "outbound":
        try:
            from dependencies import get_email_service
            from services.email.base import EmailMessage
            svc = get_email_service()
            msg = EmailMessage(
                to=body.get("to", ""),
                bcc=body.get("bcc", []),
                subject=body.get("subject", ""),
                body=body.get("body", ""),
                attachment_paths=body.get("attachmentPaths", []),
            )
            await svc.send_email(msg)
        except Exception as exc:
            log.warning("bid.email_send_failed", bid_id=bid_id, error=str(exc))
            raise HTTPException(status_code=502, detail=f"SMTP error: {exc}")

    email_record: dict[str, Any] = {
        "id": f"E-{int(time.time() * 1000)}-{uuid.uuid4().hex[:6]}",
        "bidId": bid_id,
        "direction": direction,
        "supplierId": body.get("supplierId"),
        "supplierName": body.get("supplierName"),
        "supplierEmail": body.get("supplierEmail"),
        "from": body.get("from", ""),
        "to": body.get("to", ""),
        "bcc": body.get("bcc", []),
        "subject": body.get("subject", ""),
        "body": body.get("body", ""),
        "date": datetime.now(timezone.utc).isoformat(),
        "attachments": [],
        "tags": body.get("tags", []),
        "read": False,
        "analysisResult": None,
        "isBounce": False,
        "portalSubmission": False,
    }

    await email_threads_repo.append(email_record)

    # Track solicited suppliers on Solicitation sends
    if "Solicitation" in email_record.get("tags", []) and direction == "outbound":
        bcc_list: list[str] = body.get("bcc", [])
        await _update_solicited_suppliers(bid_id, bcc_list, bids_repo)

    return email_record


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SUPPLIER STATUS OVERRIDE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/suppliers/{supplier_id}", response_model=dict[str, Any])
async def override_supplier_status(
    bid_id: str,
    supplier_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    new_status = body.get("status", "")

    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        solicited = bid.get("solicitedSuppliers", [])
        for s in solicited:
            if s.get("supplierId") == supplier_id or s.get("email") == supplier_id:
                s["status"] = new_status
                s["lastActivity"] = date.today().isoformat()
        return {**bid, "solicitedSuppliers": solicited}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AWARD EMAIL
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/send-award-email", response_model=dict[str, Any])
async def send_award_email(
    bid_id: str,
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    supplier_name = body.get("supplierName", "")
    supplier_email = body.get("supplierEmail", "")
    email_body = body.get("body") or build_award_email_body(
        supplier_name=supplier_name,
        customer_name=bid.get("customer", ""),
        bid_id=bid_id,
    )
    subject = body.get("subject") or build_award_email_subject(bid)

    sent = False
    try:
        from dependencies import get_email_service
        from services.email.base import EmailMessage
        svc = get_email_service()
        await svc.send_email(
            EmailMessage(
                to=supplier_email,
                bcc=[],
                subject=subject,
                body=email_body,
                attachment_paths=body.get("attachmentPaths", []),
            )
        )
        sent = True
    except Exception as exc:
        log.warning("bid.award_email_send_failed", bid_id=bid_id, error=str(exc))

    email_record: dict[str, Any] = {
        "id": f"E-AWARD-{bid_id}-{uuid.uuid4().hex[:8]}",
        "bidId": bid_id,
        "direction": "outbound",
        "supplierName": supplier_name,
        "supplierEmail": supplier_email,
        "subject": subject,
        "body": email_body,
        "date": datetime.now(timezone.utc).isoformat(),
        "tags": ["Award", "award-notification"],
        "read": True,
        "isBounce": False,
    }
    await email_threads_repo.append(email_record)

    # Mark awardNotificationSent on solicitedSuppliers
    def mark_award(bid: dict[str, Any]) -> dict[str, Any]:
        for s in bid.get("solicitedSuppliers", []):
            if s.get("email") == supplier_email or s.get("supplierName") == supplier_name:
                s["awardNotificationSent"] = True
                s["awardNotificationSentAt"] = datetime.now(timezone.utc).isoformat()
        return bid

    await bids_repo.update_one(lambda b: b.get("id") == bid_id, mark_award)

    return {"ok": True, "sent": sent, "emailId": email_record["id"]}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EMAIL ANALYSIS RESULT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/emails/{email_id}/analysis", response_model=dict[str, Any])
async def save_email_analysis(
    bid_id: str,
    email_id: str,
    body: dict[str, Any],
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    bids_repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    analysis = body.get("analysisResult", body)

    def updater(e: dict[str, Any]) -> dict[str, Any]:
        return {**e, "analysisResult": analysis}

    updated = await email_threads_repo.update_one(
        lambda e: e.get("id") == email_id and e.get("bidId") == bid_id,
        updater,
    )
    if not updated:
        raise HTTPException(status_code=404, detail=f"Email {email_id!r} not found")

    # Auto-update supplier status to Issues Found if issues detected
    issues = analysis.get("issues", {}) if isinstance(analysis, dict) else {}
    has_issues = any(
        issues.get(k) for k in ("missing_items", "format_issues", "expired_pricing", "non_compliant")
    )
    if has_issues:
        supplier_email = updated.get("supplierEmail", "")
        if supplier_email:
            def mark_issues(bid: dict[str, Any]) -> dict[str, Any]:
                for s in bid.get("solicitedSuppliers", []):
                    if s.get("email") == supplier_email and s.get("status") not in (
                        "Awarded", "Under Consideration"
                    ):
                        s["status"] = "Issues Found"
                return bid
            await bids_repo.update_one(lambda b: b.get("id") == bid_id, mark_issues)

    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AI PRICING EXTRACTION FROM EMAIL ATTACHMENT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/emails/{email_id}/extract-pricing", response_model=dict[str, Any])
async def extract_pricing_from_email(
    bid_id: str,
    email_id: str,
    llm: LLMService = Depends(get_llm_service),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> dict[str, Any]:
    email = await email_threads_repo.find_one(
        lambda e: e.get("id") == email_id and e.get("bidId") == bid_id
    )
    if not email:
        raise HTTPException(status_code=404, detail=f"Email {email_id!r} not found")

    line_items = await line_items_repo.get_for_bid(bid_id)
    if not line_items:
        raise HTTPException(status_code=404, detail="No line items found for this bid")

    # Fast-path: portal submission already has structured pricing
    if email.get("portalSubmission") and email.get("threadId"):
        thread_id = email["threadId"]
        all_subs = await submissions_repo.get_for_bid(bid_id)
        sub = next((s for s in all_subs if s.get("threadId") == thread_id), None)
        if sub:
            return _build_portal_extraction_result(sub, line_items)

    # Get document text from attachment
    doc_text = ""
    attachments: list[dict[str, Any]] = email.get("attachments", [])
    for att in attachments:
        path = att.get("path") or att.get("savedName", "")
        full_path = UPLOADS_DIR / Path(path).name
        if full_path.exists():
            doc_text = _read_file_text(str(full_path))
            if doc_text:
                break

    if not doc_text:
        body_text = email.get("body", "")
        if body_text and len(body_text) > 100:
            doc_text = body_text

    if not doc_text:
        raise HTTPException(status_code=422, detail="No extractable content found in email")

    # Detect Schwan's structured format
    if _is_schwans_format(doc_text):
        result = _extract_schwans_pricing(doc_text, line_items)
    else:
        result = await _extract_generic_pricing(doc_text, line_items, bid_id, llm)

    log.info(
        "pricing.extracted_from_email",
        bid_id=bid_id,
        email_id=email_id,
        items=len(result.get("items", [])),
    )
    return result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PORTAL REPLY (COE → Supplier)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/portal-reply", response_model=dict[str, Any])
async def portal_reply(
    bid_id: str,
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> dict[str, Any]:
    thread_id = body.get("threadId", "")
    message = body.get("message", "")
    supplier_email = body.get("supplierEmail", "")

    # Find the bid if not the one given (threadId is globally unique)
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    msg_id = f"MSG-{uuid.uuid4().hex[:12].upper()}"
    new_msg: dict[str, Any] = {
        "id": msg_id,
        "direction": "outbound",
        "from": "COE.BIDS@sysco.com",
        "fromName": "Sysco Bid COE",
        "body": message,
        "attachments": body.get("attachmentPaths", []),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "readBySupplier": False,
    }

    # Append to submissions.json thread
    def append_msg(sub: dict[str, Any]) -> dict[str, Any]:
        msgs = sub.get("messages", [])
        msgs.append(new_msg)
        return {**sub, "messages": msgs}

    await submissions_repo.update_submission(bid_id, thread_id, append_msg)

    # Mirror to emailThreads.json
    mirror: dict[str, Any] = {
        "id": f"E-COE-REPLY-{uuid.uuid4().hex[:8]}",
        "bidId": bid_id,
        "direction": "outbound",
        "supplierEmail": supplier_email,
        "subject": f"Re: Your pricing submission for {bid.get('customer', '')}",
        "body": message,
        "date": new_msg["timestamp"],
        "tags": ["portal-reply"],
        "read": True,
        "threadId": thread_id,
        "portalSubmission": True,
    }
    await email_threads_repo.append(mirror)

    # Send email to supplier (non-fatal)
    try:
        from config import get_settings
        from dependencies import get_email_service
        from services.email.base import EmailMessage
        settings = get_settings()
        svc = get_email_service()
        await svc.send_email(
            EmailMessage(
                to=supplier_email,
                bcc=[],
                subject=mirror["subject"],
                body=(
                    f"Hello,\n\n{message}\n\n"
                    f"View your portal thread: "
                    f"{settings.portal_base_url}/submit/{bid_id}/thread/{thread_id}\n\n"
                    "Sysco Bid COE"
                ),
            )
        )
    except Exception as exc:
        log.warning("portal_reply.email_failed", error=str(exc))

    return {"ok": True, "messageId": msg_id}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AUTO-REMINDER CONFIG
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/auto-reminder", response_model=dict[str, Any])
async def update_auto_reminder(
    bid_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        current = bid.get("autoReminder", {})
        return {**bid, "autoReminder": {**current, **body}}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PORTAL CONFIG
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/portal-config", response_model=dict[str, Any])
async def update_portal_config(
    bid_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        return {**bid, "portalConfig": {**body, "appliedAt": datetime.now(timezone.utc).isoformat()}}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return updated


@router.patch("/{bid_id}/working-file-config", response_model=dict[str, Any])
async def update_working_file_config(
    bid_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        return {**bid, "workingFileConfig": body}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# INTERNAL HELPERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def _update_solicited_suppliers(
    bid_id: str, bcc_emails: list[str], bids_repo: BidsRepository
) -> None:
    from dependencies import get_suppliers_repo
    suppliers = await get_suppliers_repo().load()
    email_to_supplier = {s.get("contact", "").lower(): s for s in suppliers}

    new_entries = []
    today = date.today().isoformat()
    for email in bcc_emails:
        sup = email_to_supplier.get(email.lower())
        if sup:
            new_entries.append({
                "supplierId": sup.get("id"),
                "supplierName": sup.get("name"),
                "email": email,
                "status": "Awaiting",
                "solicitedDate": today,
                "lastActivity": today,
                "awardNotificationSent": False,
                "awardNotificationSentAt": None,
            })

    if new_entries:
        def add_solicited(bid: dict[str, Any]) -> dict[str, Any]:
            existing = bid.get("solicitedSuppliers", [])
            existing_emails = {s.get("email", "").lower() for s in existing}
            for entry in new_entries:
                if entry["email"].lower() not in existing_emails:
                    existing.append(entry)
            return {
                **bid,
                "solicitedSuppliers": existing,
                "lastSolicitationDate": today,
            }
        await bids_repo.update_one(lambda b: b.get("id") == bid_id, add_solicited)


async def _sync_award_to_line_items(
    bid_id: str,
    solicited_suppliers: list[dict[str, Any]],
    line_items_repo: LineItemsRepository,
) -> None:
    awarded = [s for s in solicited_suppliers if s.get("status") == "Awarded"]
    if not awarded:
        return
    awarded_names = {s.get("supplierName", "") for s in awarded}

    all_items = await line_items_repo.load()
    changed = False
    for item in all_items:
        if item.get("bidId") != bid_id:
            continue
        for pricing in item.get("supplierPricing", []):
            if pricing.get("supplierName") in awarded_names:
                if pricing.get("awardStatus") != "awarded":
                    pricing["awardStatus"] = "awarded"
                    changed = True
    if changed:
        await line_items_repo.save(all_items)


def _read_file_text(path: str) -> str:
    try:
        fname = path.lower()
        with open(path, "rb") as f:
            content = f.read()
        if fname.endswith(".pdf"):
            import pypdf
            reader = pypdf.PdfReader(io.BytesIO(content))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        elif fname.endswith((".xlsx", ".xls")):
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
            lines: list[str] = []
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True):
                    lines.append("\t".join("" if v is None else str(v) for v in row))
            return "\n".join(lines)
        elif fname.endswith(".csv"):
            return content.decode("utf-8", errors="replace")
    except Exception:
        pass
    return ""


def _is_schwans_format(text: str) -> bool:
    return "schwan" in text.lower() or ("bid item" in text.lower() and "delivered price" in text.lower())


def _extract_schwans_pricing(
    doc_text: str, line_items: list[dict[str, Any]]
) -> dict[str, Any]:
    """Parse Schwan's structured XLSX: col J = bid item #, col R = delivered price."""
    items = []
    li_by_item = {li.get("bidItem", ""): li for li in line_items}

    for line in doc_text.split("\n"):
        cols = line.split("\t")
        if len(cols) > 17:
            bid_item_str = str(cols[9]).strip().zfill(4)
            try:
                price = float(str(cols[17]).strip().replace("$", "").replace(",", ""))
            except ValueError:
                continue
            if bid_item_str in li_by_item:
                li = li_by_item[bid_item_str]
                items.append({
                    "rfp_line_id": li["id"],
                    "bid_item": bid_item_str,
                    "description": li.get("description", ""),
                    "deliveredPrice": price,
                    "confidenceScore": 95,
                    "matchedBidItemNo": bid_item_str,
                })

    return {"items": items, "source": "schwans_structured"}


async def _extract_generic_pricing(
    doc_text: str,
    line_items: list[dict[str, Any]],
    bid_id: str,
    llm: LLMService,
) -> dict[str, Any]:
    li_summary = json.dumps(
        [{"id": li["id"], "bidItem": li.get("bidItem"), "description": li.get("description"), "category": li.get("category")} for li in line_items[:50]],
        indent=2,
    )

    system_prompt = (
        PRICING_EXTRACTION_SYSTEM
        + "\n\nConfidence scoring formula: "
        "Product type match (+40), Category match (+20), Cooking method (+15), "
        "Size/weight (+15), Certification (+10). "
        "For confidenceScore >= 50, MUST provide matchedBidItemNo. "
        'Return JSON: {"items": [{"description": str, "deliveredPrice": num, '
        '"fobPrice": num|null, "allowance": num|null, "confidenceScore": int, '
        '"matchedBidItemNo": str|null}]}'
    )
    user_prompt = (
        f"Bid line items (reference only):\n{li_summary}\n\n"
        f"Supplier document:\n{doc_text[:40000]}"
    )

    try:
        result = await llm.chat(system=system_prompt, user=user_prompt, max_tokens=4096)
        parsed = extract_json(result.content)
        return parsed if isinstance(parsed, dict) else {"items": parsed}
    except Exception as exc:
        log.error("pricing.generic_extract_failed", bid_id=bid_id, error=str(exc))
        return {"items": [], "error": str(exc)}


def _build_portal_extraction_result(
    sub: dict[str, Any], line_items: list[dict[str, Any]]
) -> dict[str, Any]:
    li_by_item = {li.get("bidItem", ""): li for li in line_items}
    items = []
    for li_price in sub.get("lineItems", []):
        item_no = str(li_price.get("itemNo", "")).zfill(4)
        li = li_by_item.get(item_no)
        if li and not li_price.get("noBid"):
            price = li_price.get("deliveredPrice") or li_price.get("unitPrice")
            if price:
                items.append({
                    "rfp_line_id": li["id"],
                    "bid_item": item_no,
                    "description": li.get("description", ""),
                    "deliveredPrice": price,
                    "fobPrice": li_price.get("fobPrice"),
                    "allowance": li_price.get("allowance"),
                    "devType": li_price.get("devType"),
                    "confidenceScore": 99,
                    "matchedBidItemNo": item_no,
                    "matchSource": "portal",
                })
    return {
        "items": items,
        "source": "portal",
        "supplierName": sub.get("supplierName"),
        "pricedCount": sub.get("pricedCount", 0),
        "noBidCount": sub.get("noBidCount", 0),
    }
