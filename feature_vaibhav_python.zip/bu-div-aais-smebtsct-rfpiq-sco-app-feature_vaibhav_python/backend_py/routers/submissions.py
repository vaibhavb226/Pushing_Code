"""
Public supplier portal API — all /api/submit/* endpoints.

These routes are PUBLIC (no X-API-Key required).
PUBLIC_PREFIXES in middleware/auth.py must include "/api/v1/submit/" and "/api/submit/".
"""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any

import structlog
from fastapi import APIRouter, Depends, Form, HTTPException, Query, UploadFile

from dependencies import (
    UPLOADS_DIR,
    get_bids_repo,
    get_email_threads_repo,
    get_line_items_repo,
    get_submissions_repo,
)
from repositories.bids_repo import BidsRepository
from repositories.email_threads_repo import EmailThreadsRepository
from repositories.line_items_repo import LineItemsRepository
from repositories.submissions_repo import SubmissionsRepository
from utils.file_utils import safe_filename

log = structlog.get_logger()
router = APIRouter(tags=["portal"])


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GET /api/submit/:bidId — bid details for submission form
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}", response_model=dict[str, Any])
async def get_portal_bid(
    bid_id: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    line_items = await line_items_repo.get_for_bid(bid_id)

    # Return only public-safe fields
    return {
        "id": bid["id"],
        "customer": bid.get("customer", ""),
        "segment": bid.get("segment", ""),
        "customerDue": bid.get("customerDue", ""),
        "compliance": bid.get("compliance", []),
        "itemCategories": bid.get("itemCategories", []),
        "portalConfig": bid.get("portalConfig"),
        "lineItems": [
            {
                "id": li["id"],
                "bidItem": li.get("bidItem", ""),
                "description": li.get("description", ""),
                "brand": li.get("brand", ""),
                "pack": li.get("pack", ""),
                "size": li.get("size", ""),
                "unit": li.get("unit", ""),
                "category": li.get("category", ""),
                "buyAmerican": li.get("buyAmerican", False),
                "childNutrition": li.get("childNutrition", False),
                "pfsRequired": li.get("pfsRequired", False),
                "exactSpec": li.get("exactSpec", False),
            }
            for li in line_items
        ],
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# POST /api/submit/:bidId — supplier pricing submission
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}", response_model=dict[str, Any], status_code=201)
async def submit_pricing(
    bid_id: str,
    supplier_name: str = Form("", alias="supplierName"),
    supplier_email: str = Form("", alias="supplierEmail"),
    contact_name: str = Form("", alias="contactName"),
    line_items_json: str = Form("[]", alias="lineItems"),
    notes: str = Form(""),
    pricing_file: UploadFile | None = None,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    # Parse line items JSON
    import json
    try:
        raw_items: list[dict[str, Any]] = json.loads(line_items_json)
    except json.JSONDecodeError:
        raw_items = []

    # Count priced vs no-bid
    priced_count = sum(
        1 for li in raw_items
        if not li.get("noBid")
        and (float(li.get("unitPrice") or 0) > 0 or float(li.get("casePrice") or 0) > 0)
    )
    no_bid_count = sum(1 for li in raw_items if li.get("noBid"))

    # Save pricing file
    pricing_file_name = ""
    if pricing_file:
        content = await pricing_file.read()
        ts = int(time.time() * 1000)
        ext = safe_filename(pricing_file.filename or "upload")
        fname = f"{bid_id}_Portal_{ts}_{ext}"
        dest = UPLOADS_DIR / fname
        import aiofiles
        async with aiofiles.open(dest, "wb") as f:
            await f.write(content)
        pricing_file_name = fname

    confirmation_id = f"SUB-{bid_id}-{uuid.uuid4().hex[:8].upper()}"
    thread_id = f"THREAD-{bid_id}-{int(time.time() * 1000)}"
    now = datetime.now(timezone.utc).isoformat()

    submission: dict[str, Any] = {
        "confirmationId": confirmation_id,
        "threadId": thread_id,
        "submittedAt": now,
        "supplierName": supplier_name,
        "supplierEmail": supplier_email,
        "contactName": contact_name,
        "lineItems": raw_items,
        "pricingFile": pricing_file_name,
        "pricedCount": priced_count,
        "noBidCount": no_bid_count,
        "notes": notes,
        "messages": [],
    }

    await submissions_repo.append_for_bid(bid_id, submission)

    # Mirror to emailThreads.json as a portal submission event
    email_record: dict[str, Any] = {
        "id": f"E-PORTAL-{uuid.uuid4().hex[:8].upper()}",
        "bidId": bid_id,
        "direction": "inbound",
        "supplierId": _find_supplier_id(bid, supplier_email),
        "supplierName": supplier_name,
        "supplierEmail": supplier_email,
        "from": supplier_email,
        "to": "",
        "bcc": [],
        "subject": f"Portal Submission: {bid.get('customer', '')} — {bid_id}",
        "body": f"Pricing submission from {supplier_name}. Items priced: {priced_count}, No bid: {no_bid_count}.",
        "date": now,
        "attachments": [{"name": pricing_file_name, "path": f"uploads/{pricing_file_name}"}] if pricing_file_name else [],
        "tags": ["portal-submission"],
        "read": False,
        "analysisResult": None,
        "isBounce": False,
        "portalSubmission": True,
        "threadId": thread_id,
        "confirmationId": confirmation_id,
    }
    await email_threads_repo.append(email_record)

    # Update supplier status to Responded
    await _update_supplier_responded(bid_id, supplier_email, thread_id, bids_repo)

    log.info(
        "portal.submission_received",
        bid_id=bid_id,
        supplier=supplier_name,
        priced=priced_count,
    )

    return {
        "confirmationId": confirmation_id,
        "threadId": thread_id,
        "submittedAt": now,
        "pricedCount": priced_count,
        "noBidCount": no_bid_count,
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GET /api/submit/:bidId/submissions — portal submission summaries for SuppliersTab
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/submissions", response_model=list[dict[str, Any]])
async def get_submissions(
    bid_id: str,
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> list[dict[str, Any]]:
    all_subs = await submissions_repo.get_for_bid(bid_id)
    return [
        {
            "confirmationId": s.get("confirmationId"),
            "threadId": s.get("threadId"),
            "supplierName": s.get("supplierName"),
            "supplierEmail": s.get("supplierEmail"),
            "submittedAt": s.get("submittedAt"),
            "pricedCount": s.get("pricedCount", 0),
            "noBidCount": s.get("noBidCount", 0),
            "messageCount": len(s.get("messages", [])),
            "lastUpdated": _last_message_time(s),
            "accessed": True,
        }
        for s in all_subs
    ]


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GET /api/submit/:bidId/thread/:threadId — conversation thread (email-gated)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/thread/{thread_id}", response_model=dict[str, Any])
async def get_thread(
    bid_id: str,
    thread_id: str,
    email: str = Query(""),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    all_subs = await submissions_repo.get_for_bid(bid_id)
    sub = next((s for s in all_subs if s.get("threadId") == thread_id), None)

    if not sub:
        raise HTTPException(status_code=404, detail="Thread not found")

    # Email gate — supplier must verify with their email
    if email and email.lower() != sub.get("supplierEmail", "").lower():
        raise HTTPException(status_code=401, detail="Email address does not match submission")

    # Mark COE outbound messages as read by supplier
    messages = sub.get("messages", [])
    changed = False
    for msg in messages:
        if msg.get("direction") == "outbound" and not msg.get("readBySupplier"):
            msg["readBySupplier"] = True
            changed = True

    if changed:
        def mark_read(s: dict[str, Any]) -> dict[str, Any]:
            return {**s, "messages": messages}
        await submissions_repo.update_submission(bid_id, thread_id, mark_read)

    line_items = await line_items_repo.get_for_bid(bid_id)
    bid = await bids_repo.find_one(lambda b: b.get("id") == bid_id)

    return {
        "confirmationId": sub.get("confirmationId"),
        "threadId": thread_id,
        "supplierName": sub.get("supplierName"),
        "supplierEmail": sub.get("supplierEmail"),
        "contactName": sub.get("contactName"),
        "submittedAt": sub.get("submittedAt"),
        "pricedCount": sub.get("pricedCount", 0),
        "noBidCount": sub.get("noBidCount", 0),
        "notes": sub.get("notes", ""),
        "pricingFile": sub.get("pricingFile"),
        "lineItems": sub.get("lineItems", []),
        "messages": messages,
        "messageCount": len(messages),
        "lastUpdated": _last_message_time(sub),
        "customerName": bid.get("customer", "") if bid else "",
        "bidId": bid_id,
        "rfpLineItems": [
            {
                "id": li["id"],
                "bidItem": li.get("bidItem"),
                "description": li.get("description"),
                "category": li.get("category"),
            }
            for li in line_items
        ],
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# POST /api/submit/:bidId/message — supplier follow-up message
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/message", response_model=dict[str, Any])
async def post_message(
    bid_id: str,
    body: dict[str, Any],
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    thread_id = body.get("threadId", "")
    message_text = body.get("message", "")
    supplier_email = body.get("supplierEmail", "")
    supplier_name = body.get("supplierName", "")
    attachment_paths: list[str] = body.get("attachmentPaths", [])

    all_subs = await submissions_repo.get_for_bid(bid_id)
    sub = next((s for s in all_subs if s.get("threadId") == thread_id), None)
    if not sub:
        raise HTTPException(status_code=404, detail="Thread not found")

    msg_id = f"MSG-{uuid.uuid4().hex[:12].upper()}"
    new_msg: dict[str, Any] = {
        "id": msg_id,
        "direction": "inbound",
        "from": supplier_email,
        "fromName": supplier_name,
        "body": message_text,
        "attachments": [{"name": p.split("/")[-1], "path": p} for p in attachment_paths],
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "readByBidCOE": False,
    }

    def append_msg(s: dict[str, Any]) -> dict[str, Any]:
        msgs = s.get("messages", [])
        msgs.append(new_msg)
        return {**s, "messages": msgs}

    await submissions_repo.update_submission(bid_id, thread_id, append_msg)

    # Mirror to emailThreads.json
    mirror: dict[str, Any] = {
        "id": f"E-PORTAL-MSG-{uuid.uuid4().hex[:8].upper()}",
        "bidId": bid_id,
        "direction": "inbound",
        "supplierName": supplier_name,
        "supplierEmail": supplier_email,
        "from": supplier_email,
        "subject": f"Portal Message: Thread {thread_id[:20]}",
        "body": message_text,
        "date": new_msg["timestamp"],
        "tags": ["portal-message"],
        "read": False,
        "threadId": thread_id,
        "portalSubmission": True,
    }
    await email_threads_repo.append(mirror)

    return {"ok": True, "messageId": msg_id}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GET /api/submit/:bidId/status/:confirmationId — receipt check
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/status/{confirmation_id}", response_model=dict[str, Any])
async def get_submission_status(
    bid_id: str,
    confirmation_id: str,
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> dict[str, Any]:
    all_subs = await submissions_repo.get_for_bid(bid_id)
    sub = next((s for s in all_subs if s.get("confirmationId") == confirmation_id), None)
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")

    return {
        "confirmationId": confirmation_id,
        "threadId": sub.get("threadId"),
        "status": "received",
        "submittedAt": sub.get("submittedAt"),
        "supplierName": sub.get("supplierName"),
        "pricedCount": sub.get("pricedCount", 0),
        "noBidCount": sub.get("noBidCount", 0),
    }


# ── Helpers ────────────────────────────────────────────────────────────────────

def _find_supplier_id(bid: dict[str, Any], email: str) -> str | None:
    for s in bid.get("solicitedSuppliers", []):
        if s.get("email", "").lower() == email.lower():
            return s.get("supplierId")
    return None


async def _update_supplier_responded(
    bid_id: str,
    supplier_email: str,
    thread_id: str,
    bids_repo: BidsRepository,
) -> None:
    today = datetime.now(timezone.utc).date().isoformat()

    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        for s in bid.get("solicitedSuppliers", []):
            if s.get("email", "").lower() == supplier_email.lower():
                if s.get("status") not in ("Awarded", "Under Consideration"):
                    s["status"] = "Responded"
                s["threadId"] = thread_id
                s["lastActivity"] = today
        return bid

    await bids_repo.update_one(lambda b: b.get("id") == bid_id, updater)


def _last_message_time(sub: dict[str, Any]) -> str:
    messages = sub.get("messages", [])
    if messages:
        return messages[-1].get("timestamp", sub.get("submittedAt", ""))
    return sub.get("submittedAt", "")
