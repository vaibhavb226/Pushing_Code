"""
GET /api/emails
GET /api/emails/:id
POST /api/emails/log  (non-persistent — POC only, mirrors Node.js behaviour)
"""
from __future__ import annotations

from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query

from dependencies import get_email_threads_repo
from repositories.email_threads_repo import EmailThreadsRepository
from schemas.email_thread import EmailCreate, EmailThreadResponse

log = structlog.get_logger()
router = APIRouter(tags=["emails"])


@router.get("/", response_model=list[dict[str, Any]])
async def list_emails(
    bid_id: str | None = Query(None, alias="bidId"),
    repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> list[dict[str, Any]]:
    emails = await repo.load()
    if bid_id:
        emails = [e for e in emails if e.get("bidId") == bid_id]
    return emails


@router.get("/{email_id}", response_model=dict[str, Any])
async def get_email(
    email_id: str,
    repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    email = await repo.find_one(lambda e: e.get("id") == email_id)
    if not email:
        raise HTTPException(status_code=404, detail=f"Email {email_id!r} not found")
    return email


@router.post("/log", response_model=dict[str, Any])
async def log_email(body: dict[str, Any]) -> dict[str, Any]:
    # Non-persistent POC endpoint — returns the constructed email without saving.
    # Mirrors POST /api/emails/log in emails.js
    log.info("email.log", subject=body.get("subject"))
    return {"ok": True, "logged": body}
