"""
POST /api/analyse-response
Analyse a supplier pricing document (PDF / Excel / CSV) using AI.
Returns priced items + issues found.
"""
from __future__ import annotations

import io
from typing import Any

import structlog
from fastapi import APIRouter, Depends, Form, UploadFile

from dependencies import get_llm_service
from routers.prompts import ANALYSE_PROMPT
from services.llm.json_parser import extract_json
from services.llm.provider import LLMService

log = structlog.get_logger()
router = APIRouter(tags=["analyse"])

_DEMO_RESULT: dict[str, Any] = {
    "priced_items": [
        {
            "item_code": "001",
            "description": "Demo Item — no file uploaded",
            "pack": "6/10",
            "qty": 100,
            "del_price": 12.50,
            "allw": None,
            "allw_type": None,
            "guarantee_date": None,
        }
    ],
    "issues": {
        "missing_items": [],
        "format_issues": ["No file was uploaded — demo result shown"],
        "expired_pricing": [],
        "non_compliant": [],
    },
    "supplier_name": "Demo Supplier",
    "quote_reference": None,
    "valid_through": None,
}


@router.post("/", response_model=dict[str, Any])
async def analyse_response(
    file: UploadFile | None = None,
    supplier_name: str = Form("", alias="supplierName"),
    llm: LLMService = Depends(get_llm_service),
) -> dict[str, Any]:
    if not file:
        return _DEMO_RESULT

    content = await file.read()
    mime = file.content_type or ""
    fname = (file.filename or "").lower()
    doc_text = _extract_text(content, mime, fname)

    if not doc_text.strip():
        return _DEMO_RESULT

    user_content = f"Supplier: {supplier_name}\n\nDocument:\n{doc_text[:60000]}"

    try:
        result = await llm.chat(system=ANALYSE_PROMPT, user=user_content, max_tokens=8000)
        parsed = extract_json(result.content)
    except Exception as exc:
        log.error("analyse_response.failed", supplier=supplier_name, error=str(exc))
        return _DEMO_RESULT

    log.info(
        "analyse_response.done",
        supplier=supplier_name,
        items=len(parsed.get("priced_items", [])),
    )
    return parsed


def _extract_text(content: bytes, mime: str, fname: str) -> str:
    if mime == "application/pdf" or fname.endswith(".pdf"):
        return _pdf_text(content)
    if fname.endswith(".csv") or mime == "text/csv":
        return content.decode("utf-8", errors="replace")
    # Excel
    return _excel_text(content)


def _pdf_text(content: bytes) -> str:
    try:
        import pypdf
        reader = pypdf.PdfReader(io.BytesIO(content))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except Exception:
        return ""


def _excel_text(content: bytes) -> str:
    try:
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
        lines: list[str] = []
        for ws in wb.worksheets:
            lines.append(f"=== Sheet: {ws.title} ===")
            for row in ws.iter_rows(values_only=True):
                row_str = "\t".join("" if v is None else str(v) for v in row)
                if row_str.strip():
                    lines.append(row_str)
        return "\n".join(lines)
    except Exception:
        return ""
