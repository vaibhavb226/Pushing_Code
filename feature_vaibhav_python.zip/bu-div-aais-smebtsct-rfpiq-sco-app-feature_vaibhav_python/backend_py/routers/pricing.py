"""
POST /api/extract-pricing
Matches supplier pricing data to RFP line items using AI.
"""
from __future__ import annotations

import json
from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from dependencies import get_line_items_repo, get_llm_service, get_pricing_repo
from repositories.line_items_repo import LineItemsRepository
from repositories.pricing_repo import PricingRepository
from routers.prompts import EXTRACT_PROMPT
from services.llm.json_parser import extract_json
from services.llm.provider import LLMService

log = structlog.get_logger()
router = APIRouter(tags=["pricing"])


class ExtractPricingRequest(BaseModel):
    bidId: str


@router.post("/", response_model=list[dict[str, Any]])
async def extract_pricing(
    body: ExtractPricingRequest,
    llm: LLMService = Depends(get_llm_service),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    pricing_repo: PricingRepository = Depends(get_pricing_repo),
) -> list[dict[str, Any]]:
    bid_id = body.bidId
    line_items = await line_items_repo.get_for_bid(bid_id)
    all_pricing = await pricing_repo.load()
    pricing_data = [p for p in all_pricing if p.get("bidId") == bid_id]

    if not line_items:
        raise HTTPException(status_code=404, detail=f"No line items found for bid {bid_id!r}")

    if not pricing_data:
        raise HTTPException(status_code=404, detail=f"No pricing data found for bid {bid_id!r}")

    user_prompt = (
        f"RFP Line Items for {bid_id}:\n{json.dumps(line_items, indent=2)}\n\n"
        f"Supplier Pricing Responses:\n{json.dumps(pricing_data, indent=2)}"
    )

    try:
        result = await llm.chat(system=EXTRACT_PROMPT, user=user_prompt, max_tokens=8192)
        matched = extract_json(result.content)
    except Exception as exc:
        log.error("pricing.extract_failed", bid_id=bid_id, error=str(exc))
        # Demo fallback — SUPC exact match
        matched = _demo_supc_match(line_items, pricing_data)

    if not isinstance(matched, list):
        matched = []

    log.info("pricing.extracted", bid_id=bid_id, matches=len(matched))
    return matched


def _demo_supc_match(
    line_items: list[dict[str, Any]],
    pricing_data: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Fallback: exact SUPC matching when no API key is configured."""
    results = []
    for li in line_items:
        match = next(
            (p for p in pricing_data if p.get("rfpLineId") == li.get("id")),
            None,
        )
        if match:
            results.append({
                "rfp_line_id": li["id"],
                "matched_supc": match.get("supc"),
                "supplier_name": match.get("supplierName", ""),
                "supplied_price": match.get("suppliedPrice"),
                "allw": match.get("allw"),
                "dl": match.get("dl"),
                "dev_type": match.get("devType"),
                "price_case": match.get("priceCase"),
                "open_review": "N",
                "confidence": match.get("confidence", 90),
                "match_method": "supc_exact",
                "notes": "",
            })
    return results
