"""
Line item parsing service.

Mirrors backend/services/lineItemParser.js:
- parseLineItemsFromExcel()  — direct XLSX column mapping (no AI)
- parseLineItemsFromPDF()    — PDF text → AI extraction
- autoParseLineItems()       — auto-detect format and call correct parser
- saveLineItemsToDB()        — write results to lineItems.json + update bid metadata
"""
from __future__ import annotations

import io
import re
from datetime import date
from pathlib import Path
from typing import Any

import structlog

log = structlog.get_logger()

# Column name keyword matching (flexible — case-insensitive substring)
_COLUMN_KEYWORDS: dict[str, list[str]] = {
    "itemNo": ["item no", "item #", "bid item", "line no", "line number", "item number"],
    "category": ["category", "cat."],
    "description": ["description", "item desc", "product desc", "prod desc"],
    "brand": ["brand"],
    "mpcCode": ["mpc", "mfg code", "manufacturer code", "product code", "mfg#"],
    "pack": ["pack size", "pack"],
    "size": ["size"],
    "unit": ["uom", "unit of measure", "unit"],
    "qty": ["est qty", "qty", "quantity", "volume", "annual qty", "est. qty"],
    "storage": ["storage", "temp", "temp zone"],
    "cn": ["cn", "child nutrition", "child nutr"],
    "buyAmerican": ["buy american", "buy am", "ba"],
    "pfs": ["pfs"],
}

_TRUTHY_VALUES: frozenset[str] = frozenset(["yes", "y", "x", "1", "true"])


def _is_truthy(val: Any) -> bool:
    return str(val).strip().lower() in _TRUTHY_VALUES if val is not None else False


def parse_line_items_from_excel(bid_id: str, file_path: str) -> list[dict[str, Any]]:
    """Direct XLSX column mapping — no AI required."""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(file_path, data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
    except Exception as exc:
        log.warning("excel_parser.open_failed", path=file_path, error=str(exc))
        return []

    if not rows:
        return []

    # Find header row
    header_idx = next(
        (i for i, r in enumerate(rows) if any(c is not None for c in r)), 0
    )
    header = [str(c).strip().lower() if c is not None else "" for c in rows[header_idx]]

    # Map column keywords → column indices
    col_map: dict[str, int] = {}
    for field, keywords in _COLUMN_KEYWORDS.items():
        for kw in keywords:
            idx = next((i for i, h in enumerate(header) if kw in h), None)
            if idx is not None:
                col_map[field] = idx
                break

    items: list[dict[str, Any]] = []
    data_rows = rows[header_idx + 1:]

    for i, row in enumerate(data_rows):
        if not any(c is not None for c in row):
            continue  # skip empty rows

        def cell(field: str) -> Any:
            idx = col_map.get(field)
            return row[idx] if idx is not None and idx < len(row) else None

        items.append({
            "id": f"LI-{bid_id}-{i + 1:03d}",
            "bidId": bid_id,
            "bidItem": str(cell("itemNo") or i + 1).strip().zfill(4),
            "mpcCode": str(cell("mpcCode") or "").strip(),
            "brand": str(cell("brand") or "").strip(),
            "description": str(cell("description") or "").strip(),
            "pack": str(cell("pack") or "").strip(),
            "size": str(cell("size") or "").strip(),
            "unit": str(cell("unit") or "").strip(),
            "category": str(cell("category") or "").strip(),
            "qty": int(float(str(cell("qty") or 0).replace(",", "") or 0)),
            "storage": str(cell("storage") or "").strip(),
            "cw": "N",
            "stkType": "A",
            "buyAmerican": _is_truthy(cell("buyAmerican")),
            "childNutrition": _is_truthy(cell("cn")),
            "pfsRequired": _is_truthy(cell("pfs")),
            "exactSpec": False,
            "rfpPopulated": True,
            "_source": "excel",
            "trueVendor": None,
            "suppliedPrice": None,
            "allw": None,
            "dl": None,
            "priceCase": None,
            "devType": None,
            "openReview": False,
            "status": "No Response",
            "confidence": None,
            "supplierPricing": [],
        })

    log.info("excel_parser.done", bid_id=bid_id, items=len(items))
    return items


async def parse_line_items_from_pdf(bid_id: str, file_path: str) -> list[dict[str, Any]]:
    """PDF text → Anthropic AI extraction."""
    try:
        import pypdf
        reader = pypdf.PdfReader(file_path)
        pdf_text = "\n".join(page.extract_text() or "" for page in reader.pages)
    except Exception as exc:
        log.warning("pdf_parser.read_failed", path=file_path, error=str(exc))
        return []

    if not pdf_text.strip():
        return []

    from dependencies import get_llm_service
    from services.llm.json_parser import extract_json

    user_prompt = (
        "Extract all product line items from this RFP/bid document. "
        "Return ONLY valid JSON. No markdown fences, no explanation. "
        "Start with { and end with }.\n\n"
        f"DOCUMENT TEXT:\n{pdf_text[:15000]}\n\n"
        'Return this exact structure:\n'
        '{\n'
        '  "items": [\n'
        '    {\n'
        '      "itemNo": "0001",\n'
        '      "category": "Protein",\n'
        '      "description": "full product description",\n'
        '      "brand": "brand name or empty string",\n'
        '      "mfgCode": "product code or empty string",\n'
        '      "packSize": "e.g. 6/10 or empty string",\n'
        '      "size": "e.g. 4 OZ or empty string",\n'
        '      "unit": "CS or EA or LB etc",\n'
        '      "estQty": 0,\n'
        '      "storage": "Freezer or Cooler or Dry or empty string",\n'
        '      "compliance": ["CN", "Buy American", "PFS"]\n'
        '    }\n'
        '  ],\n'
        '  "confidence": "high|medium|low",\n'
        '  "totalFound": 0\n'
        '}'
    )

    try:
        llm = get_llm_service()
        result = await llm.chat(system="", user=user_prompt, max_tokens=4000)
        parsed = extract_json(result.content)
        raw_items: list[dict[str, Any]] = parsed.get("items", [])
    except Exception as exc:
        log.error("pdf_parser.ai_failed", bid_id=bid_id, error=str(exc))
        return []

    items: list[dict[str, Any]] = []
    for i, li in enumerate(raw_items):
        compliance = li.get("compliance", [])
        items.append({
            "id": f"LI-{bid_id}-{i + 1:03d}",
            "bidId": bid_id,
            "bidItem": str(li.get("itemNo") or i + 1).zfill(4),
            "mpcCode": li.get("mfgCode") or "",
            "brand": li.get("brand") or "",
            "description": li.get("description") or "",
            "pack": li.get("packSize") or "",
            "size": li.get("size") or "",
            "unit": li.get("unit") or "",
            "category": li.get("category") or "",
            "qty": int(li.get("estQty") or 0),
            "storage": li.get("storage") or "",
            "cw": "N",
            "stkType": "A",
            "buyAmerican": "Buy American" in compliance or "BA" in compliance,
            "childNutrition": "CN" in compliance or "Child Nutrition" in compliance,
            "pfsRequired": "PFS" in compliance,
            "exactSpec": False,
            "rfpPopulated": True,
            "_source": "pdf",
            "trueVendor": None,
            "suppliedPrice": None,
            "allw": None,
            "dl": None,
            "priceCase": None,
            "devType": None,
            "openReview": False,
            "status": "No Response",
            "confidence": None,
            "supplierPricing": [],
        })

    log.info("pdf_parser.done", bid_id=bid_id, items=len(items))
    return items


async def auto_parse_line_items(
    bid_id: str,
    original_name: str,
    file_path: str,
) -> list[dict[str, Any]]:
    """Detect file type and call the correct parser. Excel takes priority over PDF."""
    fname_lower = original_name.lower()
    if fname_lower.endswith((".xlsx", ".xls", ".csv")):
        items = parse_line_items_from_excel(bid_id, file_path)
        source = "excel"
    elif fname_lower.endswith(".pdf"):
        items = await parse_line_items_from_pdf(bid_id, file_path)
        source = "pdf"
    else:
        return []

    if items:
        await save_line_items_to_db(bid_id, items, source)

    return items


async def save_line_items_to_db(
    bid_id: str,
    items: list[dict[str, Any]],
    source: str,
) -> None:
    """
    Write items to lineItems.json, replacing existing items for this bid.
    Also updates bid metadata: items count, _lineItemSource, itemCategories.
    """
    from dependencies import get_bids_repo, get_line_items_repo

    line_items_repo = get_line_items_repo()
    bids_repo = get_bids_repo()

    all_items = await line_items_repo.load()
    all_items = [it for it in all_items if it.get("bidId") != bid_id]
    all_items.extend(items)
    await line_items_repo.save(all_items)

    categories = list({it.get("category", "") for it in items if it.get("category")})

    await bids_repo.update_one(
        lambda b: b.get("id") == bid_id,
        lambda b: {
            **b,
            "items": len(items),
            "_lineItemSource": source,
            "itemCategories": categories,
        },
    )
    log.info("line_items.saved", bid_id=bid_id, count=len(items), source=source)
