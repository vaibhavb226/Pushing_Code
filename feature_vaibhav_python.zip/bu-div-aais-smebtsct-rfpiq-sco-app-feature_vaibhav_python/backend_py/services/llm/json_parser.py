"""
Central JSON extraction utility.

Replaces the 5 duplicated extractJSON() helper functions spread across
rfpParser.js, pricing.js, analyseResponse.js, bids.js, and lineItemParser.js.

Logic (identical to the Node.js originals):
1. Strip markdown code fences  (```json … ``` or ``` … ```)
2. Try direct json.loads()
3. Extract first {...} object via regex, try parse
4. Extract first [...] array via regex, try parse
5. Raise ValueError with the first 500 chars of the raw response for debugging
"""
from __future__ import annotations

import json
import re


def extract_json(raw_text: str) -> dict | list:
    if not raw_text or not isinstance(raw_text, str):
        raise ValueError("Empty AI response")

    text = raw_text.strip()

    # Strip markdown code fences (all variants)
    text = re.sub(r"^```json\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^```\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text, flags=re.IGNORECASE)
    text = text.strip()

    # Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Extract first {...} object
    obj_match = re.search(r"\{[\s\S]*\}", text)
    if obj_match:
        try:
            return json.loads(obj_match.group(0))
        except json.JSONDecodeError:
            pass

    # Extract first [...] array
    arr_match = re.search(r"\[[\s\S]*\]", text)
    if arr_match:
        try:
            return json.loads(arr_match.group(0))
        except json.JSONDecodeError:
            pass

    preview = text[:500].replace("\n", " ")
    raise ValueError(
        f"AI response could not be parsed as JSON. First 500 chars: {preview!r}"
    )
