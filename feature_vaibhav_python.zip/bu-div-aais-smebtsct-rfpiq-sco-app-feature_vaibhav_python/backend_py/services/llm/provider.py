"""
Vendor-agnostic LLM service wrapper.

All 5 AI call sites use one of two methods:
- chat()              — single user message (rfp_parser, pricing, analyse_response, bids, lineItemParser)
- chat_with_history() — multi-turn conversation (ai_chat)

The underlying model is a LangChain BaseChatModel, so swapping providers
requires only changing LLM_PROVIDER in .env — no code changes.
"""
from __future__ import annotations

from dataclasses import dataclass

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage


@dataclass
class LLMResponse:
    content: str


class LLMService:
    def __init__(self, model: BaseChatModel) -> None:
        self._model = model

    async def chat(
        self,
        system: str,
        user: str,
        max_tokens: int = 1024,
        temperature: float = 0.1,
    ) -> LLMResponse:
        """Single-turn: one system prompt + one user message."""
        bound = self._model.bind(max_tokens=max_tokens, temperature=temperature)
        messages = []
        if system:
            messages.append(SystemMessage(content=system))
        messages.append(HumanMessage(content=user))
        response = await bound.ainvoke(messages)
        return LLMResponse(content=str(response.content))

    async def chat_with_history(
        self,
        system: str,
        messages: list[dict[str, str]],
        max_tokens: int = 1024,
        temperature: float = 0.1,
    ) -> LLMResponse:
        """
        Multi-turn: system prompt + existing conversation history.
        messages format: [{"role": "user"|"assistant", "content": str}, ...]
        """
        lc_messages = []
        if system:
            lc_messages.append(SystemMessage(content=system))
        for m in messages:
            if m.get("role") == "user":
                lc_messages.append(HumanMessage(content=str(m.get("content", ""))))
            else:
                lc_messages.append(AIMessage(content=str(m.get("content", ""))))
        bound = self._model.bind(max_tokens=max_tokens, temperature=temperature)
        response = await bound.ainvoke(lc_messages)
        return LLMResponse(content=str(response.content))
