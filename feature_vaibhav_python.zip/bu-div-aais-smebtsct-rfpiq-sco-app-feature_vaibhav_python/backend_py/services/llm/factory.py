"""
LLM provider factory.

Reads LLM_PROVIDER from settings and returns the correct LangChain model
wrapped in LLMService. Supported values:

  anthropic  — ChatAnthropic (default; current production provider)
               Requires: ANTHROPIC_API_KEY
  
  openai     — ChatOpenAI
               Requires: OPENAI_API_KEY
  
  vertexai   — ChatVertexAI (Google Cloud Vertex AI)
               Uses IAM-based authentication (service account OAuth 2.0 tokens)
               No API key needed — automatically uses:
                 1. GOOGLE_APPLICATION_CREDENTIALS (path to service account JSON)
                 2. gcloud Application Default Credentials (gcloud auth)
                 3. Workload Identity (GKE, Cloud Run, etc.)
               Requires: GCP_PROJECT, GCP_LOCATION
"""
from __future__ import annotations

from langchain_core.language_models import BaseChatModel

from config import Settings
from services.llm.provider import LLMService


def build_llm_service(settings: Settings) -> LLMService:
    provider = settings.llm_provider.lower()

    if provider == "anthropic":
        from langchain_anthropic import ChatAnthropic

        model: BaseChatModel = ChatAnthropic(  # type: ignore[call-arg]
            model=settings.anthropic_model,
            api_key=settings.anthropic_api_key.get_secret_value(),
        )

    elif provider == "openai":
        from langchain_openai import ChatOpenAI

        model = ChatOpenAI(
            model=settings.openai_model,
            api_key=settings.openai_api_key.get_secret_value(),  # type: ignore[arg-type]
        )

    elif provider == "vertexai":
        from langchain_google_vertexai import ChatVertexAI

        # ChatVertexAI automatically uses Application Default Credentials (ADC)
        # which includes service account keys, gcloud auth, or Workload Identity
        model = ChatVertexAI(
            model_name=settings.vertex_model,
            project=settings.gcp_project,
            location=settings.gcp_location,
        )

    else:
        raise ValueError(
            f"Unknown LLM_PROVIDER: {provider!r}. Choose: anthropic, openai, vertexai"
        )

    return LLMService(model)
